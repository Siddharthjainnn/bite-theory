(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[974],{3592:(e,a,i)=>{"use strict";i.r(a),i.d(a,{default:()=>k,dynamic:()=>y});var t=i(5155),r=i(2115),s=i(1393),n=i(1613),o=i(8828),l=i(4030),d=i(7882),c=i(2738);let p=[{ic:"\uD83E\uDDFE",label:"Order History"},{ic:"\uD83D\uDCCD",label:"Saved Addresses"},{ic:"\uD83D\uDCB3",label:"Wallet & Transactions"},{ic:"\uD83C\uDF9F️",label:"My Coupons"},{ic:"\uD83C\uDF81",label:"Refer & Earn"},{ic:"❤️",label:"Favorites"},{ic:"⭐",label:"My Reviews"},{ic:"\uD83D\uDEDF",label:"Help & Support"},{ic:"ℹ️",label:"About Bite Theory"},{ic:"\uD83D\uDCC4",label:"Terms & Privacy"}];function x({open:e,onClose:a}){let{data:i,status:r}=(0,d.useSession)(),s=i?.user,n="authenticated"===r,o=(s?.loyaltyLevel||"bronze").toString().toUpperCase();return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:`drawer-scrim ${e?"on":""}`,onClick:a,"aria-hidden":!0}),(0,t.jsxs)("aside",{className:`drawer ${e?"on":""}`,"aria-hidden":!e,children:[(0,t.jsxs)("div",{className:"drawer-head",children:[(0,t.jsx)("button",{className:"drawer-x",onClick:a,"aria-label":"Close",children:"✕"}),(0,t.jsx)("div",{className:"drawer-head-title",children:"My Profile"}),n?(0,t.jsxs)("div",{className:"drawer-user",children:[s?.image?(0,t.jsx)("img",{className:"drawer-ava",src:s.image,alt:s.name||"You",referrerPolicy:"no-referrer"}):(0,t.jsx)("span",{className:"drawer-ava",children:function(e){if(!e)return"U";let a=e.trim().split(/\s+/);return((a[0]?.[0]||"")+(a[1]?.[0]||"")).toUpperCase()||"U"}(s?.name)}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"drawer-name",children:s?.name||"Bite Theory User"}),(0,t.jsx)("div",{className:"drawer-mail",children:s?.email}),(0,t.jsxs)("span",{className:"drawer-tier",children:["\uD83C\uDFC5 ",o," MEMBER"]})]})]}):(0,t.jsxs)("div",{className:"drawer-user",children:[(0,t.jsx)("span",{className:"drawer-ava",children:"\uD83D\uDC4B"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"drawer-name",children:"Guest"}),(0,t.jsx)("div",{className:"drawer-mail",children:"Login to order & earn rewards"}),(0,t.jsx)("button",{onClick:()=>(0,d.signIn)("google"),className:"drawer-login-btn",children:"Login / Sign up →"})]})]})]}),n&&(0,t.jsxs)("div",{className:"drawer-stats",children:[(0,t.jsxs)("div",{className:"dstat",children:[(0,t.jsx)("b",{children:s?.ordersCount??"—"}),(0,t.jsx)("span",{children:"Orders"})]}),(0,t.jsxs)("div",{className:"dstat",children:[(0,t.jsx)("b",{style:{color:c.C.green},children:(0,c.TG)(s?.walletBalance||0)}),(0,t.jsx)("span",{children:"Wallet"})]}),(0,t.jsxs)("div",{className:"dstat",children:[(0,t.jsx)("b",{style:{color:c.C.orange},children:s?.loyaltyPoints||0}),(0,t.jsx)("span",{children:"Points"})]})]}),(0,t.jsxs)("div",{className:"drawer-menu",children:[p.map(e=>(0,t.jsxs)("button",{className:"drawer-item",children:[(0,t.jsx)("span",{className:"di-ic",children:e.ic}),(0,t.jsx)("span",{className:"di-label",children:e.label}),(0,t.jsx)("span",{className:"di-arrow",children:"›"})]},e.label)),n&&(0,t.jsxs)("button",{className:"drawer-item logout",onClick:()=>(0,d.signOut)({callbackUrl:"/login"}),children:[(0,t.jsx)("span",{className:"di-ic",children:"↩️"}),(0,t.jsx)("span",{className:"di-label",children:"Logout"}),(0,t.jsx)("span",{className:"di-arrow",children:"›"})]})]})]}),(0,t.jsx)("style",{children:`
.drawer-scrim{position:fixed;top:0;bottom:0;left:50%;transform:translateX(-50%);
  width:100%;max-width:480px;background:rgba(13,59,46,.45);
  opacity:0;pointer-events:none;transition:opacity .3s;z-index:40}
.drawer-scrim.on{opacity:1;pointer-events:auto}
.drawer{position:fixed;top:0;bottom:0;right:0;left:auto;width:86%;max-width:330px;
  background:${c.C.bg};z-index:41;transform:translateX(105%);
  transition:transform .34s cubic-bezier(.4,0,.2,1);display:flex;flex-direction:column;
  box-shadow:-12px 0 40px rgba(0,0,0,.3);overflow-y:auto}
.drawer.on{transform:translateX(0)}
@media(min-width:520px){
  .drawer-scrim{top:18px;bottom:18px;height:calc(100vh - 36px);border-radius:30px}
  .drawer{top:18px;bottom:18px;height:calc(100vh - 36px);right:50%;margin-right:-240px;max-width:300px;border-radius:0 30px 30px 0}
}
.drawer-head{background:linear-gradient(135deg,${c.C.dark},${c.C.darkSoft});padding:16px 18px 20px;position:relative;border-radius:0 0 22px 22px}
.drawer-x{position:absolute;top:14px;right:14px;background:rgba(255,255,255,.14);border:none;color:#fff;
  width:30px;height:30px;border-radius:50%;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center}
.drawer-head-title{color:#fff;font-size:15px;font-weight:700;margin-bottom:16px}
.drawer-user{display:flex;align-items:center;gap:14px}
.drawer-ava{width:64px;height:64px;border-radius:50%;flex-shrink:0;object-fit:cover;
  background:linear-gradient(135deg,#a3c93a,${c.C.orange});display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:26px;font-weight:800}
.drawer-login-btn{margin-top:8px;background:${c.C.orange};color:#fff;border:none;font-size:12px;font-weight:800;
  padding:7px 14px;border-radius:20px;cursor:pointer}
.drawer-name{color:#fff;font-size:19px;font-weight:800;line-height:1.1}
.drawer-mail{color:#a9cdbf;font-size:12px;margin-top:3px}
.drawer-tier{display:inline-block;margin-top:7px;background:${c.C.orange};color:#fff;font-size:10px;font-weight:800;
  padding:3px 11px;border-radius:20px;letter-spacing:.4px}
.drawer-stats{display:flex;gap:10px;padding:14px 16px 4px}
.dstat{flex:1;background:#fff;border-radius:14px;padding:12px 6px;text-align:center;box-shadow:0 2px 10px rgba(13,59,46,.06)}
.dstat b{display:block;font-size:19px;font-weight:800;color:${c.C.ink}}
.dstat span{font-size:10px;color:${c.C.muted}}
.drawer-menu{padding:12px 16px 26px;display:flex;flex-direction:column;gap:0}
.drawer-item{display:flex;align-items:center;gap:13px;background:#fff;border:none;
  border-bottom:1px solid ${c.C.line};padding:15px 14px;cursor:pointer;text-align:left;width:100%}
.drawer-item:first-child{border-radius:14px 14px 0 0}
.drawer-item:last-child{border-radius:0 0 14px 14px;border-bottom:none}
.di-ic{font-size:18px;width:24px;text-align:center}
.di-label{flex:1;font-size:14px;font-weight:600;color:${c.C.ink}}
.drawer-item.logout{margin-top:14px;border-radius:14px}
.drawer-item.logout .di-label{color:#d64545}
.di-arrow{color:#c2cfc8;font-size:18px;font-weight:700}
      `})]})}console.log("dnjddb");let g=[{key:"healthy",emoji:"\uD83E\uDD57",title:"Healthy / High Protein",sub:"Diet bowls, protein meals",match:e=>/health|protein|salad|bowl|diet/i.test(e.name)},{key:"indian",emoji:"\uD83C\uDF5B",title:"Indian Food",sub:"Thali, rajma chawal, sabzi",match:e=>/thali|indian|combo|meal|rice|dal|sabzi/i.test(e.name)},{key:"fast",emoji:"\uD83C\uDF54",title:"Fast Food",sub:"Snacks, quick bites",match:e=>/fast|snack|burger|wrap|roll|quick/i.test(e.name)},{key:"surprise",emoji:"\uD83D\uDE0B",title:"Surprise me!",sub:"Aaj ka best dikha do",match:()=>!1}];function m({onDone:e}){let[a,i]=(0,r.useState)(null),[s,n]=(0,r.useState)(!1),[o,l]=(0,r.useState)(!1);return(0,t.jsxs)("div",{className:`intro-wrap ${s?"intro-leave":""}`,children:[(0,t.jsx)("div",{className:"intro-amb","aria-hidden":!0,children:["\uD83C\uDF5B","\uD83E\uDD57","\uD83E\uDED3","\uD83E\uDDC3","\uD83C\uDF6E"].map((e,a)=>(0,t.jsx)("span",{className:`amb a${a}`,children:e},a))}),(0,t.jsxs)("div",{className:"intro-inner",children:[(0,t.jsxs)("div",{className:"intro-brand",children:[(0,t.jsx)("span",{className:"brandmark",children:"B"}),(0,t.jsx)("span",{children:"Bite Theory"}),(0,t.jsx)("button",{className:"intro-skip",onClick:()=>e(null),children:"Skip →"})]}),(0,t.jsxs)("div",{className:"intro-avatar-stage",children:[(0,t.jsx)("div",{className:"intro-glow"}),o?(0,t.jsx)("div",{className:"intro-avatar-fallback",children:"\uD83E\uDDD1‍\uD83C\uDF73"}):(0,t.jsx)("img",{src:c.w7,alt:"Theory Bhaiya",className:"intro-avatar",onError:()=>l(!0)}),(0,t.jsx)("span",{className:"intro-wave",children:"\uD83D\uDC4B"}),(0,t.jsx)("span",{className:"intro-badge",children:"YOUR BITE AGENT \uD83E\uDDEA"})]}),(0,t.jsxs)("div",{className:"intro-bubble",children:[(0,t.jsx)("div",{className:"intro-bubble-title",children:"Hello! Main hoon aapka Bite Agent \uD83D\uDE04"}),(0,t.jsx)("div",{className:"intro-bubble-sub",children:"Bhaiyaaa, aaj kya khaane ka mann hai? Bata do, main perfect cheez dikha deta hoon!"})]}),(0,t.jsx)("div",{className:"intro-goals",children:g.map(r=>(0,t.jsxs)("button",{className:`intro-goal ${a===r.key?"sel":""}`,onClick:()=>{i(r.key),n(!0),setTimeout(()=>e(r),420)},children:[(0,t.jsx)("span",{className:"ig-emoji",children:r.emoji}),(0,t.jsxs)("span",{className:"ig-text",children:[(0,t.jsx)("span",{className:"ig-title",children:r.title}),(0,t.jsx)("span",{className:"ig-sub",children:r.sub})]}),(0,t.jsx)("span",{className:"ig-arrow",children:a===r.key?"✓":"›"})]},r.key))})]}),(0,t.jsx)("style",{children:`
.intro-wrap{position:fixed;top:0;bottom:0;left:50%;transform:translateX(-50%);
  width:100%;max-width:480px;z-index:100;
  background:linear-gradient(165deg,${c.C.dark} 0%,${c.C.darkSoft} 55%,#1a6349 100%);
  display:flex;justify-content:center;animation:fadeIn .4s ease;overflow:hidden}
@media(min-width:520px){.intro-wrap{top:18px;bottom:18px;height:calc(100vh - 36px);border-radius:30px}}
.intro-leave{animation:fadeOut .42s ease forwards}
.intro-amb{position:absolute;inset:0;pointer-events:none}
.amb{position:absolute;opacity:.15;font-size:24px}
.amb.a0{top:7%;left:10%;animation:floatA 5s ease-in-out infinite}
.amb.a1{top:12%;right:11%;animation:floatB 6s ease-in-out infinite}
.amb.a2{top:42%;left:7%;animation:floatA 7s ease-in-out infinite}
.amb.a3{top:38%;right:8%;animation:floatB 6.5s ease-in-out infinite}
.amb.a4{bottom:20%;left:14%;animation:floatA 5.5s ease-in-out infinite}
.intro-inner{position:relative;width:100%;max-width:430px;padding:20px 22px 26px;
  display:flex;flex-direction:column;min-height:100%;overflow-y:auto}
.intro-brand{display:flex;align-items:center;gap:8px;color:#fff;font-weight:700;font-size:14px}
.intro-brand .brandmark{width:28px;height:28px;font-size:15px}
.intro-skip{margin-left:auto;background:none;border:none;color:#8fb3a3;font-size:12px;cursor:pointer}
.intro-avatar-stage{position:relative;height:230px;display:flex;align-items:flex-end;justify-content:center;margin-top:6px}
.intro-glow{position:absolute;top:10%;left:50%;transform:translateX(-50%);width:230px;height:230px;border-radius:50%;
  background:radial-gradient(circle,rgba(76,175,80,.45),transparent 68%)}
.intro-avatar{position:relative;max-height:230px;width:auto;object-fit:contain;
  filter:drop-shadow(0 14px 22px rgba(0,0,0,.32));animation:bob 3.2s ease-in-out infinite}
.intro-avatar-fallback{display:flex;align-items:flex-end;justify-content:center;font-size:150px;line-height:1;
  position:relative;animation:bob 3.2s ease-in-out infinite}
.intro-wave{position:absolute;top:18px;right:24%;font-size:30px;animation:wave 1.3s ease-in-out infinite;transform-origin:bottom}
.intro-badge{position:absolute;bottom:-4px;left:50%;transform:translateX(-50%);
  background:${c.C.orange};color:#fff;font-size:10px;padding:4px 14px;border-radius:20px;white-space:nowrap;
  animation:pulse 2s ease-in-out infinite}
.intro-bubble{background:rgba(255,255,255,.97);border-radius:18px 18px 18px 5px;padding:14px 16px;margin:22px 0 14px;
  box-shadow:0 8px 24px rgba(0,0,0,.18)}
.intro-bubble-title{font-size:16px;font-weight:700;color:${c.C.ink};line-height:1.3}
.intro-bubble-sub{font-size:12.5px;color:#3a5a4d;margin-top:5px;line-height:1.4}
.intro-goals{display:flex;flex-direction:column;gap:9px;margin-top:auto}
.intro-goal{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.97);
  border:2px solid transparent;border-radius:14px;padding:12px 14px;cursor:pointer;text-align:left;
  transition:transform .12s,border-color .12s}
.intro-goal:active{transform:scale(.98)}
.intro-goal.sel{border-color:${c.C.green}}
.ig-emoji{font-size:24px}
.ig-text{flex:1;display:flex;flex-direction:column;min-width:0}
.ig-title{font-size:14px;font-weight:700;color:${c.C.ink}}
.ig-sub{font-size:11px;color:${c.C.muted}}
.ig-arrow{color:${c.C.green};font-size:18px;font-weight:700}
@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
@keyframes wave{0%,100%{transform:rotate(0)}50%{transform:rotate(22deg)}}
@keyframes floatA{0%,100%{transform:translateY(0)}50%{transform:translateY(-13px)}}
@keyframes floatB{0%,100%{transform:translateY(0)}50%{transform:translateY(11px)}}
@keyframes pulse{0%,100%{transform:translateX(-50%) scale(1)}50%{transform:translateX(-50%) scale(1.05)}}
@keyframes fadeOut{0%{opacity:1}100%{opacity:0;visibility:hidden}}
      `})]})}var h=i(3321),f=i(8880);let b=[{greet:"Aur bhaiyooo, kaise ho? \uD83D\uDE04",push:"Ye try kiya? Ek number hai —"},{greet:"Bhaiyyaaa, bhookh lagi kya? \uD83D\uDE0B",push:"Hamare yaha ka ye dekho —"},{greet:"Aaiye aaiye! \uD83D\uDE4F",push:"Aaj ye special bana hai —"},{greet:"Arre wah, aap aa gaye! \uD83E\uDD29",push:"Ye to aapke liye perfect hai —"}];function u({product:e,line:a,inCart:i,hasCart:s,onOrder:n,onClose:o}){let[l,d]=(0,r.useState)(!1),p=(0,h.useRouter)(),x=(0,c.jQ)(e);return(0,t.jsxs)("div",{className:`agent-wrap ${s?"has-cart":""}`,role:"dialog","aria-label":"Today's special",children:[(0,t.jsxs)("div",{className:"agent-card",children:[(0,t.jsxs)("div",{className:"agent-ribbon",children:[(0,t.jsx)("span",{className:"agent-spark",children:"✨"}),"TODAY'S SPECIAL"]}),(0,t.jsxs)("div",{className:"agent-head",children:[(0,t.jsx)("span",{className:"agent-face",children:l?(0,t.jsx)("span",{className:"agent-face-fb",children:"\uD83E\uDDD1‍\uD83C\uDF73"}):(0,t.jsx)("img",{src:c.CY,alt:"Theory Bhaiya",onError:()=>d(!0)})}),(0,t.jsxs)("div",{className:"agent-id",children:[(0,t.jsx)("div",{className:"agent-name",children:"Theory Bhaiya"}),(0,t.jsxs)("div",{className:"agent-online",children:[(0,t.jsx)("i",{className:"dot"})," online \xb7 aapke liye"]})]}),(0,t.jsx)("button",{className:"agent-x",onClick:o,"aria-label":"Close",children:"✕"})]}),(0,t.jsxs)("div",{className:"agent-body",children:[(0,t.jsxs)("div",{className:"agent-bubble",children:[(0,t.jsx)("div",{className:"agent-greet",children:a.greet}),(0,t.jsxs)("div",{className:"agent-push",children:[a.push," ",(0,t.jsx)("b",{children:e.name})," \uD83C\uDF5B"]})]}),(0,t.jsxs)("div",{className:"agent-prod",onClick:()=>p.push(`/product/${e.id}`),style:{cursor:"pointer"},children:[(0,t.jsxs)("div",{className:"agent-prod-img",children:[(0,t.jsx)(f.A,{src:e.image,alt:e.name,emoji:(0,c.dL)(e.name)}),(0,t.jsx)("span",{className:"veg-dot sm",children:(0,t.jsx)("i",{})})]}),(0,t.jsxs)("div",{className:"agent-prod-info",children:[(0,t.jsx)("div",{className:"agent-prod-name",children:e.name}),(0,t.jsxs)("div",{className:"agent-prod-tags",children:[e.calories>0&&(0,t.jsxs)("span",{className:"tag",children:[e.calories," cal"]}),e.protein>0&&(0,t.jsxs)("span",{className:"tag green",children:[e.protein,"g protein"]})]}),(0,t.jsxs)("div",{className:"agent-prod-price",children:[(0,t.jsx)("b",{children:(0,c.TG)((0,c.ns)(e))}),x&&(0,t.jsx)("s",{children:(0,c.TG)(e.price)}),x&&(0,t.jsxs)("span",{className:"agent-off",children:[(0,c.KE)(e),"% OFF"]})]})]})]}),(0,t.jsxs)("div",{className:"agent-actions",children:[(0,t.jsx)("button",{className:"agent-order",onClick:n,children:i?"Add one more \uD83D\uDED2":"Order Now \uD83D\uDED2"}),(0,t.jsx)("button",{className:"agent-see",onClick:()=>p.push(`/product/${e.id}`),children:"Dekho →"})]})]})]}),(0,t.jsx)("style",{children:`
.agent-wrap{position:absolute;left:0;right:0;bottom:70px;padding:0 12px;z-index:26;pointer-events:none}
.agent-wrap.has-cart{bottom:122px}
.agent-card{pointer-events:auto;background:#fff;border-radius:20px;
  box-shadow:0 18px 50px rgba(13,59,46,.30);overflow:hidden;
  animation:popIn .5s cubic-bezier(.2,.9,.3,1.2);border:1px solid #d9efdc}
.agent-ribbon{background:linear-gradient(90deg,${c.C.orange},#f7a73a);color:#fff;font-size:10.5px;font-weight:800;
  letter-spacing:.8px;padding:5px 14px;display:flex;align-items:center;gap:6px}
.agent-spark{font-size:11px}
.agent-head{background:linear-gradient(135deg,${c.C.green},#3b8c3f);padding:10px 13px;display:flex;align-items:center;gap:10px}
.agent-face{width:34px;height:34px;border-radius:50%;background:#fff;overflow:hidden;flex-shrink:0;
  animation:bob 2.4s ease-in-out infinite;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.18)}
.agent-face img{width:100%;height:100%;object-fit:cover}
.agent-face-fb{font-size:19px}
.agent-id{flex:1;min-width:0}
.agent-name{color:#fff;font-size:13px;font-weight:700}
.agent-online{color:#d6f5e0;font-size:9px;display:flex;align-items:center;gap:4px}
.agent-online .dot{width:6px;height:6px;border-radius:50%;background:#aef5c0;display:inline-block;animation:pulseDot 1.6s ease-in-out infinite}
.agent-x{background:rgba(255,255,255,.18);border:none;color:#fff;font-size:13px;width:24px;height:24px;border-radius:50%;
  cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.agent-body{padding:12px 13px}
.agent-bubble{background:${c.C.bg};border-radius:13px 13px 13px 4px;padding:10px 12px;margin-bottom:10px}
.agent-greet{font-size:13.5px;color:${c.C.ink};font-weight:700}
.agent-push{font-size:12px;color:#3a5a4d;margin-top:2px}
.agent-prod{display:flex;gap:11px;background:#fff;border:1.5px solid ${c.C.greenSoft};border-radius:14px;padding:9px;align-items:center}
.agent-prod-img{width:58px;height:58px;border-radius:12px;background:${c.C.orangeSoft};display:flex;align-items:center;
  justify-content:center;flex-shrink:0;position:relative;overflow:hidden}
.agent-prod-img img{width:100%;height:100%;object-fit:cover}
.agent-prod-img .food-emoji{font-size:28px}
.agent-prod-info{flex:1;min-width:0}
.agent-prod-name{font-size:13px;font-weight:700;color:${c.C.ink};white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.agent-prod-tags{display:flex;gap:4px;margin:3px 0 4px;flex-wrap:wrap}
.agent-prod-price{display:flex;align-items:center;flex-wrap:wrap}
.agent-prod-price b{font-size:15px;font-weight:800}
.agent-prod-price s{font-size:10px;color:#9aa8a0;margin-left:5px}
.agent-off{font-size:8.5px;background:${c.C.orangeSoft};color:${c.C.orangeDeep};padding:2px 6px;border-radius:5px;font-weight:800;margin-left:6px}
.agent-actions{display:flex;gap:8px;margin-top:11px}
.agent-order{flex:1;background:linear-gradient(135deg,${c.C.green},${c.C.greenDeep});color:#fff;border:none;font-size:13px;
  font-weight:800;padding:11px;border-radius:11px;cursor:pointer;box-shadow:0 6px 16px rgba(76,175,80,.35)}
.agent-see{background:#fff;color:${c.C.ink};border:1.5px solid ${c.C.line};font-size:13px;font-weight:700;padding:11px 15px;border-radius:11px;cursor:pointer}
@keyframes popIn{0%{transform:translateY(40px) scale(.96);opacity:0}100%{transform:translateY(0) scale(1);opacity:1}}
@keyframes pulseDot{0%,100%{opacity:1}50%{opacity:.4}}
@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
      `})]})}var j=i(9334),w=i(8914);let y="force-dynamic";function k(){let{products:e,categories:a,loading:i,error:d}=(0,j.d)(),{add:p,cart:g}=(0,w._)(),[h,f]=(0,r.useState)("all"),[y,k]=(0,r.useState)("pop"),[N,v]=(0,r.useState)(!1),[C,z]=(0,r.useState)(!1),[$,S]=(0,r.useState)(null),[A,T]=(0,r.useState)(null),[E,B]=(0,r.useState)(!1),[Y]=(0,r.useState)(()=>Math.floor(Math.random()*b.length));function P(){B(!0);try{sessionStorage.setItem("bt_special_closed","1")}catch{}}(0,r.useEffect)(()=>{try{localStorage.getItem("bt_intro_seen")!==new Date().toDateString()&&z(!0)}catch{z(!0)}try{"1"===sessionStorage.getItem("bt_special_closed")&&B(!0)}catch{}},[]),(0,r.useEffect)(()=>{if(!$||"surprise"===$.key||!a.length)return;let e=a.find(e=>$.match(e));e&&f(e.id)},[$,a]),(0,r.useEffect)(()=>{if(i||!e.length||E)return;let a=setTimeout(()=>{T(e.filter(e=>e.offerPrice>0&&e.offerPrice<e.price).sort((e,a)=>a.price-a.offerPrice-(e.price-e.offerPrice))[0]||e[0])},2800);return()=>clearTimeout(a)},[i,e,E]);let I=(0,r.useMemo)(()=>{let a=[..."all"===h?e:e.filter(e=>e.categoryId===h)];return"protein"===y?a.sort((e,a)=>a.protein-e.protein):"lowcal"===y?a.sort((e,a)=>e.calories-a.calories):"cheap"===y?a.sort((e,a)=>(e.offerPrice||e.price)-(a.offerPrice||a.price)):a.sort((e,a)=>a.rating-e.rating),a},[e,h,y]);return(0,t.jsxs)(s.A,{header:(0,t.jsx)(n.A,{variant:"home",showSearch:!0,onMenu:()=>v(!0),onAskBhaiya:()=>z(!0)}),footerExtra:(0,t.jsx)(l.A,{}),overlay:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(x,{open:N,onClose:()=>v(!1)}),A&&!E&&(0,t.jsx)(u,{product:A,line:b[Y],inCart:(g[A.id]||0)>0,hasCart:Object.keys(g).length>0,onOrder:()=>{p(A.id),P()},onClose:P}),C&&(0,t.jsx)(m,{onDone:function(e){S(e),z(!1);try{localStorage.setItem("bt_intro_seen",new Date().toDateString())}catch{}e&&"surprise"!==e.key&&setTimeout(()=>{document.getElementById("catrow")?.scrollIntoView({behavior:"smooth",block:"start"})},350)}})]}),children:[(0,t.jsxs)("section",{className:"bt-hero",children:[(0,t.jsx)("span",{className:"bt-veg-badge",children:"100% PURE VEG"}),(0,t.jsxs)("h1",{className:"bt-hero-title",children:["Smart Food.",(0,t.jsx)("br",{}),"Better Living."]}),(0,t.jsx)("p",{className:"bt-hero-sub",children:"Good food. Right price. Under ₹99 combos."})]}),(0,t.jsx)("section",{className:"bt-cats",id:"catrow",children:(0,t.jsxs)("div",{className:"bt-cat-scroll",children:[(0,t.jsxs)("button",{className:`bt-cat ${"all"===h?"on":""}`,onClick:()=>f("all"),children:[(0,t.jsx)("span",{className:"bt-cat-ic",style:{background:c.C.orangeSoft},children:"\uD83C\uDF7D️"}),(0,t.jsx)("span",{className:"bt-cat-lbl",children:"All"})]}),i?Array.from({length:5}).map((e,a)=>(0,t.jsxs)("div",{className:"bt-cat",children:[(0,t.jsx)("span",{className:"bt-cat-ic skel"}),(0,t.jsx)("span",{className:"bt-cat-lbl skel-txt"})]},a)):a.map((e,a)=>(0,t.jsxs)("button",{className:`bt-cat ${h===e.id?"on":""}`,onClick:()=>f(e.id),children:[(0,t.jsx)("span",{className:"bt-cat-ic",style:{background:a%2?c.C.greenSoft:c.C.orangeSoft},children:e.image?(0,t.jsx)("img",{src:e.image,alt:e.name}):e.emoji}),(0,t.jsx)("span",{className:"bt-cat-lbl",children:e.name})]},e.id))]})}),(0,t.jsxs)("section",{className:"bt-offers",children:[(0,t.jsxs)("div",{className:"bt-offer dark",children:[(0,t.jsx)("span",{className:"bt-offer-ic",style:{background:c.C.orange},children:"%"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"bt-offer-t",children:"70% OFF up to ₹100"}),(0,t.jsx)("div",{className:"bt-offer-s",children:"USE BITE70"})]})]}),(0,t.jsxs)("div",{className:"bt-offer soft",children:[(0,t.jsx)("span",{className:"bt-offer-ic",style:{background:c.C.green},children:"\uD83C\uDF5B"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"bt-offer-t",style:{color:"#854f0b"},children:"Thali at ₹99"}),(0,t.jsx)("div",{className:"bt-offer-s",style:{color:"#ba7517"},children:"TODAY ONLY"})]})]})]}),(0,t.jsx)("section",{className:"bt-filters",children:[["pop","Sort by"],["protein","High Protein"],["lowcal","Under 400 cal"],["cheap","Cheapest"]].map(([e,a])=>(0,t.jsx)("button",{className:`bt-chip ${y===e?"on":""}`,onClick:()=>k(e),children:a},e))}),(0,t.jsxs)("section",{className:"bt-products",children:[(0,t.jsx)("h2",{className:"bt-sec-title",children:"all"===h?"Popular near you":a.find(e=>e.id===h)?.name||"Menu"}),d&&(0,t.jsx)("div",{className:"bt-empty",children:d}),i?Array.from({length:4}).map((e,a)=>(0,t.jsxs)("div",{className:"bt-card",children:[(0,t.jsx)("div",{className:"bt-card-img skel"}),(0,t.jsxs)("div",{className:"bt-card-body",children:[(0,t.jsx)("div",{className:"skel-txt",style:{width:"60%"}}),(0,t.jsx)("div",{className:"skel-txt",style:{width:"90%"}}),(0,t.jsx)("div",{className:"skel-txt",style:{width:"40%"}})]})]},a)):0===I.length?(0,t.jsx)("div",{className:"bt-empty",children:"Is category mein abhi kuch nahi hai. Doosri dekho!"}):I.map(e=>(0,t.jsx)(o.A,{p:e},e.id))]}),(0,t.jsx)("div",{style:{height:16}})]})}},7146:(e,a,i)=>{Promise.resolve().then(i.bind(i,3592))}},e=>{e.O(0,[882,756,691,531,441,794,358],()=>e(e.s=7146)),_N_E=e.O()}]);