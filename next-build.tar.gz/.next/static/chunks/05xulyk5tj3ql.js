(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,18566,(e,t,o)=>{t.exports=e.r(76562)},7884,e=>{"use strict";var t=e.i(43476),o=e.i(61928);e.s(["default",0,function(){return(0,t.jsx)("style",{children:`
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;max-width:100%;overflow-x:hidden}
a{text-decoration:none;color:inherit}

/* stage = desktop backdrop + centered phone frame */
.bt-stage{height:100vh;min-height:100vh;width:100%;background:
  radial-gradient(900px 600px at 50% -10%, #16604733, transparent 60%),
  ${o.C.dark};
  display:flex;justify-content:center;align-items:stretch;
  padding:0;overflow:hidden}

/* app = full-height flex column: [header][scroll][footer] */
.bt-app{position:relative;width:100%;max-width:480px;background:${o.C.bg};
  height:100vh;max-height:100vh;overflow:hidden;
  display:flex;flex-direction:column;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  color:${o.C.ink}}

.bt-scroll{flex:1 1 auto;overflow-y:auto;overflow-x:hidden;
  -webkit-overflow-scrolling:touch;scrollbar-width:none}
.bt-scroll::-webkit-scrollbar{display:none}

@media(min-width:520px){
  .bt-stage{padding:18px 0;align-items:center}
  .bt-app{height:calc(100vh - 36px);max-height:calc(100vh - 36px);
    margin:0;border-radius:30px;
    box-shadow:0 30px 90px rgba(0,0,0,.5);overflow:hidden}
  .bt-app .bt-head{border-radius:30px 30px 0 0}
}

.brandmark{width:34px;height:34px;border-radius:9px;
  background:linear-gradient(135deg,${o.C.green},${o.C.orange});display:flex;
  align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:18px;flex-shrink:0}

.food-emoji{display:flex;align-items:center;justify-content:center;width:100%;height:100%;font-size:34px;line-height:1}

/* ── header ── */
.bt-head{background:${o.C.dark};padding:14px 16px 16px;flex:0 0 auto;z-index:30}
.bt-head--page{padding:14px 12px}
.bt-head-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:0;gap:10px}
.bt-head .bt-search{margin-top:12px}
.bt-brand{display:flex;align-items:center;gap:9px;min-width:0}
.bt-brand-name{color:#fff;font-weight:700;font-size:15px;line-height:1}
.bt-loc{color:#8fb3a3;font-size:10px;margin-top:2px}
.bt-page-title{color:#fff;font-size:16px;font-weight:700;flex:1;text-align:center}
.bt-head-actions{display:flex;gap:8px;align-items:center;flex-shrink:0}
.bt-bhaiya-btn{border:none;cursor:pointer;border-radius:20px;
  background:linear-gradient(135deg,${o.C.orange},#f7a73a);color:#fff;
  font-size:11.5px;font-weight:800;padding:0 12px;height:36px;white-space:nowrap;
  display:flex;align-items:center;gap:4px;box-shadow:0 4px 12px rgba(245,158,11,.35)}
.bt-bhaiya-label{display:inline}
@media(max-width:360px){.bt-bhaiya-btn{padding:0 10px}.bt-bhaiya-label{display:none}}
.bt-icon-btn{width:36px;height:36px;border-radius:10px;border:none;
  background:rgba(255,255,255,.12);color:#fff;font-size:20px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;transition:background .15s}
.bt-icon-btn:hover{background:rgba(255,255,255,.2)}
.bt-avatar-btn{width:36px;height:36px;border-radius:50%;border:none;
  background:linear-gradient(135deg,#a3c93a,${o.C.orange});color:#fff;font-size:15px;
  font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center}
.bt-search{width:100%;background:#fff;border:none;border-radius:12px;
  padding:11px 13px;display:flex;align-items:center;gap:8px;cursor:pointer;text-align:left}
.bt-search-ph{color:#9aa8a0;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* ── hero ── */
.bt-hero{background:linear-gradient(135deg,${o.C.green},#3b8c3f);
  margin:12px;border-radius:18px;padding:16px}
.bt-veg-badge{display:inline-block;background:rgba(255,255,255,.2);color:#fff;
  font-size:10px;padding:3px 10px;border-radius:20px;margin-bottom:8px;letter-spacing:.5px}
.bt-hero-title{color:#fff;font-size:21px;font-weight:800;line-height:1.2;margin:0}
.bt-hero-sub{color:#eafdea;font-size:12px;margin:6px 0 0}

/* ── categories ── */
.bt-cats{padding:2px 0 0;max-width:100%}
.bt-cat-scroll{display:flex;gap:12px;overflow-x:auto;padding:8px 12px 4px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-cat-scroll::-webkit-scrollbar{display:none}
.bt-cat{flex-shrink:0;background:none;border:none;cursor:pointer;text-align:center;padding:0}
.bt-cat-ic{width:60px;height:60px;border-radius:17px;display:flex;align-items:center;
  justify-content:center;font-size:27px;overflow:hidden;transition:transform .15s}
.bt-cat-ic img{width:100%;height:100%;object-fit:cover}
.bt-cat-ic .food-emoji{font-size:27px}
.bt-cat.on .bt-cat-ic{transform:scale(1.06);box-shadow:0 0 0 2.5px ${o.C.green}}
.bt-cat-lbl{display:block;font-size:11px;color:${o.C.ink};margin-top:5px;max-width:64px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bt-cat.on .bt-cat-lbl{font-weight:700;color:${o.C.green}}

/* ── offers ── */
.bt-offers{display:flex;gap:10px;overflow-x:auto;padding:12px 12px 4px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-offers::-webkit-scrollbar{display:none}
.bt-offer{flex-shrink:0;border-radius:14px;padding:12px 14px;display:flex;align-items:center;gap:10px;min-width:185px}
.bt-offer.dark{background:${o.C.dark}}
.bt-offer.soft{background:${o.C.orangeSoft}}
.bt-offer-ic{width:32px;height:32px;border-radius:9px;display:flex;align-items:center;
  justify-content:center;color:#fff;font-size:16px;font-weight:700;flex-shrink:0}
.bt-offer.dark .bt-offer-t{color:#fff;font-size:13px;font-weight:700}
.bt-offer.dark .bt-offer-s{color:#8fb3a3;font-size:10px}
.bt-offer-t{font-size:13px;font-weight:700}
.bt-offer-s{font-size:10px}

/* ── filters ── */
.bt-filters{display:flex;gap:7px;overflow-x:auto;padding:10px 12px 2px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-filters::-webkit-scrollbar{display:none}
.bt-chip{flex-shrink:0;font-size:11.5px;padding:6px 13px;border-radius:20px;
  border:1px solid ${o.C.line};background:#fff;color:${o.C.ink};cursor:pointer;font-weight:600;white-space:nowrap}
.bt-chip.on{background:${o.C.dark};color:#fff;border-color:${o.C.dark}}

/* ── products ── */
.bt-products{padding:12px 12px 0}
.bt-sec-title{font-size:16px;font-weight:800;margin:4px 0 12px}
.bt-card{display:flex;gap:12px;background:#fff;border:1px solid ${o.C.line};
  border-radius:15px;padding:10px;margin-bottom:11px}
.bt-card-img{width:92px;height:92px;border-radius:11px;background:${o.C.greenSoft};
  display:flex;align-items:center;justify-content:center;flex-shrink:0;position:relative;overflow:hidden}
.bt-card-img img{width:100%;height:100%;object-fit:cover}
.bt-card-img .food-emoji{font-size:40px}
.veg-dot{position:absolute;top:6px;left:6px;width:15px;height:15px;border:1.5px solid ${o.C.green};
  border-radius:3px;background:#fff;display:flex;align-items:center;justify-content:center;z-index:2}
.veg-dot i{width:7px;height:7px;background:${o.C.green};border-radius:50%}
.veg-dot.sm{width:13px;height:13px}
.veg-dot.sm i{width:6px;height:6px}
.bt-card-off{position:absolute;bottom:6px;left:6px;background:${o.C.orange};color:#fff;
  font-size:9px;font-weight:800;padding:2px 6px;border-radius:5px;z-index:2}
.bt-card-body{flex:1;min-width:0;display:flex;flex-direction:column}
.bt-card-name{font-size:14px;font-weight:700}
.bt-card-name-link{color:inherit}
.bt-card-desc{font-size:11px;color:${o.C.muted};margin:2px 0 6px;
  display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}
.bt-card-tags{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:7px}
.tag{font-size:9px;background:${o.C.bg};color:${o.C.muted};padding:2px 6px;border-radius:5px;font-weight:600;white-space:nowrap}
.tag.green{background:${o.C.greenSoft};color:#2e7d32}
.tag.orange{background:${o.C.orangeSoft};color:#b76e00}
.bt-card-foot{display:flex;align-items:center;justify-content:space-between;margin-top:auto;gap:8px}
.bt-price b{font-size:15px;font-weight:800}
.bt-price s{font-size:11px;color:#9aa8a0;margin-left:6px}
.bt-add{background:${o.C.green};color:#fff;border:none;font-size:12px;font-weight:700;
  padding:7px 18px;border-radius:9px;cursor:pointer;letter-spacing:.5px;flex-shrink:0}
.bt-qty{display:flex;align-items:center;gap:10px;background:${o.C.green};border-radius:9px;padding:5px 11px;flex-shrink:0}
.bt-qty button{background:none;border:none;color:#fff;font-size:17px;cursor:pointer;line-height:1;width:14px}
.bt-qty span{color:#fff;font-weight:700;font-size:13px;min-width:12px;text-align:center}
.bt-empty{background:#fff;border:1px dashed ${o.C.line};border-radius:14px;padding:32px 18px;
  text-align:center;color:${o.C.muted};font-size:13px}

/* ── skeletons ── */
.skel{background:linear-gradient(90deg,#eef2ee 25%,#e3e9e3 50%,#eef2ee 75%);
  background-size:200% 100%;animation:sh 1.3s infinite}
.skel-txt{height:11px;border-radius:5px;margin:5px 0;
  background:linear-gradient(90deg,#eef2ee 25%,#e3e9e3 50%,#eef2ee 75%);
  background-size:200% 100%;animation:sh 1.3s infinite}
@keyframes sh{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── footer (cart bar + nav) ── */
.bt-footer{flex:0 0 auto;position:relative;z-index:25}
.bt-cartbar{background:${o.C.green};padding:12px 18px;display:flex;
  align-items:center;justify-content:space-between;animation:slideUpBar .4s ease}
.bt-cartbar-c{color:#eafdea;font-size:11px}
.bt-cartbar-t{color:#fff;font-weight:800;font-size:16px}
.bt-cartbar-btn{background:${o.C.orange};color:#fff;border:none;font-weight:800;
  padding:10px 20px;border-radius:22px;cursor:pointer;font-size:13px}
.bt-nav{background:#fff;border-top:1px solid ${o.C.line};display:flex;justify-content:space-around;
  padding:8px 0 10px}
.bt-nav-i{background:none;border:none;cursor:pointer;display:flex;flex-direction:column;
  align-items:center;gap:1px;color:#9aa8a0;font-size:9px;position:relative}
.bt-nav-ic{font-size:19px;position:relative;display:inline-block}
.bt-nav-i.on{color:${o.C.green}}
.bt-nav-badge{position:absolute;top:-6px;right:-10px;background:${o.C.orange};color:#fff;
  font-style:normal;font-size:9px;font-weight:700;min-width:15px;height:15px;border-radius:8px;
  display:flex;align-items:center;justify-content:center;padding:0 3px}

/* ── generic page bits ── */
.bt-page-pad{padding:14px 12px}
.bt-section-h{font-size:15px;font-weight:800;margin:18px 12px 10px}

/* ── product detail ── */
.pd-hero{position:relative;width:100%;aspect-ratio:1/1;max-height:340px;background:${o.C.greenSoft};
  display:flex;align-items:center;justify-content:center;overflow:hidden}
.pd-hero img{width:100%;height:100%;object-fit:cover}
.pd-hero .food-emoji{font-size:120px}
.pd-hero-off{position:absolute;top:14px;left:14px;background:${o.C.orange};color:#fff;
  font-size:12px;font-weight:800;padding:5px 12px;border-radius:8px}
.pd-veg{position:absolute;top:14px;right:14px;width:22px;height:22px;border:2px solid ${o.C.green};
  border-radius:4px;background:#fff;display:flex;align-items:center;justify-content:center}
.pd-veg i{width:10px;height:10px;background:${o.C.green};border-radius:50%}
.pd-body{padding:16px 16px 0}
.pd-name{font-size:22px;font-weight:800;line-height:1.2}
.pd-rating{display:inline-flex;align-items:center;gap:4px;background:${o.C.greenSoft};
  color:${o.C.greenDeep};font-size:12px;font-weight:700;padding:3px 9px;border-radius:8px;margin-top:8px}
.pd-desc{font-size:13.5px;color:#3a5a4d;line-height:1.5;margin:12px 0 4px}
.pd-price{display:flex;align-items:baseline;gap:10px;margin:14px 0 4px}
.pd-price b{font-size:26px;font-weight:800}
.pd-price s{font-size:15px;color:#9aa8a0}
.pd-price .pd-save{font-size:12px;font-weight:800;color:${o.C.greenDeep};background:${o.C.greenSoft};
  padding:3px 9px;border-radius:7px}
.pd-macros{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0 6px}
.pd-macro{background:#fff;border:1px solid ${o.C.line};border-radius:13px;padding:12px 6px;text-align:center}
.pd-macro b{display:block;font-size:17px;font-weight:800;color:${o.C.ink}}
.pd-macro span{font-size:10px;color:${o.C.muted}}
.pd-macro.cal b{color:${o.C.orange}}
.pd-macro.pro b{color:${o.C.green}}

/* ── cart ── */
.cart-item{display:flex;gap:12px;background:#fff;border:1px solid ${o.C.line};
  border-radius:15px;padding:10px;margin-bottom:11px;align-items:center}
.cart-item-img{width:70px;height:70px;border-radius:11px;background:${o.C.greenSoft};
  display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;position:relative}
.cart-item-img img{width:100%;height:100%;object-fit:cover}
.cart-item-img .food-emoji{font-size:30px}
.cart-item-info{flex:1;min-width:0}
.cart-item-name{font-size:14px;font-weight:700}
.cart-item-price{font-size:13px;color:${o.C.muted};margin-top:2px}
.cart-item-price b{color:${o.C.ink}}
.cart-remove{background:none;border:none;color:#c0392b;font-size:11px;cursor:pointer;margin-top:4px;padding:0}
.bill{background:#fff;border:1px solid ${o.C.line};border-radius:15px;padding:14px;margin-top:6px}
.bill-row{display:flex;justify-content:space-between;font-size:13px;color:#3a5a4d;margin-bottom:8px}
.bill-row.free{color:${o.C.green};font-weight:700}
.bill-hr{border:none;border-top:1px dashed ${o.C.line};margin:10px 0}
.bill-total{display:flex;justify-content:space-between;font-size:16px;font-weight:800;color:${o.C.ink}}
.coupon{display:flex;gap:8px;align-items:center;background:${o.C.orangeSoft};border:1px dashed ${o.C.orange};
  border-radius:12px;padding:10px 12px;margin:12px 0;font-size:12px;color:${o.C.orangeDeep};font-weight:700}
.checkout-bar{padding:12px 16px;background:#fff;border-top:1px solid ${o.C.line};
  display:flex;align-items:center;justify-content:space-between;gap:12px}
.checkout-total b{font-size:18px;font-weight:800}
.checkout-total span{display:block;font-size:11px;color:${o.C.muted}}
.checkout-btn{flex:1;max-width:200px;background:linear-gradient(135deg,${o.C.green},${o.C.greenDeep});
  color:#fff;border:none;font-size:15px;font-weight:800;padding:13px;border-radius:13px;cursor:pointer;
  box-shadow:0 6px 16px rgba(76,175,80,.35)}

/* ── orders ── */
.order-card{background:#fff;border:1px solid ${o.C.line};border-radius:15px;padding:14px;margin-bottom:12px}
.order-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}
.order-id{font-size:13px;font-weight:800}
.order-date{font-size:11px;color:${o.C.muted};margin-top:2px}
.order-status{font-size:10px;font-weight:800;padding:4px 10px;border-radius:20px;white-space:nowrap}
.order-status.placed{background:${o.C.orangeSoft};color:${o.C.orangeDeep}}
.order-status.preparing{background:${o.C.orangeSoft};color:${o.C.orangeDeep}}
.order-status.on_the_way{background:#e3f2fd;color:#1565c0}
.order-status.delivered{background:${o.C.greenSoft};color:${o.C.greenDeep}}
.order-items{display:flex;flex-direction:column;gap:6px}
.order-line{display:flex;justify-content:space-between;font-size:12.5px;color:#3a5a4d}
.order-foot{display:flex;justify-content:space-between;align-items:center;
  border-top:1px dashed ${o.C.line};margin-top:10px;padding-top:10px}
.order-total{font-size:14px;font-weight:800}
.order-reorder{background:${o.C.greenSoft};color:${o.C.greenDeep};border:none;font-size:12px;
  font-weight:700;padding:7px 14px;border-radius:9px;cursor:pointer}

/* ── menu page ── */
.menu-jump{display:flex;gap:7px;overflow-x:auto;padding:10px 12px;scrollbar-width:none;
  position:sticky;top:0;background:${o.C.bg};z-index:5}
.menu-jump::-webkit-scrollbar{display:none}
.menu-jump-chip{flex-shrink:0;font-size:11.5px;padding:6px 13px;border-radius:20px;
  border:1px solid ${o.C.line};background:#fff;color:${o.C.ink};cursor:pointer;font-weight:600;white-space:nowrap}
.menu-jump-chip.on{background:${o.C.dark};color:#fff;border-color:${o.C.dark}}
.menu-cat-h{display:flex;align-items:center;gap:8px;font-size:16px;font-weight:800;
  margin:18px 12px 10px;scroll-margin-top:60px}
.menu-cat-h .cnt{font-size:11px;font-weight:600;color:${o.C.muted}}

/* toast */
.toast{position:absolute;bottom:78px;left:50%;transform:translateX(-50%);
  background:${o.C.dark};color:#fff;font-size:13px;font-weight:600;padding:11px 18px;border-radius:24px;
  box-shadow:0 10px 30px rgba(0,0,0,.3);z-index:50;animation:toastIn .3s ease;white-space:nowrap}

/* keyframes */
@keyframes slideUpBar{0%{transform:translateY(100px)}100%{transform:translateY(0)}}
@keyframes toastIn{0%{transform:translate(-50%,20px);opacity:0}100%{transform:translate(-50%,0);opacity:1}}
@keyframes fadeIn{0%{opacity:0}100%{opacity:1}}

@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
    `})}])},35023,e=>{"use strict";var t=e.i(43476),o=e.i(71645),r=e.i(17255),i=e.i(18566),n=e.i(61928),a=e.i(7884);e.s(["default",0,function(){let{data:e,status:p,update:d}=(0,r.useSession)(),s=(0,i.useRouter)(),[l,c]=(0,o.useState)(""),[x,f]=(0,o.useState)(!1),[g,b]=(0,o.useState)(""),h=e?.user;async function u(){b("");let e=l.replace(/\D/g,"").slice(-10);if(10!==e.length)return void b("Please enter a valid 10-digit mobile number");f(!0);try{let t=await fetch("/account/profile",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({mobile:e})});if(!t.ok){let e=await t.json().catch(()=>({}));throw Error(e.error||"Could not save")}await d(),s.replace("/")}catch(e){b(e.message||"Something went wrong"),f(!1)}}return(0,o.useEffect)(()=>{"unauthenticated"===p&&s.replace("/login"),"authenticated"===p&&h?.profileComplete&&s.replace("/")},[p,h,s]),(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(a.default,{}),(0,t.jsx)("div",{className:"bt-stage",children:(0,t.jsxs)("main",{className:"bt-app",style:{background:n.C.bg},children:[(0,t.jsx)("header",{className:"bt-head",children:(0,t.jsx)("div",{className:"bt-head-row",children:(0,t.jsxs)("div",{className:"bt-brand",children:[(0,t.jsx)("span",{className:"brandmark",children:"B"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"bt-brand-name",children:"Bite Theory"}),(0,t.jsx)("div",{className:"bt-loc",children:"📍 Indore"})]})]})})}),(0,t.jsx)("div",{className:"bt-scroll",children:(0,t.jsxs)("div",{style:{padding:"28px 22px"},children:[(0,t.jsx)("div",{style:{fontSize:46,marginBottom:6},children:"📱"}),(0,t.jsxs)("h1",{style:{fontSize:22,fontWeight:800,margin:"0 0 6px",color:n.C.ink},children:["One last step",h?.name?`, ${h.name.split(" ")[0]}`:"","!"]}),(0,t.jsx)("p",{style:{fontSize:13.5,color:n.C.muted,margin:"0 0 22px",lineHeight:1.5},children:"Add your mobile number so we (and Theory Bhaiya 🧪) can reach you about your orders & delivery."}),(0,t.jsx)("label",{style:{fontSize:12,fontWeight:700,color:n.C.ink,display:"block",marginBottom:7},children:"Mobile number"}),(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center",background:"#fff",border:`1.5px solid ${g?"#e57373":n.C.line}`,borderRadius:13,overflow:"hidden"},children:[(0,t.jsx)("span",{style:{padding:"13px 12px",background:n.C.greenSoft,color:n.C.greenDeep,fontWeight:700,fontSize:14},children:"+91"}),(0,t.jsx)("input",{type:"tel",inputMode:"numeric",placeholder:"98765 43210",value:l,onChange:e=>c(e.target.value.replace(/[^\d]/g,"").slice(0,10)),style:{flex:1,border:"none",outline:"none",padding:"13px 12px",fontSize:15,color:n.C.ink}})]}),g&&(0,t.jsx)("div",{style:{color:"#c0392b",fontSize:12,marginTop:7},children:g}),(0,t.jsx)("button",{onClick:u,disabled:x,style:{width:"100%",marginTop:22,background:`linear-gradient(135deg,${n.C.green},${n.C.greenDeep})`,color:"#fff",border:"none",fontSize:15,fontWeight:800,padding:14,borderRadius:13,cursor:"pointer",boxShadow:"0 6px 16px rgba(76,175,80,.35)"},children:x?"Saving…":"Continue →"}),(0,t.jsx)("button",{onClick:()=>s.replace("/"),style:{width:"100%",marginTop:10,background:"none",border:"none",color:n.C.muted,fontSize:13,cursor:"pointer"},children:"Skip for now"})]})})]})})]})},"dynamic",0,"force-dynamic"])}]);