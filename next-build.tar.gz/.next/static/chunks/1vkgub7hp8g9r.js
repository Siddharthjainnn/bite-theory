(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,18566,(e,t,r)=>{t.exports=e.r(76562)},7884,e=>{"use strict";var t=e.i(43476),r=e.i(61928);e.s(["default",0,function(){return(0,t.jsx)("style",{children:`
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;max-width:100%;overflow-x:hidden}
a{text-decoration:none;color:inherit}

/* stage = desktop backdrop + centered phone frame */
.bt-stage{height:100vh;min-height:100vh;width:100%;background:
  radial-gradient(900px 600px at 50% -10%, #16604733, transparent 60%),
  ${r.C.dark};
  display:flex;justify-content:center;align-items:stretch;
  padding:0;overflow:hidden}

/* app = full-height flex column: [header][scroll][footer] */
.bt-app{position:relative;width:100%;max-width:480px;background:${r.C.bg};
  height:100vh;max-height:100vh;overflow:hidden;
  display:flex;flex-direction:column;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  color:${r.C.ink}}

.bt-scroll{flex:1 1 auto;overflow-y:auto;overflow-x:hidden;
  -webkit-overflow-scrolling:touch;scrollbar-width:none}
.bt-scroll::-webkit-scrollbar{display:none}

@media(min-width:520px){
  .bt-stage{padding:18px 0;align-items:center}
  .bt-app{height:calc(100vh - 36px);max-height:calc(100vh - 36px);
    margin:0;border-radius:30px;
    box-shadow:0 30px 90px rgba(0,0,0,.5);overflow:hidden}
  .bt-app .bt-head{border-radius:30px 30px 0 0}
}

.brandmark{width:34px;height:34px;border-radius:9px;
  background:linear-gradient(135deg,${r.C.green},${r.C.orange});display:flex;
  align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:18px;flex-shrink:0}

.food-emoji{display:flex;align-items:center;justify-content:center;width:100%;height:100%;font-size:34px;line-height:1}

/* ── header ── */
.bt-head{background:${r.C.dark};padding:14px 16px 16px;flex:0 0 auto;z-index:30}
.bt-head--page{padding:14px 12px}
.bt-head-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:0;gap:10px}
.bt-head .bt-search{margin-top:12px}
.bt-brand{display:flex;align-items:center;gap:9px;min-width:0}
.bt-brand-name{color:#fff;font-weight:700;font-size:15px;line-height:1}
.bt-loc{color:#8fb3a3;font-size:10px;margin-top:2px}
.bt-page-title{color:#fff;font-size:16px;font-weight:700;flex:1;text-align:center}
.bt-head-actions{display:flex;gap:8px;align-items:center;flex-shrink:0}
.bt-bhaiya-btn{border:none;cursor:pointer;border-radius:20px;
  background:linear-gradient(135deg,${r.C.orange},#f7a73a);color:#fff;
  font-size:11.5px;font-weight:800;padding:0 12px;height:36px;white-space:nowrap;
  display:flex;align-items:center;gap:4px;box-shadow:0 4px 12px rgba(245,158,11,.35)}
.bt-bhaiya-label{display:inline}
@media(max-width:360px){.bt-bhaiya-btn{padding:0 10px}.bt-bhaiya-label{display:none}}
.bt-icon-btn{width:36px;height:36px;border-radius:10px;border:none;
  background:rgba(255,255,255,.12);color:#fff;font-size:20px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;transition:background .15s}
.bt-icon-btn:hover{background:rgba(255,255,255,.2)}
.bt-avatar-btn{width:36px;height:36px;border-radius:50%;border:none;
  background:linear-gradient(135deg,#a3c93a,${r.C.orange});color:#fff;font-size:15px;
  font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center}
.bt-search{width:100%;background:#fff;border:none;border-radius:12px;
  padding:11px 13px;display:flex;align-items:center;gap:8px;cursor:pointer;text-align:left}
.bt-search-ph{color:#9aa8a0;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* ── hero ── */
.bt-hero{background:linear-gradient(135deg,${r.C.green},#3b8c3f);
  margin:12px;border-radius:18px;padding:16px}
.bt-veg-badge{display:inline-block;background:rgba(255,255,255,.2);color:#fff;
  font-size:10px;padding:3px 10px;border-radius:20px;margin-bottom:8px;letter-spacing:.5px}
.bt-hero-title{color:#fff;font-size:21px;font-weight:800;line-height:1.2;margin:0}
.bt-hero-sub{color:#eafdea;font-size:12px;margin:6px 0 0}

/* ── categories ── */
.bt-cats{padding:2px 0 0;max-width:100%}
.bt-cat-scroll{display:flex;gap:12px;overflow-x:auto;padding:8px 12px 4px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-cat-scroll::-webkit-scrollbar{display:none}
.bt-cat{flex-shrink:0;background:none;border:none;cursor:pointer;text-align:center;padding:0}
.bt-cat-ic{width:60px;height:60px;border-radius:17px;display:flex;align-items:center;
  justify-content:center;font-size:27px;overflow:hidden;transition:transform .15s}
.bt-cat-ic img{width:100%;height:100%;object-fit:cover}
.bt-cat-ic .food-emoji{font-size:27px}
.bt-cat.on .bt-cat-ic{transform:scale(1.06);box-shadow:0 0 0 2.5px ${r.C.green}}
.bt-cat-lbl{display:block;font-size:11px;color:${r.C.ink};margin-top:5px;max-width:64px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bt-cat.on .bt-cat-lbl{font-weight:700;color:${r.C.green}}

/* ── offers ── */
.bt-offers{display:flex;gap:10px;overflow-x:auto;padding:12px 12px 4px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-offers::-webkit-scrollbar{display:none}
.bt-offer{flex-shrink:0;border-radius:14px;padding:12px 14px;display:flex;align-items:center;gap:10px;min-width:185px}
.bt-offer.dark{background:${r.C.dark}}
.bt-offer.soft{background:${r.C.orangeSoft}}
.bt-offer-ic{width:32px;height:32px;border-radius:9px;display:flex;align-items:center;
  justify-content:center;color:#fff;font-size:16px;font-weight:700;flex-shrink:0}
.bt-offer.dark .bt-offer-t{color:#fff;font-size:13px;font-weight:700}
.bt-offer.dark .bt-offer-s{color:#8fb3a3;font-size:10px}
.bt-offer-t{font-size:13px;font-weight:700}
.bt-offer-s{font-size:10px}

/* ── filters ── */
.bt-filters{display:flex;gap:7px;overflow-x:auto;padding:10px 12px 2px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-filters::-webkit-scrollbar{display:none}
.bt-chip{flex-shrink:0;font-size:11.5px;padding:6px 13px;border-radius:20px;
  border:1px solid ${r.C.line};background:#fff;color:${r.C.ink};cursor:pointer;font-weight:600;white-space:nowrap}
.bt-chip.on{background:${r.C.dark};color:#fff;border-color:${r.C.dark}}

/* ── products ── */
.bt-products{padding:12px 12px 0}
.bt-sec-title{font-size:16px;font-weight:800;margin:4px 0 12px}
.bt-card{display:flex;gap:12px;background:#fff;border:1px solid ${r.C.line};
  border-radius:15px;padding:10px;margin-bottom:11px}
.bt-card-img{width:92px;height:92px;border-radius:11px;background:${r.C.greenSoft};
  display:flex;align-items:center;justify-content:center;flex-shrink:0;position:relative;overflow:hidden}
.bt-card-img img{width:100%;height:100%;object-fit:cover}
.bt-card-img .food-emoji{font-size:40px}
.veg-dot{position:absolute;top:6px;left:6px;width:15px;height:15px;border:1.5px solid ${r.C.green};
  border-radius:3px;background:#fff;display:flex;align-items:center;justify-content:center;z-index:2}
.veg-dot i{width:7px;height:7px;background:${r.C.green};border-radius:50%}
.veg-dot.sm{width:13px;height:13px}
.veg-dot.sm i{width:6px;height:6px}
.bt-card-off{position:absolute;bottom:6px;left:6px;background:${r.C.orange};color:#fff;
  font-size:9px;font-weight:800;padding:2px 6px;border-radius:5px;z-index:2}
.bt-card-body{flex:1;min-width:0;display:flex;flex-direction:column}
.bt-card-name{font-size:14px;font-weight:700}
.bt-card-name-link{color:inherit}
.bt-card-desc{font-size:11px;color:${r.C.muted};margin:2px 0 6px;
  display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}
.bt-card-tags{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:7px}
.tag{font-size:9px;background:${r.C.bg};color:${r.C.muted};padding:2px 6px;border-radius:5px;font-weight:600;white-space:nowrap}
.tag.green{background:${r.C.greenSoft};color:#2e7d32}
.tag.orange{background:${r.C.orangeSoft};color:#b76e00}
.bt-card-foot{display:flex;align-items:center;justify-content:space-between;margin-top:auto;gap:8px}
.bt-price b{font-size:15px;font-weight:800}
.bt-price s{font-size:11px;color:#9aa8a0;margin-left:6px}
.bt-add{background:${r.C.green};color:#fff;border:none;font-size:12px;font-weight:700;
  padding:7px 18px;border-radius:9px;cursor:pointer;letter-spacing:.5px;flex-shrink:0}
.bt-qty{display:flex;align-items:center;gap:10px;background:${r.C.green};border-radius:9px;padding:5px 11px;flex-shrink:0}
.bt-qty button{background:none;border:none;color:#fff;font-size:17px;cursor:pointer;line-height:1;width:14px}
.bt-qty span{color:#fff;font-weight:700;font-size:13px;min-width:12px;text-align:center}
.bt-empty{background:#fff;border:1px dashed ${r.C.line};border-radius:14px;padding:32px 18px;
  text-align:center;color:${r.C.muted};font-size:13px}

/* ── skeletons ── */
.skel{background:linear-gradient(90deg,#eef2ee 25%,#e3e9e3 50%,#eef2ee 75%);
  background-size:200% 100%;animation:sh 1.3s infinite}
.skel-txt{height:11px;border-radius:5px;margin:5px 0;
  background:linear-gradient(90deg,#eef2ee 25%,#e3e9e3 50%,#eef2ee 75%);
  background-size:200% 100%;animation:sh 1.3s infinite}
@keyframes sh{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── footer (cart bar + nav) ── */
.bt-footer{flex:0 0 auto;position:relative;z-index:25}
.bt-cartbar{background:${r.C.green};padding:12px 18px;display:flex;
  align-items:center;justify-content:space-between;animation:slideUpBar .4s ease}
.bt-cartbar-c{color:#eafdea;font-size:11px}
.bt-cartbar-t{color:#fff;font-weight:800;font-size:16px}
.bt-cartbar-btn{background:${r.C.orange};color:#fff;border:none;font-weight:800;
  padding:10px 20px;border-radius:22px;cursor:pointer;font-size:13px}
.bt-nav{background:#fff;border-top:1px solid ${r.C.line};display:flex;justify-content:space-around;
  padding:8px 0 10px}
.bt-nav-i{background:none;border:none;cursor:pointer;display:flex;flex-direction:column;
  align-items:center;gap:1px;color:#9aa8a0;font-size:9px;position:relative}
.bt-nav-ic{font-size:19px;position:relative;display:inline-block}
.bt-nav-i.on{color:${r.C.green}}
.bt-nav-badge{position:absolute;top:-6px;right:-10px;background:${r.C.orange};color:#fff;
  font-style:normal;font-size:9px;font-weight:700;min-width:15px;height:15px;border-radius:8px;
  display:flex;align-items:center;justify-content:center;padding:0 3px}

/* ── generic page bits ── */
.bt-page-pad{padding:14px 12px}
.bt-section-h{font-size:15px;font-weight:800;margin:18px 12px 10px}

/* ── product detail ── */
.pd-hero{position:relative;width:100%;aspect-ratio:1/1;max-height:340px;background:${r.C.greenSoft};
  display:flex;align-items:center;justify-content:center;overflow:hidden}
.pd-hero img{width:100%;height:100%;object-fit:cover}
.pd-hero .food-emoji{font-size:120px}
.pd-hero-off{position:absolute;top:14px;left:14px;background:${r.C.orange};color:#fff;
  font-size:12px;font-weight:800;padding:5px 12px;border-radius:8px}
.pd-veg{position:absolute;top:14px;right:14px;width:22px;height:22px;border:2px solid ${r.C.green};
  border-radius:4px;background:#fff;display:flex;align-items:center;justify-content:center}
.pd-veg i{width:10px;height:10px;background:${r.C.green};border-radius:50%}
.pd-body{padding:16px 16px 0}
.pd-name{font-size:22px;font-weight:800;line-height:1.2}
.pd-rating{display:inline-flex;align-items:center;gap:4px;background:${r.C.greenSoft};
  color:${r.C.greenDeep};font-size:12px;font-weight:700;padding:3px 9px;border-radius:8px;margin-top:8px}
.pd-desc{font-size:13.5px;color:#3a5a4d;line-height:1.5;margin:12px 0 4px}
.pd-price{display:flex;align-items:baseline;gap:10px;margin:14px 0 4px}
.pd-price b{font-size:26px;font-weight:800}
.pd-price s{font-size:15px;color:#9aa8a0}
.pd-price .pd-save{font-size:12px;font-weight:800;color:${r.C.greenDeep};background:${r.C.greenSoft};
  padding:3px 9px;border-radius:7px}
.pd-macros{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0 6px}
.pd-macro{background:#fff;border:1px solid ${r.C.line};border-radius:13px;padding:12px 6px;text-align:center}
.pd-macro b{display:block;font-size:17px;font-weight:800;color:${r.C.ink}}
.pd-macro span{font-size:10px;color:${r.C.muted}}
.pd-macro.cal b{color:${r.C.orange}}
.pd-macro.pro b{color:${r.C.green}}

/* ── cart ── */
.cart-item{display:flex;gap:12px;background:#fff;border:1px solid ${r.C.line};
  border-radius:15px;padding:10px;margin-bottom:11px;align-items:center}
.cart-item-img{width:70px;height:70px;border-radius:11px;background:${r.C.greenSoft};
  display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;position:relative}
.cart-item-img img{width:100%;height:100%;object-fit:cover}
.cart-item-img .food-emoji{font-size:30px}
.cart-item-info{flex:1;min-width:0}
.cart-item-name{font-size:14px;font-weight:700}
.cart-item-price{font-size:13px;color:${r.C.muted};margin-top:2px}
.cart-item-price b{color:${r.C.ink}}
.cart-remove{background:none;border:none;color:#c0392b;font-size:11px;cursor:pointer;margin-top:4px;padding:0}
.bill{background:#fff;border:1px solid ${r.C.line};border-radius:15px;padding:14px;margin-top:6px}
.bill-row{display:flex;justify-content:space-between;font-size:13px;color:#3a5a4d;margin-bottom:8px}
.bill-row.free{color:${r.C.green};font-weight:700}
.bill-hr{border:none;border-top:1px dashed ${r.C.line};margin:10px 0}
.bill-total{display:flex;justify-content:space-between;font-size:16px;font-weight:800;color:${r.C.ink}}
.coupon{display:flex;gap:8px;align-items:center;background:${r.C.orangeSoft};border:1px dashed ${r.C.orange};
  border-radius:12px;padding:10px 12px;margin:12px 0;font-size:12px;color:${r.C.orangeDeep};font-weight:700}
.checkout-bar{padding:12px 16px;background:#fff;border-top:1px solid ${r.C.line};
  display:flex;align-items:center;justify-content:space-between;gap:12px}
.checkout-total b{font-size:18px;font-weight:800}
.checkout-total span{display:block;font-size:11px;color:${r.C.muted}}
.checkout-btn{flex:1;max-width:200px;background:linear-gradient(135deg,${r.C.green},${r.C.greenDeep});
  color:#fff;border:none;font-size:15px;font-weight:800;padding:13px;border-radius:13px;cursor:pointer;
  box-shadow:0 6px 16px rgba(76,175,80,.35)}

/* ── orders ── */
.order-card{background:#fff;border:1px solid ${r.C.line};border-radius:15px;padding:14px;margin-bottom:12px}
.order-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}
.order-id{font-size:13px;font-weight:800}
.order-date{font-size:11px;color:${r.C.muted};margin-top:2px}
.order-status{font-size:10px;font-weight:800;padding:4px 10px;border-radius:20px;white-space:nowrap}
.order-status.placed{background:${r.C.orangeSoft};color:${r.C.orangeDeep}}
.order-status.preparing{background:${r.C.orangeSoft};color:${r.C.orangeDeep}}
.order-status.on_the_way{background:#e3f2fd;color:#1565c0}
.order-status.delivered{background:${r.C.greenSoft};color:${r.C.greenDeep}}
.order-items{display:flex;flex-direction:column;gap:6px}
.order-line{display:flex;justify-content:space-between;font-size:12.5px;color:#3a5a4d}
.order-foot{display:flex;justify-content:space-between;align-items:center;
  border-top:1px dashed ${r.C.line};margin-top:10px;padding-top:10px}
.order-total{font-size:14px;font-weight:800}
.order-reorder{background:${r.C.greenSoft};color:${r.C.greenDeep};border:none;font-size:12px;
  font-weight:700;padding:7px 14px;border-radius:9px;cursor:pointer}

/* ── menu page ── */
.menu-jump{display:flex;gap:7px;overflow-x:auto;padding:10px 12px;scrollbar-width:none;
  position:sticky;top:0;background:${r.C.bg};z-index:5}
.menu-jump::-webkit-scrollbar{display:none}
.menu-jump-chip{flex-shrink:0;font-size:11.5px;padding:6px 13px;border-radius:20px;
  border:1px solid ${r.C.line};background:#fff;color:${r.C.ink};cursor:pointer;font-weight:600;white-space:nowrap}
.menu-jump-chip.on{background:${r.C.dark};color:#fff;border-color:${r.C.dark}}
.menu-cat-h{display:flex;align-items:center;gap:8px;font-size:16px;font-weight:800;
  margin:18px 12px 10px;scroll-margin-top:60px}
.menu-cat-h .cnt{font-size:11px;font-weight:600;color:${r.C.muted}}

/* toast */
.toast{position:absolute;bottom:78px;left:50%;transform:translateX(-50%);
  background:${r.C.dark};color:#fff;font-size:13px;font-weight:600;padding:11px 18px;border-radius:24px;
  box-shadow:0 10px 30px rgba(0,0,0,.3);z-index:50;animation:toastIn .3s ease;white-space:nowrap}

/* keyframes */
@keyframes slideUpBar{0%{transform:translateY(100px)}100%{transform:translateY(0)}}
@keyframes toastIn{0%{transform:translate(-50%,20px);opacity:0}100%{transform:translate(-50%,0);opacity:1}}
@keyframes fadeIn{0%{opacity:0}100%{opacity:1}}

@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
    `})}])},95057,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var o={formatUrl:function(){return d},formatWithValidation:function(){return l},urlObjectKeys:function(){return s}};for(var n in o)Object.defineProperty(r,n,{enumerable:!0,get:o[n]});let i=e.r(90809)._(e.r(98183)),a=/https?|ftp|gopher|file/;function d(e){let{auth:t,hostname:r}=e,o=e.protocol||"",n=e.pathname||"",d=e.hash||"",s=e.query||"",l=!1;t=t?encodeURIComponent(t).replace(/%3A/i,":")+"@":"",e.host?l=t+e.host:r&&(l=t+(~r.indexOf(":")?`[${r}]`:r),e.port&&(l+=":"+e.port)),s&&"object"==typeof s&&(s=String(i.urlQueryToSearchParams(s)));let p=e.search||s&&`?${s}`||"";return o&&!o.endsWith(":")&&(o+=":"),e.slashes||(!o||a.test(o))&&!1!==l?(l="//"+(l||""),n&&"/"!==n[0]&&(n="/"+n)):l||(l=""),d&&"#"!==d[0]&&(d="#"+d),p&&"?"!==p[0]&&(p="?"+p),n=n.replace(/[?#]/g,encodeURIComponent),p=p.replace("#","%23"),`${o}${l}${n}${p}${d}`}let s=["auth","hash","host","hostname","href","path","pathname","port","protocol","query","search","slashes"];function l(e){return d(e)}},18581,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"useMergedRef",{enumerable:!0,get:function(){return n}});let o=e.r(71645);function n(e,t){let r=(0,o.useRef)(null),n=(0,o.useRef)(null);return(0,o.useCallback)(o=>{if(null===o){let e=r.current;e&&(r.current=null,e());let t=n.current;t&&(n.current=null,t())}else e&&(r.current=i(e,o)),t&&(n.current=i(t,o))},[e,t])}function i(e,t){if("function"!=typeof e)return e.current=t,()=>{e.current=null};{let r=e(t);return"function"==typeof r?r:()=>e(null)}}("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)},73668,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"isLocalURL",{enumerable:!0,get:function(){return i}});let o=e.r(18967),n=e.r(52817);function i(e){if(!(0,o.isAbsoluteUrl)(e))return!0;try{let t=(0,o.getLocationOrigin)(),r=new URL(e,t);return r.origin===t&&(0,n.hasBasePath)(r.pathname)}catch(e){return!1}}},84508,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"errorOnce",{enumerable:!0,get:function(){return o}});let o=e=>{}},22016,(e,t,r)=>{"use strict";Object.defineProperty(r,"__esModule",{value:!0});var o={default:function(){return h},useLinkStatus:function(){return y}};for(var n in o)Object.defineProperty(r,n,{enumerable:!0,get:o[n]});let i=e.r(90809),a=e.r(43476),d=i._(e.r(71645)),s=e.r(95057),l=e.r(8372),p=e.r(18581),c=e.r(18967),f=e.r(5550);e.r(33525);let x=e.r(88540),g=e.r(91949),b=e.r(73668),u=e.r(9396);function h(t){var r,o;let n,i,h,[y,w]=(0,d.useOptimistic)(g.IDLE_LINK_STATUS),k=(0,d.useRef)(null),{href:v,as:j,children:C,prefetch:$=null,passHref:z,replace:N,shallow:S,scroll:_,onClick:O,onMouseEnter:P,onTouchStart:T,legacyBehavior:R=!1,onNavigate:M,transitionTypes:B,ref:D,unstable_dynamicOnHover:U,...E}=t;n=C,R&&("string"==typeof n||"number"==typeof n)&&(n=(0,a.jsx)("a",{children:n}));let I=d.default.useContext(l.AppRouterContext),A=!1!==$,L=!1!==$?null===(o=$)||"auto"===o?u.FetchStrategy.PPR:u.FetchStrategy.Full:u.FetchStrategy.PPR,K="string"==typeof(r=j||v)?r:(0,s.formatUrl)(r);if(R){if(n?.$$typeof===Symbol.for("react.lazy"))throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."),"__NEXT_ERROR_CODE",{value:"E863",enumerable:!1,configurable:!0});i=d.default.Children.only(n)}let q=R?i&&"object"==typeof i&&i.ref:D,W=d.default.useCallback(e=>(null!==I&&(k.current=(0,g.mountLinkInstance)(e,K,I,L,A,w)),()=>{k.current&&((0,g.unmountLinkForCurrentNavigation)(k.current),k.current=null),(0,g.unmountPrefetchableInstance)(e)}),[A,K,I,L,w]),F={ref:(0,p.useMergedRef)(W,q),onClick(t){R||"function"!=typeof O||O(t),R&&i.props&&"function"==typeof i.props.onClick&&i.props.onClick(t),!I||t.defaultPrevented||function(t,r,o,n,i,a,s){if("u">typeof window){let l,{nodeName:p}=t.currentTarget;if("A"===p.toUpperCase()&&((l=t.currentTarget.getAttribute("target"))&&"_self"!==l||t.metaKey||t.ctrlKey||t.shiftKey||t.altKey||t.nativeEvent&&2===t.nativeEvent.which)||t.currentTarget.hasAttribute("download"))return;if(!(0,b.isLocalURL)(r)){n&&(t.preventDefault(),location.replace(r));return}if(t.preventDefault(),a){let e=!1;if(a({preventDefault:()=>{e=!0}}),e)return}let{dispatchNavigateAction:c}=e.r(99781);d.default.startTransition(()=>{c(r,n?"replace":"push",!1===i?x.ScrollBehavior.NoScroll:x.ScrollBehavior.Default,o.current,s)})}}(t,K,k,N,_,M,B)},onMouseEnter(e){R||"function"!=typeof P||P(e),R&&i.props&&"function"==typeof i.props.onMouseEnter&&i.props.onMouseEnter(e),I&&A&&(0,g.onNavigationIntent)(e.currentTarget,!0===U)},onTouchStart:function(e){R||"function"!=typeof T||T(e),R&&i.props&&"function"==typeof i.props.onTouchStart&&i.props.onTouchStart(e),I&&A&&(0,g.onNavigationIntent)(e.currentTarget,!0===U)}};return(0,c.isAbsoluteUrl)(K)?F.href=K:R&&!z&&("a"!==i.type||"href"in i.props)||(F.href=(0,f.addBasePath)(K)),h=R?d.default.cloneElement(i,F):(0,a.jsx)("a",{...E,...F,children:n}),(0,a.jsx)(m.Provider,{value:y,children:h})}e.r(84508);let m=(0,d.createContext)(g.IDLE_LINK_STATUS),y=()=>(0,d.useContext)(m);("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)},25045,74539,e=>{"use strict";var t=e.i(43476),r=e.i(7884),o=e.i(22016),n=e.i(18566),i=e.i(74114);let a=[{href:"/",icon:"🏠",label:"Home",match:e=>"/"===e},{href:"/menu",icon:"🍽️",label:"Menu",match:e=>e.startsWith("/menu")||e.startsWith("/product")},{href:"/cart",icon:"🛒",label:"Cart",match:e=>e.startsWith("/cart")},{href:"/orders",icon:"📋",label:"Orders",match:e=>e.startsWith("/orders")}];function d(){let e=(0,n.usePathname)()||"/",{count:r}=(0,i.useCart)();return(0,t.jsx)("nav",{className:"bt-nav",children:a.map(n=>{let i=n.match(e);return(0,t.jsxs)(o.default,{href:n.href,className:`bt-nav-i ${i?"on":""}`,children:[(0,t.jsxs)("span",{className:"bt-nav-ic",children:[n.icon,"/cart"===n.href&&r>0&&(0,t.jsx)("em",{className:"bt-nav-badge",children:r})]}),(0,t.jsx)("span",{children:n.label})]},n.href)})})}e.s(["default",0,function({header:e,children:o,footerExtra:n,overlay:i}){return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(r.default,{}),(0,t.jsx)("div",{className:"bt-stage",children:(0,t.jsxs)("main",{className:"bt-app",children:[e,(0,t.jsx)("div",{className:"bt-scroll",children:o}),(0,t.jsxs)("div",{className:"bt-footer",children:[n,(0,t.jsx)(d,{})]}),i]})})]})}],25045),e.s(["default",0,function({variant:e="page",title:r,onMenu:o,onAskBhaiya:i,showSearch:a=!1}){let d=(0,n.useRouter)();return"home"===e?(0,t.jsxs)("header",{className:"bt-head",children:[(0,t.jsxs)("div",{className:"bt-head-row",children:[(0,t.jsxs)("div",{className:"bt-brand",children:[(0,t.jsx)("span",{className:"brandmark",children:"B"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"bt-brand-name",children:"Bite Theory"}),(0,t.jsx)("div",{className:"bt-loc",children:"📍 Indore"})]})]}),(0,t.jsxs)("div",{className:"bt-head-actions",children:[i&&(0,t.jsxs)("button",{className:"bt-bhaiya-btn","aria-label":"Ask Bhaiya for a recommendation",onClick:i,children:["🧪 ",(0,t.jsx)("span",{className:"bt-bhaiya-label",children:"Ask Bhaiya"})]}),(0,t.jsx)("button",{className:"bt-icon-btn","aria-label":"Open menu",onClick:o,children:"☰"}),(0,t.jsx)("button",{className:"bt-avatar-btn","aria-label":"Open profile",onClick:o,children:"S"})]})]}),a&&(0,t.jsxs)("button",{className:"bt-search",children:[(0,t.jsx)("span",{children:"🔍"}),(0,t.jsx)("span",{className:"bt-search-ph",children:"Search thali, healthy meals, snacks…"})]})]}):(0,t.jsx)("header",{className:"bt-head bt-head--page",children:(0,t.jsxs)("div",{className:"bt-head-row",children:[(0,t.jsx)("button",{className:"bt-icon-btn","aria-label":"Go back",onClick:()=>d.back(),children:"‹"}),(0,t.jsx)("div",{className:"bt-page-title",children:r}),(0,t.jsx)("button",{className:"bt-icon-btn","aria-label":"Open menu",onClick:o,children:"☰"})]})})}],74539)},27426,e=>{"use strict";var t=e.i(43476),r=e.i(71645),o=e.i(18566),n=e.i(22016),i=e.i(25045),a=e.i(74539),d=e.i(74114),s=e.i(61928);let l={placed:"Placed",preparing:"Preparing",on_the_way:"On the way",delivered:"Delivered"};function p(){let{orders:e,add:r}=(0,d.useCart)(),p=(0,o.useSearchParams)().get("placed");return(0,t.jsx)(i.default,{header:(0,t.jsx)(a.default,{variant:"page",title:"Your Orders"}),children:(0,t.jsxs)("div",{className:"bt-page-pad",children:[p&&(0,t.jsxs)("div",{style:{background:s.C.greenSoft,border:`1px solid ${s.C.green}`,borderRadius:14,padding:"14px 16px",marginBottom:14,display:"flex",gap:12,alignItems:"center"},children:[(0,t.jsx)("span",{style:{fontSize:26},children:"🎉"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{style:{fontWeight:800,color:s.C.greenDeep},children:"Order placed!"}),(0,t.jsxs)("div",{style:{fontSize:12,color:"#3a5a4d",marginTop:2},children:["#",p," · Theory Bhaiya is on it 🧪"]})]})]}),0===e.length?(0,t.jsxs)("div",{className:"bt-empty",style:{marginTop:24},children:[(0,t.jsx)("div",{style:{fontSize:40,marginBottom:8},children:"📋"}),"Abhi tak koi order nahi.",(0,t.jsx)("div",{style:{marginTop:14},children:(0,t.jsx)(n.default,{href:"/menu",style:{background:s.C.green,color:"#fff",padding:"10px 22px",borderRadius:10,fontWeight:700,fontSize:13,display:"inline-block"},children:"Order something →"})})]}):e.map(e=>(0,t.jsxs)("div",{className:"order-card",children:[(0,t.jsxs)("div",{className:"order-top",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"order-id",children:["#",e.id]}),(0,t.jsx)("div",{className:"order-date",children:function(e){let t=Math.floor((Date.now()-e)/1e3);if(t<60)return"just now";let r=Math.floor(t/60);if(r<60)return`${r} min ago`;let o=Math.floor(r/60);if(o<24)return`${o} hr ago`;let n=Math.floor(o/24);return 1===n?"yesterday":`${n} days ago`}(e.createdAt)})]}),(0,t.jsx)("span",{className:`order-status ${e.status}`,children:l[e.status]})]}),(0,t.jsx)("div",{className:"order-items",children:e.items.map(e=>(0,t.jsxs)("div",{className:"order-line",children:[(0,t.jsxs)("span",{children:[e.qty,"× ",e.name]}),(0,t.jsx)("span",{children:(0,s.money)(e.price*e.qty)})]},e.id))}),(0,t.jsxs)("div",{className:"order-foot",children:[(0,t.jsx)("span",{className:"order-total",children:(0,s.money)(e.total)}),(0,t.jsx)("button",{className:"order-reorder",onClick:()=>{e.items.forEach(e=>{for(let t=0;t<e.qty;t++)r(e.id)})},children:"Reorder"})]})]},e.id))]})})}e.s(["default",0,function(){return(0,t.jsx)(r.Suspense,{fallback:null,children:(0,t.jsx)(p,{})})}])}]);