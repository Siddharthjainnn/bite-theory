(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,7884,e=>{"use strict";var t=e.i(43476),a=e.i(61928);e.s(["default",0,function(){return(0,t.jsx)("style",{children:`
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;max-width:100%;overflow-x:hidden}
a{text-decoration:none;color:inherit}

/* stage = desktop backdrop + centered phone frame */
.bt-stage{height:100vh;min-height:100vh;width:100%;background:
  radial-gradient(900px 600px at 50% -10%, #16604733, transparent 60%),
  ${a.C.dark};
  display:flex;justify-content:center;align-items:stretch;
  padding:0;overflow:hidden}

/* app = full-height flex column: [header][scroll][footer] */
.bt-app{position:relative;width:100%;max-width:480px;background:${a.C.bg};
  height:100vh;max-height:100vh;overflow:hidden;
  display:flex;flex-direction:column;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  color:${a.C.ink}}

.bt-scroll{flex:1 1 auto;overflow-y:auto;overflow-x:hidden;
  -webkit-overflow-scrolling:touch;scrollbar-width:none}
.bt-scroll::-webkit-scrollbar{display:none}

@media(min-width:520px){
  .bt-stage{padding:18px 0;align-items:center}
  .bt-app{height:calc(100vh - 36px);max-height:calc(100vh - 36px);
    margin:0;border-radius:30px;
    box-shadow:0 30px 90px rgba(0,0,0,.5);overflow:hidden}
  .bt-app .bt-head{border-radius:30px 30px 0 0}
}

.brandmark{width:34px;height:34px;border-radius:9px;
  background:linear-gradient(135deg,${a.C.green},${a.C.orange});display:flex;
  align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:18px;flex-shrink:0}

.food-emoji{display:flex;align-items:center;justify-content:center;width:100%;height:100%;font-size:34px;line-height:1}

/* ── header ── */
.bt-head{background:${a.C.dark};padding:14px 16px 16px;flex:0 0 auto;z-index:30}
.bt-head--page{padding:14px 12px}
.bt-head-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:0;gap:10px}
.bt-head .bt-search{margin-top:12px}
.bt-brand{display:flex;align-items:center;gap:9px;min-width:0}
.bt-brand-name{color:#fff;font-weight:700;font-size:15px;line-height:1}
.bt-loc{color:#8fb3a3;font-size:10px;margin-top:2px}
.bt-page-title{color:#fff;font-size:16px;font-weight:700;flex:1;text-align:center}
.bt-head-actions{display:flex;gap:8px;align-items:center;flex-shrink:0}
.bt-bhaiya-btn{border:none;cursor:pointer;border-radius:20px;
  background:linear-gradient(135deg,${a.C.orange},#f7a73a);color:#fff;
  font-size:11.5px;font-weight:800;padding:0 12px;height:36px;white-space:nowrap;
  display:flex;align-items:center;gap:4px;box-shadow:0 4px 12px rgba(245,158,11,.35)}
.bt-bhaiya-label{display:inline}
@media(max-width:360px){.bt-bhaiya-btn{padding:0 10px}.bt-bhaiya-label{display:none}}
.bt-icon-btn{width:36px;height:36px;border-radius:10px;border:none;
  background:rgba(255,255,255,.12);color:#fff;font-size:20px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;transition:background .15s}
.bt-icon-btn:hover{background:rgba(255,255,255,.2)}
.bt-avatar-btn{width:36px;height:36px;border-radius:50%;border:none;
  background:linear-gradient(135deg,#a3c93a,${a.C.orange});color:#fff;font-size:15px;
  font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center}
.bt-search{width:100%;background:#fff;border:none;border-radius:12px;
  padding:11px 13px;display:flex;align-items:center;gap:8px;cursor:pointer;text-align:left}
.bt-search-ph{color:#9aa8a0;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* ── hero ── */
.bt-hero{background:linear-gradient(135deg,${a.C.green},#3b8c3f);
  margin:12px;border-radius:18px;padding:16px}
.bt-veg-badge{display:inline-block;background:rgba(255,255,255,.2);color:#fff;
  font-size:10px;padding:3px 10px;border-radius:20px;margin-bottom:8px;letter-spacing:.5px}
.bt-hero-title{color:#fff;font-size:21px;font-weight:800;line-height:1.2;margin:0}
.bt-hero-sub{color:#eafdea;font-size:12px;margin:6px 0 0}

/* ── categories ── */
.bt-cats{padding:2px 0 0;max-width:100%}
.bt-cat-scroll{display:flex;gap:12px;overflow-x:auto;padding:8px 12px 4px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-cat-scroll::-webkit-scrollbar{display:none}
.bt-cat{flex-shrink:0;background:none;border:none;cursor:pointer;text-align:center;padding:0}
.bt-cat-ic{width:60px;height:60px;border-radius:17px;display:flex;align-items:center;
  justify-content:center;font-size:27px;overflow:hidden;transition:transform .15s}
.bt-cat-ic img{width:100%;height:100%;object-fit:cover}
.bt-cat-ic .food-emoji{font-size:27px}
.bt-cat.on .bt-cat-ic{transform:scale(1.06);box-shadow:0 0 0 2.5px ${a.C.green}}
.bt-cat-lbl{display:block;font-size:11px;color:${a.C.ink};margin-top:5px;max-width:64px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bt-cat.on .bt-cat-lbl{font-weight:700;color:${a.C.green}}

/* ── offers ── */
.bt-offers{display:flex;gap:10px;overflow-x:auto;padding:12px 12px 4px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-offers::-webkit-scrollbar{display:none}
.bt-offer{flex-shrink:0;border-radius:14px;padding:12px 14px;display:flex;align-items:center;gap:10px;min-width:185px}
.bt-offer.dark{background:${a.C.dark}}
.bt-offer.soft{background:${a.C.orangeSoft}}
.bt-offer-ic{width:32px;height:32px;border-radius:9px;display:flex;align-items:center;
  justify-content:center;color:#fff;font-size:16px;font-weight:700;flex-shrink:0}
.bt-offer.dark .bt-offer-t{color:#fff;font-size:13px;font-weight:700}
.bt-offer.dark .bt-offer-s{color:#8fb3a3;font-size:10px}
.bt-offer-t{font-size:13px;font-weight:700}
.bt-offer-s{font-size:10px}

/* ── filters ── */
.bt-filters{display:flex;gap:7px;overflow-x:auto;padding:10px 12px 2px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-filters::-webkit-scrollbar{display:none}
.bt-chip{flex-shrink:0;font-size:11.5px;padding:6px 13px;border-radius:20px;
  border:1px solid ${a.C.line};background:#fff;color:${a.C.ink};cursor:pointer;font-weight:600;white-space:nowrap}
.bt-chip.on{background:${a.C.dark};color:#fff;border-color:${a.C.dark}}

/* ── products ── */
.bt-products{padding:12px 12px 0}
.bt-sec-title{font-size:16px;font-weight:800;margin:4px 0 12px}
.bt-card{display:flex;gap:12px;background:#fff;border:1px solid ${a.C.line};
  border-radius:15px;padding:10px;margin-bottom:11px}
.bt-card-img{width:92px;height:92px;border-radius:11px;background:${a.C.greenSoft};
  display:flex;align-items:center;justify-content:center;flex-shrink:0;position:relative;overflow:hidden}
.bt-card-img img{width:100%;height:100%;object-fit:cover}
.bt-card-img .food-emoji{font-size:40px}
.veg-dot{position:absolute;top:6px;left:6px;width:15px;height:15px;border:1.5px solid ${a.C.green};
  border-radius:3px;background:#fff;display:flex;align-items:center;justify-content:center;z-index:2}
.veg-dot i{width:7px;height:7px;background:${a.C.green};border-radius:50%}
.veg-dot.sm{width:13px;height:13px}
.veg-dot.sm i{width:6px;height:6px}
.bt-card-off{position:absolute;bottom:6px;left:6px;background:${a.C.orange};color:#fff;
  font-size:9px;font-weight:800;padding:2px 6px;border-radius:5px;z-index:2}
.bt-card-body{flex:1;min-width:0;display:flex;flex-direction:column}
.bt-card-name{font-size:14px;font-weight:700}
.bt-card-name-link{color:inherit}
.bt-card-desc{font-size:11px;color:${a.C.muted};margin:2px 0 6px;
  display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}
.bt-card-tags{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:7px}
.tag{font-size:9px;background:${a.C.bg};color:${a.C.muted};padding:2px 6px;border-radius:5px;font-weight:600;white-space:nowrap}
.tag.green{background:${a.C.greenSoft};color:#2e7d32}
.tag.orange{background:${a.C.orangeSoft};color:#b76e00}
.bt-card-foot{display:flex;align-items:center;justify-content:space-between;margin-top:auto;gap:8px}
.bt-price b{font-size:15px;font-weight:800}
.bt-price s{font-size:11px;color:#9aa8a0;margin-left:6px}
.bt-add{background:${a.C.green};color:#fff;border:none;font-size:12px;font-weight:700;
  padding:7px 18px;border-radius:9px;cursor:pointer;letter-spacing:.5px;flex-shrink:0}
.bt-qty{display:flex;align-items:center;gap:10px;background:${a.C.green};border-radius:9px;padding:5px 11px;flex-shrink:0}
.bt-qty button{background:none;border:none;color:#fff;font-size:17px;cursor:pointer;line-height:1;width:14px}
.bt-qty span{color:#fff;font-weight:700;font-size:13px;min-width:12px;text-align:center}
.bt-empty{background:#fff;border:1px dashed ${a.C.line};border-radius:14px;padding:32px 18px;
  text-align:center;color:${a.C.muted};font-size:13px}

/* ── skeletons ── */
.skel{background:linear-gradient(90deg,#eef2ee 25%,#e3e9e3 50%,#eef2ee 75%);
  background-size:200% 100%;animation:sh 1.3s infinite}
.skel-txt{height:11px;border-radius:5px;margin:5px 0;
  background:linear-gradient(90deg,#eef2ee 25%,#e3e9e3 50%,#eef2ee 75%);
  background-size:200% 100%;animation:sh 1.3s infinite}
@keyframes sh{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── footer (cart bar + nav) ── */
.bt-footer{flex:0 0 auto;position:relative;z-index:25}
.bt-cartbar{background:${a.C.green};padding:12px 18px;display:flex;
  align-items:center;justify-content:space-between;animation:slideUpBar .4s ease}
.bt-cartbar-c{color:#eafdea;font-size:11px}
.bt-cartbar-t{color:#fff;font-weight:800;font-size:16px}
.bt-cartbar-btn{background:${a.C.orange};color:#fff;border:none;font-weight:800;
  padding:10px 20px;border-radius:22px;cursor:pointer;font-size:13px}
.bt-nav{background:#fff;border-top:1px solid ${a.C.line};display:flex;justify-content:space-around;
  padding:8px 0 10px}
.bt-nav-i{background:none;border:none;cursor:pointer;display:flex;flex-direction:column;
  align-items:center;gap:1px;color:#9aa8a0;font-size:9px;position:relative}
.bt-nav-ic{font-size:19px;position:relative;display:inline-block}
.bt-nav-i.on{color:${a.C.green}}
.bt-nav-badge{position:absolute;top:-6px;right:-10px;background:${a.C.orange};color:#fff;
  font-style:normal;font-size:9px;font-weight:700;min-width:15px;height:15px;border-radius:8px;
  display:flex;align-items:center;justify-content:center;padding:0 3px}

/* ── generic page bits ── */
.bt-page-pad{padding:14px 12px}
.bt-section-h{font-size:15px;font-weight:800;margin:18px 12px 10px}

/* ── product detail ── */
.pd-hero{position:relative;width:100%;aspect-ratio:1/1;max-height:340px;background:${a.C.greenSoft};
  display:flex;align-items:center;justify-content:center;overflow:hidden}
.pd-hero img{width:100%;height:100%;object-fit:cover}
.pd-hero .food-emoji{font-size:120px}
.pd-hero-off{position:absolute;top:14px;left:14px;background:${a.C.orange};color:#fff;
  font-size:12px;font-weight:800;padding:5px 12px;border-radius:8px}
.pd-veg{position:absolute;top:14px;right:14px;width:22px;height:22px;border:2px solid ${a.C.green};
  border-radius:4px;background:#fff;display:flex;align-items:center;justify-content:center}
.pd-veg i{width:10px;height:10px;background:${a.C.green};border-radius:50%}
.pd-body{padding:16px 16px 0}
.pd-name{font-size:22px;font-weight:800;line-height:1.2}
.pd-rating{display:inline-flex;align-items:center;gap:4px;background:${a.C.greenSoft};
  color:${a.C.greenDeep};font-size:12px;font-weight:700;padding:3px 9px;border-radius:8px;margin-top:8px}
.pd-desc{font-size:13.5px;color:#3a5a4d;line-height:1.5;margin:12px 0 4px}
.pd-price{display:flex;align-items:baseline;gap:10px;margin:14px 0 4px}
.pd-price b{font-size:26px;font-weight:800}
.pd-price s{font-size:15px;color:#9aa8a0}
.pd-price .pd-save{font-size:12px;font-weight:800;color:${a.C.greenDeep};background:${a.C.greenSoft};
  padding:3px 9px;border-radius:7px}
.pd-macros{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0 6px}
.pd-macro{background:#fff;border:1px solid ${a.C.line};border-radius:13px;padding:12px 6px;text-align:center}
.pd-macro b{display:block;font-size:17px;font-weight:800;color:${a.C.ink}}
.pd-macro span{font-size:10px;color:${a.C.muted}}
.pd-macro.cal b{color:${a.C.orange}}
.pd-macro.pro b{color:${a.C.green}}

/* ── cart ── */
.cart-item{display:flex;gap:12px;background:#fff;border:1px solid ${a.C.line};
  border-radius:15px;padding:10px;margin-bottom:11px;align-items:center}
.cart-item-img{width:70px;height:70px;border-radius:11px;background:${a.C.greenSoft};
  display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;position:relative}
.cart-item-img img{width:100%;height:100%;object-fit:cover}
.cart-item-img .food-emoji{font-size:30px}
.cart-item-info{flex:1;min-width:0}
.cart-item-name{font-size:14px;font-weight:700}
.cart-item-price{font-size:13px;color:${a.C.muted};margin-top:2px}
.cart-item-price b{color:${a.C.ink}}
.cart-remove{background:none;border:none;color:#c0392b;font-size:11px;cursor:pointer;margin-top:4px;padding:0}
.bill{background:#fff;border:1px solid ${a.C.line};border-radius:15px;padding:14px;margin-top:6px}
.bill-row{display:flex;justify-content:space-between;font-size:13px;color:#3a5a4d;margin-bottom:8px}
.bill-row.free{color:${a.C.green};font-weight:700}
.bill-hr{border:none;border-top:1px dashed ${a.C.line};margin:10px 0}
.bill-total{display:flex;justify-content:space-between;font-size:16px;font-weight:800;color:${a.C.ink}}
.coupon{display:flex;gap:8px;align-items:center;background:${a.C.orangeSoft};border:1px dashed ${a.C.orange};
  border-radius:12px;padding:10px 12px;margin:12px 0;font-size:12px;color:${a.C.orangeDeep};font-weight:700}
.checkout-bar{padding:12px 16px;background:#fff;border-top:1px solid ${a.C.line};
  display:flex;align-items:center;justify-content:space-between;gap:12px}
.checkout-total b{font-size:18px;font-weight:800}
.checkout-total span{display:block;font-size:11px;color:${a.C.muted}}
.checkout-btn{flex:1;max-width:200px;background:linear-gradient(135deg,${a.C.green},${a.C.greenDeep});
  color:#fff;border:none;font-size:15px;font-weight:800;padding:13px;border-radius:13px;cursor:pointer;
  box-shadow:0 6px 16px rgba(76,175,80,.35)}

/* ── orders ── */
.order-card{background:#fff;border:1px solid ${a.C.line};border-radius:15px;padding:14px;margin-bottom:12px}
.order-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}
.order-id{font-size:13px;font-weight:800}
.order-date{font-size:11px;color:${a.C.muted};margin-top:2px}
.order-status{font-size:10px;font-weight:800;padding:4px 10px;border-radius:20px;white-space:nowrap}
.order-status.placed{background:${a.C.orangeSoft};color:${a.C.orangeDeep}}
.order-status.preparing{background:${a.C.orangeSoft};color:${a.C.orangeDeep}}
.order-status.on_the_way{background:#e3f2fd;color:#1565c0}
.order-status.delivered{background:${a.C.greenSoft};color:${a.C.greenDeep}}
.order-items{display:flex;flex-direction:column;gap:6px}
.order-line{display:flex;justify-content:space-between;font-size:12.5px;color:#3a5a4d}
.order-foot{display:flex;justify-content:space-between;align-items:center;
  border-top:1px dashed ${a.C.line};margin-top:10px;padding-top:10px}
.order-total{font-size:14px;font-weight:800}
.order-reorder{background:${a.C.greenSoft};color:${a.C.greenDeep};border:none;font-size:12px;
  font-weight:700;padding:7px 14px;border-radius:9px;cursor:pointer}

/* ── menu page ── */
.menu-jump{display:flex;gap:7px;overflow-x:auto;padding:10px 12px;scrollbar-width:none;
  position:sticky;top:0;background:${a.C.bg};z-index:5}
.menu-jump::-webkit-scrollbar{display:none}
.menu-jump-chip{flex-shrink:0;font-size:11.5px;padding:6px 13px;border-radius:20px;
  border:1px solid ${a.C.line};background:#fff;color:${a.C.ink};cursor:pointer;font-weight:600;white-space:nowrap}
.menu-jump-chip.on{background:${a.C.dark};color:#fff;border-color:${a.C.dark}}
.menu-cat-h{display:flex;align-items:center;gap:8px;font-size:16px;font-weight:800;
  margin:18px 12px 10px;scroll-margin-top:60px}
.menu-cat-h .cnt{font-size:11px;font-weight:600;color:${a.C.muted}}

/* toast */
.toast{position:absolute;bottom:78px;left:50%;transform:translateX(-50%);
  background:${a.C.dark};color:#fff;font-size:13px;font-weight:600;padding:11px 18px;border-radius:24px;
  box-shadow:0 10px 30px rgba(0,0,0,.3);z-index:50;animation:toastIn .3s ease;white-space:nowrap}

/* keyframes */
@keyframes slideUpBar{0%{transform:translateY(100px)}100%{transform:translateY(0)}}
@keyframes toastIn{0%{transform:translate(-50%,20px);opacity:0}100%{transform:translate(-50%,0);opacity:1}}
@keyframes fadeIn{0%{opacity:0}100%{opacity:1}}

@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
    `})}])},18566,(e,t,a)=>{t.exports=e.r(76562)},95057,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0});var r={formatUrl:function(){return s},formatWithValidation:function(){return d},urlObjectKeys:function(){return l}};for(var i in r)Object.defineProperty(a,i,{enumerable:!0,get:r[i]});let n=e.r(90809)._(e.r(98183)),o=/https?|ftp|gopher|file/;function s(e){let{auth:t,hostname:a}=e,r=e.protocol||"",i=e.pathname||"",s=e.hash||"",l=e.query||"",d=!1;t=t?encodeURIComponent(t).replace(/%3A/i,":")+"@":"",e.host?d=t+e.host:a&&(d=t+(~a.indexOf(":")?`[${a}]`:a),e.port&&(d+=":"+e.port)),l&&"object"==typeof l&&(l=String(n.urlQueryToSearchParams(l)));let c=e.search||l&&`?${l}`||"";return r&&!r.endsWith(":")&&(r+=":"),e.slashes||(!r||o.test(r))&&!1!==d?(d="//"+(d||""),i&&"/"!==i[0]&&(i="/"+i)):d||(d=""),s&&"#"!==s[0]&&(s="#"+s),c&&"?"!==c[0]&&(c="?"+c),i=i.replace(/[?#]/g,encodeURIComponent),c=c.replace("#","%23"),`${r}${d}${i}${c}${s}`}let l=["auth","hash","host","hostname","href","path","pathname","port","protocol","query","search","slashes"];function d(e){return s(e)}},18581,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"useMergedRef",{enumerable:!0,get:function(){return i}});let r=e.r(71645);function i(e,t){let a=(0,r.useRef)(null),i=(0,r.useRef)(null);return(0,r.useCallback)(r=>{if(null===r){let e=a.current;e&&(a.current=null,e());let t=i.current;t&&(i.current=null,t())}else e&&(a.current=n(e,r)),t&&(i.current=n(t,r))},[e,t])}function n(e,t){if("function"!=typeof e)return e.current=t,()=>{e.current=null};{let a=e(t);return"function"==typeof a?a:()=>e(null)}}("function"==typeof a.default||"object"==typeof a.default&&null!==a.default)&&void 0===a.default.__esModule&&(Object.defineProperty(a.default,"__esModule",{value:!0}),Object.assign(a.default,a),t.exports=a.default)},73668,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"isLocalURL",{enumerable:!0,get:function(){return n}});let r=e.r(18967),i=e.r(52817);function n(e){if(!(0,r.isAbsoluteUrl)(e))return!0;try{let t=(0,r.getLocationOrigin)(),a=new URL(e,t);return a.origin===t&&(0,i.hasBasePath)(a.pathname)}catch(e){return!1}}},84508,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"errorOnce",{enumerable:!0,get:function(){return r}});let r=e=>{}},22016,(e,t,a)=>{"use strict";Object.defineProperty(a,"__esModule",{value:!0});var r={default:function(){return u},useLinkStatus:function(){return y}};for(var i in r)Object.defineProperty(a,i,{enumerable:!0,get:r[i]});let n=e.r(90809),o=e.r(43476),s=n._(e.r(71645)),l=e.r(95057),d=e.r(8372),c=e.r(18581),p=e.r(18967),f=e.r(5550);e.r(33525);let x=e.r(88540),g=e.r(91949),b=e.r(73668),h=e.r(9396);function u(t){var a,r;let i,n,u,[y,w]=(0,s.useOptimistic)(g.IDLE_LINK_STATUS),j=(0,s.useRef)(null),{href:k,as:v,children:C,prefetch:N=null,passHref:$,replace:z,shallow:S,scroll:P,onClick:O,onMouseEnter:T,onTouchStart:A,legacyBehavior:_=!1,onNavigate:E,transitionTypes:B,ref:R,unstable_dynamicOnHover:D,...I}=t;i=C,_&&("string"==typeof i||"number"==typeof i)&&(i=(0,o.jsx)("a",{children:i}));let U=s.default.useContext(d.AppRouterContext),M=!1!==N,L=!1!==N?null===(r=N)||"auto"===r?h.FetchStrategy.PPR:h.FetchStrategy.Full:h.FetchStrategy.PPR,F="string"==typeof(a=v||k)?a:(0,l.formatUrl)(a);if(_){if(i?.$$typeof===Symbol.for("react.lazy"))throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."),"__NEXT_ERROR_CODE",{value:"E863",enumerable:!1,configurable:!0});n=s.default.Children.only(i)}let Y=_?n&&"object"==typeof n&&n.ref:R,X=s.default.useCallback(e=>(null!==U&&(j.current=(0,g.mountLinkInstance)(e,F,U,L,M,w)),()=>{j.current&&((0,g.unmountLinkForCurrentNavigation)(j.current),j.current=null),(0,g.unmountPrefetchableInstance)(e)}),[M,F,U,L,w]),K={ref:(0,c.useMergedRef)(X,Y),onClick(t){_||"function"!=typeof O||O(t),_&&n.props&&"function"==typeof n.props.onClick&&n.props.onClick(t),!U||t.defaultPrevented||function(t,a,r,i,n,o,l){if("u">typeof window){let d,{nodeName:c}=t.currentTarget;if("A"===c.toUpperCase()&&((d=t.currentTarget.getAttribute("target"))&&"_self"!==d||t.metaKey||t.ctrlKey||t.shiftKey||t.altKey||t.nativeEvent&&2===t.nativeEvent.which)||t.currentTarget.hasAttribute("download"))return;if(!(0,b.isLocalURL)(a)){i&&(t.preventDefault(),location.replace(a));return}if(t.preventDefault(),o){let e=!1;if(o({preventDefault:()=>{e=!0}}),e)return}let{dispatchNavigateAction:p}=e.r(99781);s.default.startTransition(()=>{p(a,i?"replace":"push",!1===n?x.ScrollBehavior.NoScroll:x.ScrollBehavior.Default,r.current,l)})}}(t,F,j,z,P,E,B)},onMouseEnter(e){_||"function"!=typeof T||T(e),_&&n.props&&"function"==typeof n.props.onMouseEnter&&n.props.onMouseEnter(e),U&&M&&(0,g.onNavigationIntent)(e.currentTarget,!0===D)},onTouchStart:function(e){_||"function"!=typeof A||A(e),_&&n.props&&"function"==typeof n.props.onTouchStart&&n.props.onTouchStart(e),U&&M&&(0,g.onNavigationIntent)(e.currentTarget,!0===D)}};return(0,p.isAbsoluteUrl)(F)?K.href=F:_&&!$&&("a"!==n.type||"href"in n.props)||(K.href=(0,f.addBasePath)(F)),u=_?s.default.cloneElement(n,K):(0,o.jsx)("a",{...I,...K,children:i}),(0,o.jsx)(m.Provider,{value:y,children:u})}e.r(84508);let m=(0,s.createContext)(g.IDLE_LINK_STATUS),y=()=>(0,s.useContext)(m);("function"==typeof a.default||"object"==typeof a.default&&null!==a.default)&&void 0===a.default.__esModule&&(Object.defineProperty(a.default,"__esModule",{value:!0}),Object.assign(a.default,a),t.exports=a.default)},25045,74539,e=>{"use strict";var t=e.i(43476),a=e.i(7884),r=e.i(22016),i=e.i(18566),n=e.i(74114);let o=[{href:"/",icon:"🏠",label:"Home",match:e=>"/"===e},{href:"/menu",icon:"🍽️",label:"Menu",match:e=>e.startsWith("/menu")||e.startsWith("/product")},{href:"/cart",icon:"🛒",label:"Cart",match:e=>e.startsWith("/cart")},{href:"/orders",icon:"📋",label:"Orders",match:e=>e.startsWith("/orders")}];function s(){let e=(0,i.usePathname)()||"/",{count:a}=(0,n.useCart)();return(0,t.jsx)("nav",{className:"bt-nav",children:o.map(i=>{let n=i.match(e);return(0,t.jsxs)(r.default,{href:i.href,className:`bt-nav-i ${n?"on":""}`,children:[(0,t.jsxs)("span",{className:"bt-nav-ic",children:[i.icon,"/cart"===i.href&&a>0&&(0,t.jsx)("em",{className:"bt-nav-badge",children:a})]}),(0,t.jsx)("span",{children:i.label})]},i.href)})})}e.s(["default",0,function({header:e,children:r,footerExtra:i,overlay:n}){return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(a.default,{}),(0,t.jsx)("div",{className:"bt-stage",children:(0,t.jsxs)("main",{className:"bt-app",children:[e,(0,t.jsx)("div",{className:"bt-scroll",children:r}),(0,t.jsxs)("div",{className:"bt-footer",children:[i,(0,t.jsx)(s,{})]}),n]})})]})}],25045),e.s(["default",0,function({variant:e="page",title:a,onMenu:r,onAskBhaiya:n,showSearch:o=!1}){let s=(0,i.useRouter)();return"home"===e?(0,t.jsxs)("header",{className:"bt-head",children:[(0,t.jsxs)("div",{className:"bt-head-row",children:[(0,t.jsxs)("div",{className:"bt-brand",children:[(0,t.jsx)("span",{className:"brandmark",children:"B"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"bt-brand-name",children:"Bite Theory"}),(0,t.jsx)("div",{className:"bt-loc",children:"📍 Indore"})]})]}),(0,t.jsxs)("div",{className:"bt-head-actions",children:[n&&(0,t.jsxs)("button",{className:"bt-bhaiya-btn","aria-label":"Ask Bhaiya for a recommendation",onClick:n,children:["🧪 ",(0,t.jsx)("span",{className:"bt-bhaiya-label",children:"Ask Bhaiya"})]}),(0,t.jsx)("button",{className:"bt-icon-btn","aria-label":"Open menu",onClick:r,children:"☰"}),(0,t.jsx)("button",{className:"bt-avatar-btn","aria-label":"Open profile",onClick:r,children:"S"})]})]}),o&&(0,t.jsxs)("button",{className:"bt-search",children:[(0,t.jsx)("span",{children:"🔍"}),(0,t.jsx)("span",{className:"bt-search-ph",children:"Search thali, healthy meals, snacks…"})]})]}):(0,t.jsx)("header",{className:"bt-head bt-head--page",children:(0,t.jsxs)("div",{className:"bt-head-row",children:[(0,t.jsx)("button",{className:"bt-icon-btn","aria-label":"Go back",onClick:()=>s.back(),children:"‹"}),(0,t.jsx)("div",{className:"bt-page-title",children:a}),(0,t.jsx)("button",{className:"bt-icon-btn","aria-label":"Open menu",onClick:r,children:"☰"})]})})}],74539)},37237,41222,e=>{"use strict";var t=e.i(43476),a=e.i(71645),r=e.i(61928);e.s(["default",0,function({src:e,alt:i,emoji:n,className:o}){let[s,l]=(0,a.useState)(!1);return!e||s?(0,t.jsx)("span",{className:`food-emoji ${o||""}`,children:n}):(0,t.jsx)("img",{src:(0,r.imgUrl)(e),alt:i,className:o,loading:"lazy",onError:()=>l(!0)})}],37237),e.s(["useCatalog",0,function(){let[e,t]=(0,a.useState)([]),[i,n]=(0,a.useState)([]),[o,s]=(0,a.useState)(!0),[l,d]=(0,a.useState)("");return(0,a.useEffect)(()=>{let e=!0;return(async()=>{try{let{products:a,categories:i}=await (0,r.fetchCatalog)();if(!e)return;t(a),n(i)}catch{e&&d("Menu load nahi hua. Thodi der baad try karein.")}finally{e&&s(!1)}})(),()=>{e=!1}},[]),{products:e,categories:i,loading:o,error:l}}],41222)},60134,10578,e=>{"use strict";var t=e.i(43476),a=e.i(22016),r=e.i(18566),i=e.i(61928),n=e.i(74114),o=e.i(37237);e.s(["default",0,function({p:e}){let{cart:s,add:l,sub:d}=(0,n.useCart)();(0,r.useRouter)();let c=s[e.id]||0,p=(0,i.hasOffer)(e);return(0,t.jsxs)("div",{className:"bt-card",children:[(0,t.jsxs)(a.default,{href:`/product/${e.id}`,className:"bt-card-img","aria-label":`View ${e.name}`,children:[(0,t.jsx)(o.default,{src:e.image,alt:e.name,emoji:(0,i.catEmoji)(e.name)}),(0,t.jsx)("span",{className:"veg-dot","aria-label":"Pure veg",children:(0,t.jsx)("i",{})}),p&&(0,t.jsxs)("span",{className:"bt-card-off",children:[(0,i.offerPct)(e),"% OFF"]})]}),(0,t.jsxs)("div",{className:"bt-card-body",children:[(0,t.jsx)(a.default,{href:`/product/${e.id}`,className:"bt-card-name-link",children:(0,t.jsx)("div",{className:"bt-card-name",children:e.name})}),e.description&&(0,t.jsx)("div",{className:"bt-card-desc",children:e.description}),(0,t.jsxs)("div",{className:"bt-card-tags",children:[e.calories>0&&(0,t.jsxs)("span",{className:"tag",children:[e.calories," cal"]}),e.protein>0&&(0,t.jsxs)("span",{className:"tag green",children:[e.protein,"g protein"]}),e.rating>0&&(0,t.jsxs)("span",{className:"tag orange",children:["★ ",e.rating.toFixed(1)]})]}),(0,t.jsxs)("div",{className:"bt-card-foot",children:[(0,t.jsxs)("div",{className:"bt-price",children:[(0,t.jsx)("b",{children:(0,i.money)((0,i.effectivePrice)(e))}),p&&(0,t.jsx)("s",{children:(0,i.money)(e.price)})]}),c>0?(0,t.jsxs)("div",{className:"bt-qty",children:[(0,t.jsx)("button",{onClick:()=>d(e.id),"aria-label":"Remove one",children:"−"}),(0,t.jsx)("span",{children:c}),(0,t.jsx)("button",{onClick:()=>l(e.id),"aria-label":"Add one",children:"+"})]}):(0,t.jsx)("button",{className:"bt-add",onClick:()=>l(e.id),children:"ADD"})]})]})]})}],60134);var s=e.i(41222);e.s(["default",0,function(){let{products:e}=(0,s.useCatalog)(),{count:a,totalFor:o}=(0,n.useCart)(),l=(0,r.useRouter)();if(0===a)return null;let d=o(e);return(0,t.jsxs)("div",{className:"bt-cartbar",children:[(0,t.jsxs)("div",{children:[(0,t.jsxs)("div",{className:"bt-cartbar-c",children:[a," item",a>1?"s":""]}),(0,t.jsx)("div",{className:"bt-cartbar-t",children:(0,i.money)(d)})]}),(0,t.jsx)("button",{className:"bt-cartbar-btn",onClick:()=>l.push("/cart"),children:"View Cart →"})]})}],10578)},31713,e=>{"use strict";var t=e.i(43476),a=e.i(71645),r=e.i(25045),i=e.i(74539),n=e.i(60134),o=e.i(10578),s=e.i(17255),l=e.i(61928);let d=[{ic:"🧾",label:"Order History"},{ic:"📍",label:"Saved Addresses"},{ic:"💳",label:"Wallet & Transactions"},{ic:"🎟️",label:"My Coupons"},{ic:"🎁",label:"Refer & Earn"},{ic:"❤️",label:"Favorites"},{ic:"⭐",label:"My Reviews"},{ic:"🛟",label:"Help & Support"},{ic:"ℹ️",label:"About Bite Theory"},{ic:"📄",label:"Terms & Privacy"}];function c({open:e,onClose:a}){let{data:r,status:i}=(0,s.useSession)(),n=r?.user,o="authenticated"===i,p=(n?.loyaltyLevel||"bronze").toString().toUpperCase();return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("div",{className:`drawer-scrim ${e?"on":""}`,onClick:a,"aria-hidden":!0}),(0,t.jsxs)("aside",{className:`drawer ${e?"on":""}`,"aria-hidden":!e,children:[(0,t.jsxs)("div",{className:"drawer-head",children:[(0,t.jsx)("button",{className:"drawer-x",onClick:a,"aria-label":"Close",children:"✕"}),(0,t.jsx)("div",{className:"drawer-head-title",children:"My Profile"}),o?(0,t.jsxs)("div",{className:"drawer-user",children:[n?.image?(0,t.jsx)("img",{className:"drawer-ava",src:n.image,alt:n.name||"You",referrerPolicy:"no-referrer"}):(0,t.jsx)("span",{className:"drawer-ava",children:function(e){if(!e)return"U";let t=e.trim().split(/\s+/);return((t[0]?.[0]||"")+(t[1]?.[0]||"")).toUpperCase()||"U"}(n?.name)}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"drawer-name",children:n?.name||"Bite Theory User"}),(0,t.jsx)("div",{className:"drawer-mail",children:n?.email}),(0,t.jsxs)("span",{className:"drawer-tier",children:["🏅 ",p," MEMBER"]})]})]}):(0,t.jsxs)("div",{className:"drawer-user",children:[(0,t.jsx)("span",{className:"drawer-ava",children:"👋"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"drawer-name",children:"Guest"}),(0,t.jsx)("div",{className:"drawer-mail",children:"Login to order & earn rewards"}),(0,t.jsx)("button",{onClick:()=>(0,s.signIn)("google"),className:"drawer-login-btn",children:"Login / Sign up →"})]})]})]}),o&&(0,t.jsxs)("div",{className:"drawer-stats",children:[(0,t.jsxs)("div",{className:"dstat",children:[(0,t.jsx)("b",{children:n?.ordersCount??"—"}),(0,t.jsx)("span",{children:"Orders"})]}),(0,t.jsxs)("div",{className:"dstat",children:[(0,t.jsx)("b",{style:{color:l.C.green},children:(0,l.money)(n?.walletBalance||0)}),(0,t.jsx)("span",{children:"Wallet"})]}),(0,t.jsxs)("div",{className:"dstat",children:[(0,t.jsx)("b",{style:{color:l.C.orange},children:n?.loyaltyPoints||0}),(0,t.jsx)("span",{children:"Points"})]})]}),(0,t.jsxs)("div",{className:"drawer-menu",children:[d.map(e=>(0,t.jsxs)("button",{className:"drawer-item",children:[(0,t.jsx)("span",{className:"di-ic",children:e.ic}),(0,t.jsx)("span",{className:"di-label",children:e.label}),(0,t.jsx)("span",{className:"di-arrow",children:"›"})]},e.label)),o&&(0,t.jsxs)("button",{className:"drawer-item logout",onClick:()=>(0,s.signOut)({callbackUrl:"/login"}),children:[(0,t.jsx)("span",{className:"di-ic",children:"↩️"}),(0,t.jsx)("span",{className:"di-label",children:"Logout"}),(0,t.jsx)("span",{className:"di-arrow",children:"›"})]})]})]}),(0,t.jsx)("style",{children:`
.drawer-scrim{position:fixed;top:0;bottom:0;left:50%;transform:translateX(-50%);
  width:100%;max-width:480px;background:rgba(13,59,46,.45);
  opacity:0;pointer-events:none;transition:opacity .3s;z-index:40}
.drawer-scrim.on{opacity:1;pointer-events:auto}
.drawer{position:fixed;top:0;bottom:0;right:0;left:auto;width:86%;max-width:330px;
  background:${l.C.bg};z-index:41;transform:translateX(105%);
  transition:transform .34s cubic-bezier(.4,0,.2,1);display:flex;flex-direction:column;
  box-shadow:-12px 0 40px rgba(0,0,0,.3);overflow-y:auto}
.drawer.on{transform:translateX(0)}
@media(min-width:520px){
  .drawer-scrim{top:18px;bottom:18px;height:calc(100vh - 36px);border-radius:30px}
  .drawer{top:18px;bottom:18px;height:calc(100vh - 36px);right:50%;margin-right:-240px;max-width:300px;border-radius:0 30px 30px 0}
}
.drawer-head{background:linear-gradient(135deg,${l.C.dark},${l.C.darkSoft});padding:16px 18px 20px;position:relative;border-radius:0 0 22px 22px}
.drawer-x{position:absolute;top:14px;right:14px;background:rgba(255,255,255,.14);border:none;color:#fff;
  width:30px;height:30px;border-radius:50%;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center}
.drawer-head-title{color:#fff;font-size:15px;font-weight:700;margin-bottom:16px}
.drawer-user{display:flex;align-items:center;gap:14px}
.drawer-ava{width:64px;height:64px;border-radius:50%;flex-shrink:0;object-fit:cover;
  background:linear-gradient(135deg,#a3c93a,${l.C.orange});display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:26px;font-weight:800}
.drawer-login-btn{margin-top:8px;background:${l.C.orange};color:#fff;border:none;font-size:12px;font-weight:800;
  padding:7px 14px;border-radius:20px;cursor:pointer}
.drawer-name{color:#fff;font-size:19px;font-weight:800;line-height:1.1}
.drawer-mail{color:#a9cdbf;font-size:12px;margin-top:3px}
.drawer-tier{display:inline-block;margin-top:7px;background:${l.C.orange};color:#fff;font-size:10px;font-weight:800;
  padding:3px 11px;border-radius:20px;letter-spacing:.4px}
.drawer-stats{display:flex;gap:10px;padding:14px 16px 4px}
.dstat{flex:1;background:#fff;border-radius:14px;padding:12px 6px;text-align:center;box-shadow:0 2px 10px rgba(13,59,46,.06)}
.dstat b{display:block;font-size:19px;font-weight:800;color:${l.C.ink}}
.dstat span{font-size:10px;color:${l.C.muted}}
.drawer-menu{padding:12px 16px 26px;display:flex;flex-direction:column;gap:0}
.drawer-item{display:flex;align-items:center;gap:13px;background:#fff;border:none;
  border-bottom:1px solid ${l.C.line};padding:15px 14px;cursor:pointer;text-align:left;width:100%}
.drawer-item:first-child{border-radius:14px 14px 0 0}
.drawer-item:last-child{border-radius:0 0 14px 14px;border-bottom:none}
.di-ic{font-size:18px;width:24px;text-align:center}
.di-label{flex:1;font-size:14px;font-weight:600;color:${l.C.ink}}
.drawer-item.logout{margin-top:14px;border-radius:14px}
.drawer-item.logout .di-label{color:#d64545}
.di-arrow{color:#c2cfc8;font-size:18px;font-weight:700}
      `})]})}console.log("dnjddb");let p=[{key:"healthy",emoji:"🥗",title:"Healthy / High Protein",sub:"Diet bowls, protein meals",match:e=>/health|protein|salad|bowl|diet/i.test(e.name)},{key:"indian",emoji:"🍛",title:"Indian Food",sub:"Thali, rajma chawal, sabzi",match:e=>/thali|indian|combo|meal|rice|dal|sabzi/i.test(e.name)},{key:"fast",emoji:"🍔",title:"Fast Food",sub:"Snacks, quick bites",match:e=>/fast|snack|burger|wrap|roll|quick/i.test(e.name)},{key:"surprise",emoji:"😋",title:"Surprise me!",sub:"Aaj ka best dikha do",match:()=>!1}];function f({onDone:e}){let[r,i]=(0,a.useState)(null),[n,o]=(0,a.useState)(!1),[s,d]=(0,a.useState)(!1);return(0,t.jsxs)("div",{className:`intro-wrap ${n?"intro-leave":""}`,children:[(0,t.jsx)("div",{className:"intro-amb","aria-hidden":!0,children:["🍛","🥗","🫓","🧃","🍮"].map((e,a)=>(0,t.jsx)("span",{className:`amb a${a}`,children:e},a))}),(0,t.jsxs)("div",{className:"intro-inner",children:[(0,t.jsxs)("div",{className:"intro-brand",children:[(0,t.jsx)("span",{className:"brandmark",children:"B"}),(0,t.jsx)("span",{children:"Bite Theory"}),(0,t.jsx)("button",{className:"intro-skip",onClick:()=>e(null),children:"Skip →"})]}),(0,t.jsxs)("div",{className:"intro-avatar-stage",children:[(0,t.jsx)("div",{className:"intro-glow"}),s?(0,t.jsx)("div",{className:"intro-avatar-fallback",children:"🧑‍🍳"}):(0,t.jsx)("img",{src:l.AVATAR_FULL,alt:"Theory Bhaiya",className:"intro-avatar",onError:()=>d(!0)}),(0,t.jsx)("span",{className:"intro-wave",children:"👋"}),(0,t.jsx)("span",{className:"intro-badge",children:"YOUR BITE AGENT 🧪"})]}),(0,t.jsxs)("div",{className:"intro-bubble",children:[(0,t.jsx)("div",{className:"intro-bubble-title",children:"Hello! Main hoon aapka Bite Agent 😄"}),(0,t.jsx)("div",{className:"intro-bubble-sub",children:"Bhaiyaaa, aaj kya khaane ka mann hai? Bata do, main perfect cheez dikha deta hoon!"})]}),(0,t.jsx)("div",{className:"intro-goals",children:p.map(a=>(0,t.jsxs)("button",{className:`intro-goal ${r===a.key?"sel":""}`,onClick:()=>{i(a.key),o(!0),setTimeout(()=>e(a),420)},children:[(0,t.jsx)("span",{className:"ig-emoji",children:a.emoji}),(0,t.jsxs)("span",{className:"ig-text",children:[(0,t.jsx)("span",{className:"ig-title",children:a.title}),(0,t.jsx)("span",{className:"ig-sub",children:a.sub})]}),(0,t.jsx)("span",{className:"ig-arrow",children:r===a.key?"✓":"›"})]},a.key))})]}),(0,t.jsx)("style",{children:`
.intro-wrap{position:fixed;top:0;bottom:0;left:50%;transform:translateX(-50%);
  width:100%;max-width:480px;z-index:100;
  background:linear-gradient(165deg,${l.C.dark} 0%,${l.C.darkSoft} 55%,#1a6349 100%);
  display:flex;justify-content:center;animation:fadeIn .4s ease;overflow:hidden}
@media(min-width:520px){.intro-wrap{top:18px;bottom:18px;height:calc(100vh - 36px);border-radius:30px}}
.intro-leave{animation:fadeOut .42s ease forwards}
.intro-amb{position:absolute;inset:0;pointer-events:none}
.amb{position:absolute;opacity:.15;font-size:24px}
.amb.a0{top:7%;left:10%;animation:floatA 5s ease-in-out infinite}
.amb.a1{top:12%;right:11%;animation:floatB 6s ease-in-out infinite}
.amb.a2{top:42%;left:7%;animation:floatA 7s ease-in-out infinite}
.amb.a3{top:38%;right:8%;animation:floatB 6.5s ease-in-out infinite}
.amb.a4{bottom:20%;left:14%;animation:floatA 5.5s ease-in-out infinite}
.intro-inner{position:relative;width:100%;max-width:430px;padding:20px 22px 26px;
  display:flex;flex-direction:column;min-height:100%;overflow-y:auto}
.intro-brand{display:flex;align-items:center;gap:8px;color:#fff;font-weight:700;font-size:14px}
.intro-brand .brandmark{width:28px;height:28px;font-size:15px}
.intro-skip{margin-left:auto;background:none;border:none;color:#8fb3a3;font-size:12px;cursor:pointer}
.intro-avatar-stage{position:relative;height:230px;display:flex;align-items:flex-end;justify-content:center;margin-top:6px}
.intro-glow{position:absolute;top:10%;left:50%;transform:translateX(-50%);width:230px;height:230px;border-radius:50%;
  background:radial-gradient(circle,rgba(76,175,80,.45),transparent 68%)}
.intro-avatar{position:relative;max-height:230px;width:auto;object-fit:contain;
  filter:drop-shadow(0 14px 22px rgba(0,0,0,.32));animation:bob 3.2s ease-in-out infinite}
.intro-avatar-fallback{display:flex;align-items:flex-end;justify-content:center;font-size:150px;line-height:1;
  position:relative;animation:bob 3.2s ease-in-out infinite}
.intro-wave{position:absolute;top:18px;right:24%;font-size:30px;animation:wave 1.3s ease-in-out infinite;transform-origin:bottom}
.intro-badge{position:absolute;bottom:-4px;left:50%;transform:translateX(-50%);
  background:${l.C.orange};color:#fff;font-size:10px;padding:4px 14px;border-radius:20px;white-space:nowrap;
  animation:pulse 2s ease-in-out infinite}
.intro-bubble{background:rgba(255,255,255,.97);border-radius:18px 18px 18px 5px;padding:14px 16px;margin:22px 0 14px;
  box-shadow:0 8px 24px rgba(0,0,0,.18)}
.intro-bubble-title{font-size:16px;font-weight:700;color:${l.C.ink};line-height:1.3}
.intro-bubble-sub{font-size:12.5px;color:#3a5a4d;margin-top:5px;line-height:1.4}
.intro-goals{display:flex;flex-direction:column;gap:9px;margin-top:auto}
.intro-goal{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.97);
  border:2px solid transparent;border-radius:14px;padding:12px 14px;cursor:pointer;text-align:left;
  transition:transform .12s,border-color .12s}
.intro-goal:active{transform:scale(.98)}
.intro-goal.sel{border-color:${l.C.green}}
.ig-emoji{font-size:24px}
.ig-text{flex:1;display:flex;flex-direction:column;min-width:0}
.ig-title{font-size:14px;font-weight:700;color:${l.C.ink}}
.ig-sub{font-size:11px;color:${l.C.muted}}
.ig-arrow{color:${l.C.green};font-size:18px;font-weight:700}
@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
@keyframes wave{0%,100%{transform:rotate(0)}50%{transform:rotate(22deg)}}
@keyframes floatA{0%,100%{transform:translateY(0)}50%{transform:translateY(-13px)}}
@keyframes floatB{0%,100%{transform:translateY(0)}50%{transform:translateY(11px)}}
@keyframes pulse{0%,100%{transform:translateX(-50%) scale(1)}50%{transform:translateX(-50%) scale(1.05)}}
@keyframes fadeOut{0%{opacity:1}100%{opacity:0;visibility:hidden}}
      `})]})}var x=e.i(18566),g=e.i(37237);let b=[{greet:"Aur bhaiyooo, kaise ho? 😄",push:"Ye try kiya? Ek number hai —"},{greet:"Bhaiyyaaa, bhookh lagi kya? 😋",push:"Hamare yaha ka ye dekho —"},{greet:"Aaiye aaiye! 🙏",push:"Aaj ye special bana hai —"},{greet:"Arre wah, aap aa gaye! 🤩",push:"Ye to aapke liye perfect hai —"}];function h({product:e,line:r,inCart:i,hasCart:n,onOrder:o,onClose:s}){let[d,c]=(0,a.useState)(!1),p=(0,x.useRouter)(),f=(0,l.hasOffer)(e);return(0,t.jsxs)("div",{className:`agent-wrap ${n?"has-cart":""}`,role:"dialog","aria-label":"Today's special",children:[(0,t.jsxs)("div",{className:"agent-card",children:[(0,t.jsxs)("div",{className:"agent-ribbon",children:[(0,t.jsx)("span",{className:"agent-spark",children:"✨"}),"TODAY'S SPECIAL"]}),(0,t.jsxs)("div",{className:"agent-head",children:[(0,t.jsx)("span",{className:"agent-face",children:d?(0,t.jsx)("span",{className:"agent-face-fb",children:"🧑‍🍳"}):(0,t.jsx)("img",{src:l.AVATAR_FACE,alt:"Theory Bhaiya",onError:()=>c(!0)})}),(0,t.jsxs)("div",{className:"agent-id",children:[(0,t.jsx)("div",{className:"agent-name",children:"Theory Bhaiya"}),(0,t.jsxs)("div",{className:"agent-online",children:[(0,t.jsx)("i",{className:"dot"})," online · aapke liye"]})]}),(0,t.jsx)("button",{className:"agent-x",onClick:s,"aria-label":"Close",children:"✕"})]}),(0,t.jsxs)("div",{className:"agent-body",children:[(0,t.jsxs)("div",{className:"agent-bubble",children:[(0,t.jsx)("div",{className:"agent-greet",children:r.greet}),(0,t.jsxs)("div",{className:"agent-push",children:[r.push," ",(0,t.jsx)("b",{children:e.name})," 🍛"]})]}),(0,t.jsxs)("div",{className:"agent-prod",onClick:()=>p.push(`/product/${e.id}`),style:{cursor:"pointer"},children:[(0,t.jsxs)("div",{className:"agent-prod-img",children:[(0,t.jsx)(g.default,{src:e.image,alt:e.name,emoji:(0,l.catEmoji)(e.name)}),(0,t.jsx)("span",{className:"veg-dot sm",children:(0,t.jsx)("i",{})})]}),(0,t.jsxs)("div",{className:"agent-prod-info",children:[(0,t.jsx)("div",{className:"agent-prod-name",children:e.name}),(0,t.jsxs)("div",{className:"agent-prod-tags",children:[e.calories>0&&(0,t.jsxs)("span",{className:"tag",children:[e.calories," cal"]}),e.protein>0&&(0,t.jsxs)("span",{className:"tag green",children:[e.protein,"g protein"]})]}),(0,t.jsxs)("div",{className:"agent-prod-price",children:[(0,t.jsx)("b",{children:(0,l.money)((0,l.effectivePrice)(e))}),f&&(0,t.jsx)("s",{children:(0,l.money)(e.price)}),f&&(0,t.jsxs)("span",{className:"agent-off",children:[(0,l.offerPct)(e),"% OFF"]})]})]})]}),(0,t.jsxs)("div",{className:"agent-actions",children:[(0,t.jsx)("button",{className:"agent-order",onClick:o,children:i?"Add one more 🛒":"Order Now 🛒"}),(0,t.jsx)("button",{className:"agent-see",onClick:()=>p.push(`/product/${e.id}`),children:"Dekho →"})]})]})]}),(0,t.jsx)("style",{children:`
.agent-wrap{position:absolute;left:0;right:0;bottom:70px;padding:0 12px;z-index:26;pointer-events:none}
.agent-wrap.has-cart{bottom:122px}
.agent-card{pointer-events:auto;background:#fff;border-radius:20px;
  box-shadow:0 18px 50px rgba(13,59,46,.30);overflow:hidden;
  animation:popIn .5s cubic-bezier(.2,.9,.3,1.2);border:1px solid #d9efdc}
.agent-ribbon{background:linear-gradient(90deg,${l.C.orange},#f7a73a);color:#fff;font-size:10.5px;font-weight:800;
  letter-spacing:.8px;padding:5px 14px;display:flex;align-items:center;gap:6px}
.agent-spark{font-size:11px}
.agent-head{background:linear-gradient(135deg,${l.C.green},#3b8c3f);padding:10px 13px;display:flex;align-items:center;gap:10px}
.agent-face{width:34px;height:34px;border-radius:50%;background:#fff;overflow:hidden;flex-shrink:0;
  animation:bob 2.4s ease-in-out infinite;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.18)}
.agent-face img{width:100%;height:100%;object-fit:cover}
.agent-face-fb{font-size:19px}
.agent-id{flex:1;min-width:0}
.agent-name{color:#fff;font-size:13px;font-weight:700}
.agent-online{color:#d6f5e0;font-size:9px;display:flex;align-items:center;gap:4px}
.agent-online .dot{width:6px;height:6px;border-radius:50%;background:#aef5c0;display:inline-block;animation:pulseDot 1.6s ease-in-out infinite}
.agent-x{background:rgba(255,255,255,.18);border:none;color:#fff;font-size:13px;width:24px;height:24px;border-radius:50%;
  cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.agent-body{padding:12px 13px}
.agent-bubble{background:${l.C.bg};border-radius:13px 13px 13px 4px;padding:10px 12px;margin-bottom:10px}
.agent-greet{font-size:13.5px;color:${l.C.ink};font-weight:700}
.agent-push{font-size:12px;color:#3a5a4d;margin-top:2px}
.agent-prod{display:flex;gap:11px;background:#fff;border:1.5px solid ${l.C.greenSoft};border-radius:14px;padding:9px;align-items:center}
.agent-prod-img{width:58px;height:58px;border-radius:12px;background:${l.C.orangeSoft};display:flex;align-items:center;
  justify-content:center;flex-shrink:0;position:relative;overflow:hidden}
.agent-prod-img img{width:100%;height:100%;object-fit:cover}
.agent-prod-img .food-emoji{font-size:28px}
.agent-prod-info{flex:1;min-width:0}
.agent-prod-name{font-size:13px;font-weight:700;color:${l.C.ink};white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.agent-prod-tags{display:flex;gap:4px;margin:3px 0 4px;flex-wrap:wrap}
.agent-prod-price{display:flex;align-items:center;flex-wrap:wrap}
.agent-prod-price b{font-size:15px;font-weight:800}
.agent-prod-price s{font-size:10px;color:#9aa8a0;margin-left:5px}
.agent-off{font-size:8.5px;background:${l.C.orangeSoft};color:${l.C.orangeDeep};padding:2px 6px;border-radius:5px;font-weight:800;margin-left:6px}
.agent-actions{display:flex;gap:8px;margin-top:11px}
.agent-order{flex:1;background:linear-gradient(135deg,${l.C.green},${l.C.greenDeep});color:#fff;border:none;font-size:13px;
  font-weight:800;padding:11px;border-radius:11px;cursor:pointer;box-shadow:0 6px 16px rgba(76,175,80,.35)}
.agent-see{background:#fff;color:${l.C.ink};border:1.5px solid ${l.C.line};font-size:13px;font-weight:700;padding:11px 15px;border-radius:11px;cursor:pointer}
@keyframes popIn{0%{transform:translateY(40px) scale(.96);opacity:0}100%{transform:translateY(0) scale(1);opacity:1}}
@keyframes pulseDot{0%,100%{opacity:1}50%{opacity:.4}}
@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
      `})]})}var u=e.i(41222),m=e.i(74114);e.s(["default",0,function(){let{products:e,categories:s,loading:d,error:p}=(0,u.useCatalog)(),{add:x,cart:g}=(0,m.useCart)(),[y,w]=(0,a.useState)("all"),[j,k]=(0,a.useState)("pop"),[v,C]=(0,a.useState)(!1),[N,$]=(0,a.useState)(!1),[z,S]=(0,a.useState)(null),[P,O]=(0,a.useState)(null),[T,A]=(0,a.useState)(!1),[_]=(0,a.useState)(()=>Math.floor(Math.random()*b.length));function E(){A(!0);try{sessionStorage.setItem("bt_special_closed","1")}catch{}}(0,a.useEffect)(()=>{try{localStorage.getItem("bt_intro_seen")!==new Date().toDateString()&&$(!0)}catch{$(!0)}try{"1"===sessionStorage.getItem("bt_special_closed")&&A(!0)}catch{}},[]),(0,a.useEffect)(()=>{if(!z||"surprise"===z.key||!s.length)return;let e=s.find(e=>z.match(e));e&&w(e.id)},[z,s]),(0,a.useEffect)(()=>{if(d||!e.length||T)return;let t=setTimeout(()=>{O(e.filter(e=>e.offerPrice>0&&e.offerPrice<e.price).sort((e,t)=>t.price-t.offerPrice-(e.price-e.offerPrice))[0]||e[0])},2800);return()=>clearTimeout(t)},[d,e,T]);let B=(0,a.useMemo)(()=>{let t=[..."all"===y?e:e.filter(e=>e.categoryId===y)];return"protein"===j?t.sort((e,t)=>t.protein-e.protein):"lowcal"===j?t.sort((e,t)=>e.calories-t.calories):"cheap"===j?t.sort((e,t)=>(e.offerPrice||e.price)-(t.offerPrice||t.price)):t.sort((e,t)=>t.rating-e.rating),t},[e,y,j]);return(0,t.jsxs)(r.default,{header:(0,t.jsx)(i.default,{variant:"home",showSearch:!0,onMenu:()=>C(!0),onAskBhaiya:()=>$(!0)}),footerExtra:(0,t.jsx)(o.default,{}),overlay:(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(c,{open:v,onClose:()=>C(!1)}),P&&!T&&(0,t.jsx)(h,{product:P,line:b[_],inCart:(g[P.id]||0)>0,hasCart:Object.keys(g).length>0,onOrder:()=>{x(P.id),E()},onClose:E}),N&&(0,t.jsx)(f,{onDone:function(e){S(e),$(!1);try{localStorage.setItem("bt_intro_seen",new Date().toDateString())}catch{}e&&"surprise"!==e.key&&setTimeout(()=>{document.getElementById("catrow")?.scrollIntoView({behavior:"smooth",block:"start"})},350)}})]}),children:[(0,t.jsxs)("section",{className:"bt-hero",children:[(0,t.jsx)("span",{className:"bt-veg-badge",children:"100% PURE VEG"}),(0,t.jsxs)("h1",{className:"bt-hero-title",children:["Smart Food.",(0,t.jsx)("br",{}),"Better Living."]}),(0,t.jsx)("p",{className:"bt-hero-sub",children:"Good food. Right price. Under ₹99 combos."})]}),(0,t.jsx)("section",{className:"bt-cats",id:"catrow",children:(0,t.jsxs)("div",{className:"bt-cat-scroll",children:[(0,t.jsxs)("button",{className:`bt-cat ${"all"===y?"on":""}`,onClick:()=>w("all"),children:[(0,t.jsx)("span",{className:"bt-cat-ic",style:{background:l.C.orangeSoft},children:"🍽️"}),(0,t.jsx)("span",{className:"bt-cat-lbl",children:"All"})]}),d?Array.from({length:5}).map((e,a)=>(0,t.jsxs)("div",{className:"bt-cat",children:[(0,t.jsx)("span",{className:"bt-cat-ic skel"}),(0,t.jsx)("span",{className:"bt-cat-lbl skel-txt"})]},a)):s.map((e,a)=>(0,t.jsxs)("button",{className:`bt-cat ${y===e.id?"on":""}`,onClick:()=>w(e.id),children:[(0,t.jsx)("span",{className:"bt-cat-ic",style:{background:a%2?l.C.greenSoft:l.C.orangeSoft},children:e.image?(0,t.jsx)("img",{src:e.image,alt:e.name}):e.emoji}),(0,t.jsx)("span",{className:"bt-cat-lbl",children:e.name})]},e.id))]})}),(0,t.jsxs)("section",{className:"bt-offers",children:[(0,t.jsxs)("div",{className:"bt-offer dark",children:[(0,t.jsx)("span",{className:"bt-offer-ic",style:{background:l.C.orange},children:"%"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"bt-offer-t",children:"70% OFF up to ₹100"}),(0,t.jsx)("div",{className:"bt-offer-s",children:"USE BITE70"})]})]}),(0,t.jsxs)("div",{className:"bt-offer soft",children:[(0,t.jsx)("span",{className:"bt-offer-ic",style:{background:l.C.green},children:"🍛"}),(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:"bt-offer-t",style:{color:"#854f0b"},children:"Thali at ₹99"}),(0,t.jsx)("div",{className:"bt-offer-s",style:{color:"#ba7517"},children:"TODAY ONLY"})]})]})]}),(0,t.jsx)("section",{className:"bt-filters",children:[["pop","Sort by"],["protein","High Protein"],["lowcal","Under 400 cal"],["cheap","Cheapest"]].map(([e,a])=>(0,t.jsx)("button",{className:`bt-chip ${j===e?"on":""}`,onClick:()=>k(e),children:a},e))}),(0,t.jsxs)("section",{className:"bt-products",children:[(0,t.jsx)("h2",{className:"bt-sec-title",children:"all"===y?"Popular near you":s.find(e=>e.id===y)?.name||"Menu"}),p&&(0,t.jsx)("div",{className:"bt-empty",children:p}),d?Array.from({length:4}).map((e,a)=>(0,t.jsxs)("div",{className:"bt-card",children:[(0,t.jsx)("div",{className:"bt-card-img skel"}),(0,t.jsxs)("div",{className:"bt-card-body",children:[(0,t.jsx)("div",{className:"skel-txt",style:{width:"60%"}}),(0,t.jsx)("div",{className:"skel-txt",style:{width:"90%"}}),(0,t.jsx)("div",{className:"skel-txt",style:{width:"40%"}})]})]},a)):0===B.length?(0,t.jsx)("div",{className:"bt-empty",children:"Is category mein abhi kuch nahi hai. Doosri dekho!"}):B.map(e=>(0,t.jsx)(n.default,{p:e},e.id))]}),(0,t.jsx)("div",{style:{height:16}})]})},"dynamic",0,"force-dynamic"],31713)}]);