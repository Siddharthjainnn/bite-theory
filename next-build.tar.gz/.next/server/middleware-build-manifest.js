globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/w4u7ScXq45YGWlmZBUswU/_buildManifest.js",
    "static/w4u7ScXq45YGWlmZBUswU/_ssgManifest.js",
    "static/w4u7ScXq45YGWlmZBUswU/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/10qk6v6416kh8.js",
    "static/chunks/07-hzktxqjvzd.js",
    "static/chunks/11oof8oxnxiv9.js",
    "static/chunks/2nykiepra7i1k.js",
    "static/chunks/turbopack-0oc8o0e657vtx.js"
  ]
};
