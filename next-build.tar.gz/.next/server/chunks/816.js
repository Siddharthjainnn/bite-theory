exports.id=816,exports.ids=[816],exports.modules={1817:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,95547,23)),Promise.resolve().then(c.t.bind(c,15098,23)),Promise.resolve().then(c.t.bind(c,47644,23)),Promise.resolve().then(c.t.bind(c,33859,23)),Promise.resolve().then(c.t.bind(c,98099,23)),Promise.resolve().then(c.t.bind(c,16237,23)),Promise.resolve().then(c.t.bind(c,98562,23)),Promise.resolve().then(c.t.bind(c,36675,23))},4183:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,95547,23))},5710:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(77943).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\Users\\\\DELL\\\\Desktop\\\\bite-theory\\\\app\\\\providers\\\\AuthProvider.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\DELL\\Desktop\\bite-theory\\app\\providers\\AuthProvider.tsx","default")},32056:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>h,metadata:()=>g});var d=c(5735);c(82704);var e=c(42390),f=c(5710);let g={title:"Bite Theory — Smart Food, Better Living",description:"100% pure veg. Good food, right price. Indore."};function h({children:a}){return(0,d.jsx)("html",{lang:"en",children:(0,d.jsx)("body",{style:{margin:0},children:(0,d.jsx)(f.default,{children:(0,d.jsx)(e.CartProvider,{children:a})})})})}},38265:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,81921,23)),Promise.resolve().then(c.t.bind(c,60440,23)),Promise.resolve().then(c.t.bind(c,84342,23)),Promise.resolve().then(c.t.bind(c,82265,23)),Promise.resolve().then(c.t.bind(c,35421,23)),Promise.resolve().then(c.t.bind(c,61335,23)),Promise.resolve().then(c.t.bind(c,70664,23)),Promise.resolve().then(c.bind(c,74661))},42390:(a,b,c)=>{"use strict";c.d(b,{CartProvider:()=>e});var d=c(77943);let e=(0,d.registerClientReference)(function(){throw Error("Attempted to call CartProvider() from the server but CartProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\DELL\\Desktop\\bite-theory\\app\\providers\\CartProvider.tsx","CartProvider");(0,d.registerClientReference)(function(){throw Error("Attempted to call useCart() from the server but useCart is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\Users\\DELL\\Desktop\\bite-theory\\app\\providers\\CartProvider.tsx","useCart")},49468:(a,b,c)=>{"use strict";c.d(b,{CartProvider:()=>h,_:()=>i});var d=c(48249),e=c(67484),f=c(85226);let g=(0,e.createContext)(null);function h({children:a}){let[b,c]=(0,e.useState)({}),[i,j]=(0,e.useState)([]),[k,l]=(0,e.useState)([]),[m,n]=(0,e.useState)(!1),o=(0,e.useMemo)(()=>Object.values(b).reduce((a,b)=>a+b,0),[b]);return(0,d.jsx)(g.Provider,{value:{cart:b,add:a=>c(b=>({...b,[a]:(b[a]||0)+1})),sub:a=>c(b=>{let c={...b};return(c[a]||0)>1?c[a]-=1:delete c[a],c}),remove:a=>c(b=>{let c={...b};return delete c[a],c}),setQty:(a,b)=>c(c=>{let d={...c};return b<=0?delete d[a]:d[a]=b,d}),clear:()=>c({}),count:o,totalFor:a=>Object.entries(b).reduce((b,[c,d])=>{let e=a.find(a=>a.id===Number(c));return b+(e?(0,f.ns)(e)*d:0)},0),orders:i,placeOrder:a=>{let d=Object.entries(b);if(!d.length)return null;let e=d.map(([b,c])=>{let d=a.find(a=>a.id===Number(b));return d?{id:d.id,name:d.name,image:d.image,price:(0,f.ns)(d),qty:c}:null}).filter(Boolean);if(!e.length)return null;let g=e.reduce((a,b)=>a+b.price*b.qty,0),h={id:"BT"+Date.now().toString().slice(-8),createdAt:Date.now(),items:e,total:g,status:"placed"};return j(a=>[h,...a]),c({}),h},recent:k,markViewed:a=>l(b=>[a,...b.filter(b=>b!==a)].slice(0,12))},children:a})}function i(){let a=(0,e.useContext)(g);if(!a)throw Error("useCart must be used inside <CartProvider>");return a}},52923:(a,b,c)=>{Promise.resolve().then(c.bind(c,5710)),Promise.resolve().then(c.bind(c,42390))},57327:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,81921,23))},69644:(a,b,c)=>{"use strict";c.d(b,{default:()=>f});var d=c(48249),e=c(17546);function f({children:a}){return(0,d.jsx)(e.SessionProvider,{basePath:"/auth",children:a})}},78335:()=>{},82704:()=>{},85226:(a,b,c)=>{"use strict";c.d(b,{C:()=>g,CY:()=>f,JU:()=>i,KE:()=>p,S1:()=>m,TG:()=>h,dL:()=>j,jQ:()=>o,ns:()=>n,w7:()=>e});let d="https://bitestheory.com/api",e=`${d}/uploads/theory-bhaiya-avatar.png`,f=`${d}/uploads/theory-bhaiya-face.png`,g={green:"#4CAF50",greenDeep:"#2e7d32",dark:"#0D3B2E",darkSoft:"#13503c",orange:"#F59E0B",orangeDeep:"#b76e00",ink:"#0D3B2E",muted:"#6b7d74",line:"#e4ebe6",bg:"#f4f6f3",greenSoft:"#e8f5e9",orangeSoft:"#fef3e2"},h=a=>"₹"+Number(a||0).toLocaleString("en-IN");function i(a){return a?a.startsWith("http")?a:`${d}/uploads/${a.replace(/^\/+/,"")}`:""}function j(a){let b=(a||"").toLowerCase();return/thali/.test(b)?"\uD83C\uDF5B":/health|salad|diet/.test(b)?"\uD83E\uDD57":/protein|gym|muscle/.test(b)?"\uD83D\uDCAA":/break/.test(b)?"\uD83C\uDF73":/drink|bever|juice|shake/.test(b)?"\uD83E\uDD64":/snack|fast/.test(b)?"\uD83C\uDF54":/sweet|dessert/.test(b)?"\uD83C\uDF6E":/roll|wrap/.test(b)?"\uD83C\uDF2F":/pizza|pasta/.test(b)?"\uD83C\uDF55":"\uD83C\uDF7D️"}function k(a){return{id:Number(a.id),categoryId:Number(a.categoryId??a.category_id),name:a.name||"Item",slug:a.slug||"",description:a.description||"",image:a.image||"",price:Number(a.price)||0,offerPrice:Number(a.offerPrice??a.offer_price)||0,calories:Number(a.calories)||0,protein:Number(a.protein)||0,carbs:Number(a.carbs)||0,fat:Number(a.fat)||0,rating:Number(a.rating)||0}}function l(a){return{id:Number(a.id),name:a.name||"Category",slug:a.slug||"",image:a.image||"",emoji:j(a.name||"")}}async function m(){let[a,b]=await Promise.all([fetch(`${d}/products`),fetch(`${d}/categories`)]);if(!a.ok||!b.ok)throw Error("load failed");let c=await a.json(),e=await b.json();return{products:c.map(k),categories:e.filter(a=>void 0===a.isActive||a.isActive||a.is_active).map(l)}}function n(a){return a.offerPrice>0&&a.offerPrice<a.price?a.offerPrice:a.price}function o(a){return a.offerPrice>0&&a.offerPrice<a.price}function p(a){return o(a)?Math.round((1-a.offerPrice/a.price)*100):0}},89715:(a,b,c)=>{Promise.resolve().then(c.bind(c,69644)),Promise.resolve().then(c.bind(c,49468))},96481:(a,b,c)=>{"use strict";c.d(b,{A:()=>f});var d=c(48249),e=c(85226);function f(){return(0,d.jsx)("style",{children:`
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;padding:0;max-width:100%;overflow-x:hidden}
a{text-decoration:none;color:inherit}

/* stage = desktop backdrop + centered phone frame */
.bt-stage{height:100vh;min-height:100vh;width:100%;background:
  radial-gradient(900px 600px at 50% -10%, #16604733, transparent 60%),
  ${e.C.dark};
  display:flex;justify-content:center;align-items:stretch;
  padding:0;overflow:hidden}

/* app = full-height flex column: [header][scroll][footer] */
.bt-app{position:relative;width:100%;max-width:480px;background:${e.C.bg};
  height:100vh;max-height:100vh;overflow:hidden;
  display:flex;flex-direction:column;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
  color:${e.C.ink}}

.bt-scroll{flex:1 1 auto;overflow-y:auto;overflow-x:hidden;
  -webkit-overflow-scrolling:touch;scrollbar-width:none}
.bt-scroll::-webkit-scrollbar{display:none}

@media(min-width:520px){
  .bt-stage{padding:18px 0;align-items:center}
  .bt-app{height:calc(100vh - 36px);max-height:calc(100vh - 36px);
    margin:0;border-radius:30px;
    box-shadow:0 30px 90px rgba(0,0,0,.5);overflow:hidden}
  .bt-app .bt-head{border-radius:30px 30px 0 0}
}

.brandmark{width:34px;height:34px;border-radius:9px;
  background:linear-gradient(135deg,${e.C.green},${e.C.orange});display:flex;
  align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:18px;flex-shrink:0}

.food-emoji{display:flex;align-items:center;justify-content:center;width:100%;height:100%;font-size:34px;line-height:1}

/* ── header ── */
.bt-head{background:${e.C.dark};padding:14px 16px 16px;flex:0 0 auto;z-index:30}
.bt-head--page{padding:14px 12px}
.bt-head-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:0;gap:10px}
.bt-head .bt-search{margin-top:12px}
.bt-brand{display:flex;align-items:center;gap:9px;min-width:0}
.bt-brand-name{color:#fff;font-weight:700;font-size:15px;line-height:1}
.bt-loc{color:#8fb3a3;font-size:10px;margin-top:2px}
.bt-page-title{color:#fff;font-size:16px;font-weight:700;flex:1;text-align:center}
.bt-head-actions{display:flex;gap:8px;align-items:center;flex-shrink:0}
.bt-bhaiya-btn{border:none;cursor:pointer;border-radius:20px;
  background:linear-gradient(135deg,${e.C.orange},#f7a73a);color:#fff;
  font-size:11.5px;font-weight:800;padding:0 12px;height:36px;white-space:nowrap;
  display:flex;align-items:center;gap:4px;box-shadow:0 4px 12px rgba(245,158,11,.35)}
.bt-bhaiya-label{display:inline}
@media(max-width:360px){.bt-bhaiya-btn{padding:0 10px}.bt-bhaiya-label{display:none}}
.bt-icon-btn{width:36px;height:36px;border-radius:10px;border:none;
  background:rgba(255,255,255,.12);color:#fff;font-size:20px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;transition:background .15s}
.bt-icon-btn:hover{background:rgba(255,255,255,.2)}
.bt-avatar-btn{width:36px;height:36px;border-radius:50%;border:none;
  background:linear-gradient(135deg,#a3c93a,${e.C.orange});color:#fff;font-size:15px;
  font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center}
.bt-search{width:100%;background:#fff;border:none;border-radius:12px;
  padding:11px 13px;display:flex;align-items:center;gap:8px;cursor:pointer;text-align:left}
.bt-search-ph{color:#9aa8a0;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* ── hero ── */
.bt-hero{background:linear-gradient(135deg,${e.C.green},#3b8c3f);
  margin:12px;border-radius:18px;padding:16px}
.bt-veg-badge{display:inline-block;background:rgba(255,255,255,.2);color:#fff;
  font-size:10px;padding:3px 10px;border-radius:20px;margin-bottom:8px;letter-spacing:.5px}
.bt-hero-title{color:#fff;font-size:21px;font-weight:800;line-height:1.2;margin:0}
.bt-hero-sub{color:#eafdea;font-size:12px;margin:6px 0 0}

/* ── categories ── */
.bt-cats{padding:2px 0 0;max-width:100%}
.bt-cat-scroll{display:flex;gap:12px;overflow-x:auto;padding:8px 12px 4px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-cat-scroll::-webkit-scrollbar{display:none}
.bt-cat{flex-shrink:0;background:none;border:none;cursor:pointer;text-align:center;padding:0}
.bt-cat-ic{width:60px;height:60px;border-radius:17px;display:flex;align-items:center;
  justify-content:center;font-size:27px;overflow:hidden;transition:transform .15s}
.bt-cat-ic img{width:100%;height:100%;object-fit:cover}
.bt-cat-ic .food-emoji{font-size:27px}
.bt-cat.on .bt-cat-ic{transform:scale(1.06);box-shadow:0 0 0 2.5px ${e.C.green}}
.bt-cat-lbl{display:block;font-size:11px;color:${e.C.ink};margin-top:5px;max-width:64px;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bt-cat.on .bt-cat-lbl{font-weight:700;color:${e.C.green}}

/* ── offers ── */
.bt-offers{display:flex;gap:10px;overflow-x:auto;padding:12px 12px 4px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-offers::-webkit-scrollbar{display:none}
.bt-offer{flex-shrink:0;border-radius:14px;padding:12px 14px;display:flex;align-items:center;gap:10px;min-width:185px}
.bt-offer.dark{background:${e.C.dark}}
.bt-offer.soft{background:${e.C.orangeSoft}}
.bt-offer-ic{width:32px;height:32px;border-radius:9px;display:flex;align-items:center;
  justify-content:center;color:#fff;font-size:16px;font-weight:700;flex-shrink:0}
.bt-offer.dark .bt-offer-t{color:#fff;font-size:13px;font-weight:700}
.bt-offer.dark .bt-offer-s{color:#8fb3a3;font-size:10px}
.bt-offer-t{font-size:13px;font-weight:700}
.bt-offer-s{font-size:10px}

/* ── filters ── */
.bt-filters{display:flex;gap:7px;overflow-x:auto;padding:10px 12px 2px;
  scrollbar-width:none;-webkit-overflow-scrolling:touch}
.bt-filters::-webkit-scrollbar{display:none}
.bt-chip{flex-shrink:0;font-size:11.5px;padding:6px 13px;border-radius:20px;
  border:1px solid ${e.C.line};background:#fff;color:${e.C.ink};cursor:pointer;font-weight:600;white-space:nowrap}
.bt-chip.on{background:${e.C.dark};color:#fff;border-color:${e.C.dark}}

/* ── products ── */
.bt-products{padding:12px 12px 0}
.bt-sec-title{font-size:16px;font-weight:800;margin:4px 0 12px}
.bt-card{display:flex;gap:12px;background:#fff;border:1px solid ${e.C.line};
  border-radius:15px;padding:10px;margin-bottom:11px}
.bt-card-img{width:92px;height:92px;border-radius:11px;background:${e.C.greenSoft};
  display:flex;align-items:center;justify-content:center;flex-shrink:0;position:relative;overflow:hidden}
.bt-card-img img{width:100%;height:100%;object-fit:cover}
.bt-card-img .food-emoji{font-size:40px}
.veg-dot{position:absolute;top:6px;left:6px;width:15px;height:15px;border:1.5px solid ${e.C.green};
  border-radius:3px;background:#fff;display:flex;align-items:center;justify-content:center;z-index:2}
.veg-dot i{width:7px;height:7px;background:${e.C.green};border-radius:50%}
.veg-dot.sm{width:13px;height:13px}
.veg-dot.sm i{width:6px;height:6px}
.bt-card-off{position:absolute;bottom:6px;left:6px;background:${e.C.orange};color:#fff;
  font-size:9px;font-weight:800;padding:2px 6px;border-radius:5px;z-index:2}
.bt-card-body{flex:1;min-width:0;display:flex;flex-direction:column}
.bt-card-name{font-size:14px;font-weight:700}
.bt-card-name-link{color:inherit}
.bt-card-desc{font-size:11px;color:${e.C.muted};margin:2px 0 6px;
  display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden}
.bt-card-tags{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:7px}
.tag{font-size:9px;background:${e.C.bg};color:${e.C.muted};padding:2px 6px;border-radius:5px;font-weight:600;white-space:nowrap}
.tag.green{background:${e.C.greenSoft};color:#2e7d32}
.tag.orange{background:${e.C.orangeSoft};color:#b76e00}
.bt-card-foot{display:flex;align-items:center;justify-content:space-between;margin-top:auto;gap:8px}
.bt-price b{font-size:15px;font-weight:800}
.bt-price s{font-size:11px;color:#9aa8a0;margin-left:6px}
.bt-add{background:${e.C.green};color:#fff;border:none;font-size:12px;font-weight:700;
  padding:7px 18px;border-radius:9px;cursor:pointer;letter-spacing:.5px;flex-shrink:0}
.bt-qty{display:flex;align-items:center;gap:10px;background:${e.C.green};border-radius:9px;padding:5px 11px;flex-shrink:0}
.bt-qty button{background:none;border:none;color:#fff;font-size:17px;cursor:pointer;line-height:1;width:14px}
.bt-qty span{color:#fff;font-weight:700;font-size:13px;min-width:12px;text-align:center}
.bt-empty{background:#fff;border:1px dashed ${e.C.line};border-radius:14px;padding:32px 18px;
  text-align:center;color:${e.C.muted};font-size:13px}

/* ── skeletons ── */
.skel{background:linear-gradient(90deg,#eef2ee 25%,#e3e9e3 50%,#eef2ee 75%);
  background-size:200% 100%;animation:sh 1.3s infinite}
.skel-txt{height:11px;border-radius:5px;margin:5px 0;
  background:linear-gradient(90deg,#eef2ee 25%,#e3e9e3 50%,#eef2ee 75%);
  background-size:200% 100%;animation:sh 1.3s infinite}
@keyframes sh{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ── footer (cart bar + nav) ── */
.bt-footer{flex:0 0 auto;position:relative;z-index:25}
.bt-cartbar{background:${e.C.green};padding:12px 18px;display:flex;
  align-items:center;justify-content:space-between;animation:slideUpBar .4s ease}
.bt-cartbar-c{color:#eafdea;font-size:11px}
.bt-cartbar-t{color:#fff;font-weight:800;font-size:16px}
.bt-cartbar-btn{background:${e.C.orange};color:#fff;border:none;font-weight:800;
  padding:10px 20px;border-radius:22px;cursor:pointer;font-size:13px}
.bt-nav{background:#fff;border-top:1px solid ${e.C.line};display:flex;justify-content:space-around;
  padding:8px 0 10px}
.bt-nav-i{background:none;border:none;cursor:pointer;display:flex;flex-direction:column;
  align-items:center;gap:1px;color:#9aa8a0;font-size:9px;position:relative}
.bt-nav-ic{font-size:19px;position:relative;display:inline-block}
.bt-nav-i.on{color:${e.C.green}}
.bt-nav-badge{position:absolute;top:-6px;right:-10px;background:${e.C.orange};color:#fff;
  font-style:normal;font-size:9px;font-weight:700;min-width:15px;height:15px;border-radius:8px;
  display:flex;align-items:center;justify-content:center;padding:0 3px}

/* ── generic page bits ── */
.bt-page-pad{padding:14px 12px}
.bt-section-h{font-size:15px;font-weight:800;margin:18px 12px 10px}

/* ── product detail ── */
.pd-hero{position:relative;width:100%;aspect-ratio:1/1;max-height:340px;background:${e.C.greenSoft};
  display:flex;align-items:center;justify-content:center;overflow:hidden}
.pd-hero img{width:100%;height:100%;object-fit:cover}
.pd-hero .food-emoji{font-size:120px}
.pd-hero-off{position:absolute;top:14px;left:14px;background:${e.C.orange};color:#fff;
  font-size:12px;font-weight:800;padding:5px 12px;border-radius:8px}
.pd-veg{position:absolute;top:14px;right:14px;width:22px;height:22px;border:2px solid ${e.C.green};
  border-radius:4px;background:#fff;display:flex;align-items:center;justify-content:center}
.pd-veg i{width:10px;height:10px;background:${e.C.green};border-radius:50%}
.pd-body{padding:16px 16px 0}
.pd-name{font-size:22px;font-weight:800;line-height:1.2}
.pd-rating{display:inline-flex;align-items:center;gap:4px;background:${e.C.greenSoft};
  color:${e.C.greenDeep};font-size:12px;font-weight:700;padding:3px 9px;border-radius:8px;margin-top:8px}
.pd-desc{font-size:13.5px;color:#3a5a4d;line-height:1.5;margin:12px 0 4px}
.pd-price{display:flex;align-items:baseline;gap:10px;margin:14px 0 4px}
.pd-price b{font-size:26px;font-weight:800}
.pd-price s{font-size:15px;color:#9aa8a0}
.pd-price .pd-save{font-size:12px;font-weight:800;color:${e.C.greenDeep};background:${e.C.greenSoft};
  padding:3px 9px;border-radius:7px}
.pd-macros{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin:18px 0 6px}
.pd-macro{background:#fff;border:1px solid ${e.C.line};border-radius:13px;padding:12px 6px;text-align:center}
.pd-macro b{display:block;font-size:17px;font-weight:800;color:${e.C.ink}}
.pd-macro span{font-size:10px;color:${e.C.muted}}
.pd-macro.cal b{color:${e.C.orange}}
.pd-macro.pro b{color:${e.C.green}}

/* ── cart ── */
.cart-item{display:flex;gap:12px;background:#fff;border:1px solid ${e.C.line};
  border-radius:15px;padding:10px;margin-bottom:11px;align-items:center}
.cart-item-img{width:70px;height:70px;border-radius:11px;background:${e.C.greenSoft};
  display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;position:relative}
.cart-item-img img{width:100%;height:100%;object-fit:cover}
.cart-item-img .food-emoji{font-size:30px}
.cart-item-info{flex:1;min-width:0}
.cart-item-name{font-size:14px;font-weight:700}
.cart-item-price{font-size:13px;color:${e.C.muted};margin-top:2px}
.cart-item-price b{color:${e.C.ink}}
.cart-remove{background:none;border:none;color:#c0392b;font-size:11px;cursor:pointer;margin-top:4px;padding:0}
.bill{background:#fff;border:1px solid ${e.C.line};border-radius:15px;padding:14px;margin-top:6px}
.bill-row{display:flex;justify-content:space-between;font-size:13px;color:#3a5a4d;margin-bottom:8px}
.bill-row.free{color:${e.C.green};font-weight:700}
.bill-hr{border:none;border-top:1px dashed ${e.C.line};margin:10px 0}
.bill-total{display:flex;justify-content:space-between;font-size:16px;font-weight:800;color:${e.C.ink}}
.coupon{display:flex;gap:8px;align-items:center;background:${e.C.orangeSoft};border:1px dashed ${e.C.orange};
  border-radius:12px;padding:10px 12px;margin:12px 0;font-size:12px;color:${e.C.orangeDeep};font-weight:700}
.checkout-bar{padding:12px 16px;background:#fff;border-top:1px solid ${e.C.line};
  display:flex;align-items:center;justify-content:space-between;gap:12px}
.checkout-total b{font-size:18px;font-weight:800}
.checkout-total span{display:block;font-size:11px;color:${e.C.muted}}
.checkout-btn{flex:1;max-width:200px;background:linear-gradient(135deg,${e.C.green},${e.C.greenDeep});
  color:#fff;border:none;font-size:15px;font-weight:800;padding:13px;border-radius:13px;cursor:pointer;
  box-shadow:0 6px 16px rgba(76,175,80,.35)}

/* ── orders ── */
.order-card{background:#fff;border:1px solid ${e.C.line};border-radius:15px;padding:14px;margin-bottom:12px}
.order-top{display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px}
.order-id{font-size:13px;font-weight:800}
.order-date{font-size:11px;color:${e.C.muted};margin-top:2px}
.order-status{font-size:10px;font-weight:800;padding:4px 10px;border-radius:20px;white-space:nowrap}
.order-status.placed{background:${e.C.orangeSoft};color:${e.C.orangeDeep}}
.order-status.preparing{background:${e.C.orangeSoft};color:${e.C.orangeDeep}}
.order-status.on_the_way{background:#e3f2fd;color:#1565c0}
.order-status.delivered{background:${e.C.greenSoft};color:${e.C.greenDeep}}
.order-items{display:flex;flex-direction:column;gap:6px}
.order-line{display:flex;justify-content:space-between;font-size:12.5px;color:#3a5a4d}
.order-foot{display:flex;justify-content:space-between;align-items:center;
  border-top:1px dashed ${e.C.line};margin-top:10px;padding-top:10px}
.order-total{font-size:14px;font-weight:800}
.order-reorder{background:${e.C.greenSoft};color:${e.C.greenDeep};border:none;font-size:12px;
  font-weight:700;padding:7px 14px;border-radius:9px;cursor:pointer}

/* ── menu page ── */
.menu-jump{display:flex;gap:7px;overflow-x:auto;padding:10px 12px;scrollbar-width:none;
  position:sticky;top:0;background:${e.C.bg};z-index:5}
.menu-jump::-webkit-scrollbar{display:none}
.menu-jump-chip{flex-shrink:0;font-size:11.5px;padding:6px 13px;border-radius:20px;
  border:1px solid ${e.C.line};background:#fff;color:${e.C.ink};cursor:pointer;font-weight:600;white-space:nowrap}
.menu-jump-chip.on{background:${e.C.dark};color:#fff;border-color:${e.C.dark}}
.menu-cat-h{display:flex;align-items:center;gap:8px;font-size:16px;font-weight:800;
  margin:18px 12px 10px;scroll-margin-top:60px}
.menu-cat-h .cnt{font-size:11px;font-weight:600;color:${e.C.muted}}

/* toast */
.toast{position:absolute;bottom:78px;left:50%;transform:translateX(-50%);
  background:${e.C.dark};color:#fff;font-size:13px;font-weight:600;padding:11px 18px;border-radius:24px;
  box-shadow:0 10px 30px rgba(0,0,0,.3);z-index:50;animation:toastIn .3s ease;white-space:nowrap}

/* keyframes */
@keyframes slideUpBar{0%{transform:translateY(100px)}100%{transform:translateY(0)}}
@keyframes toastIn{0%{transform:translate(-50%,20px);opacity:0}100%{transform:translate(-50%,0);opacity:1}}
@keyframes fadeIn{0%{opacity:0}100%{opacity:1}}

@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
    `})}},96487:()=>{}};