module.exports=[60350,a=>{"use strict";var b=a.i(87924),c=a.i(72131),d=a.i(42588),e=a.i(18192),f=a.i(69336),g=a.i(87516),h=a.i(75003),i=a.i(77281);let j=[{ic:"🧾",label:"Order History"},{ic:"📍",label:"Saved Addresses"},{ic:"💳",label:"Wallet & Transactions"},{ic:"🎟️",label:"My Coupons"},{ic:"🎁",label:"Refer & Earn"},{ic:"❤️",label:"Favorites"},{ic:"⭐",label:"My Reviews"},{ic:"🛟",label:"Help & Support"},{ic:"ℹ️",label:"About Bite Theory"},{ic:"📄",label:"Terms & Privacy"}];function k({open:a,onClose:c}){let{data:d,status:e}=(0,h.useSession)(),f=d?.user,g="authenticated"===e,l=(f?.loyaltyLevel||"bronze").toString().toUpperCase();return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("div",{className:`drawer-scrim ${a?"on":""}`,onClick:c,"aria-hidden":!0}),(0,b.jsxs)("aside",{className:`drawer ${a?"on":""}`,"aria-hidden":!a,children:[(0,b.jsxs)("div",{className:"drawer-head",children:[(0,b.jsx)("button",{className:"drawer-x",onClick:c,"aria-label":"Close",children:"✕"}),(0,b.jsx)("div",{className:"drawer-head-title",children:"My Profile"}),g?(0,b.jsxs)("div",{className:"drawer-user",children:[f?.image?(0,b.jsx)("img",{className:"drawer-ava",src:f.image,alt:f.name||"You",referrerPolicy:"no-referrer"}):(0,b.jsx)("span",{className:"drawer-ava",children:function(a){if(!a)return"U";let b=a.trim().split(/\s+/);return((b[0]?.[0]||"")+(b[1]?.[0]||"")).toUpperCase()||"U"}(f?.name)}),(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"drawer-name",children:f?.name||"Bite Theory User"}),(0,b.jsx)("div",{className:"drawer-mail",children:f?.email}),(0,b.jsxs)("span",{className:"drawer-tier",children:["🏅 ",l," MEMBER"]})]})]}):(0,b.jsxs)("div",{className:"drawer-user",children:[(0,b.jsx)("span",{className:"drawer-ava",children:"👋"}),(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"drawer-name",children:"Guest"}),(0,b.jsx)("div",{className:"drawer-mail",children:"Login to order & earn rewards"}),(0,b.jsx)("button",{onClick:()=>(0,h.signIn)("google"),className:"drawer-login-btn",children:"Login / Sign up →"})]})]})]}),g&&(0,b.jsxs)("div",{className:"drawer-stats",children:[(0,b.jsxs)("div",{className:"dstat",children:[(0,b.jsx)("b",{children:f?.ordersCount??"—"}),(0,b.jsx)("span",{children:"Orders"})]}),(0,b.jsxs)("div",{className:"dstat",children:[(0,b.jsx)("b",{style:{color:i.C.green},children:(0,i.money)(f?.walletBalance||0)}),(0,b.jsx)("span",{children:"Wallet"})]}),(0,b.jsxs)("div",{className:"dstat",children:[(0,b.jsx)("b",{style:{color:i.C.orange},children:f?.loyaltyPoints||0}),(0,b.jsx)("span",{children:"Points"})]})]}),(0,b.jsxs)("div",{className:"drawer-menu",children:[j.map(a=>(0,b.jsxs)("button",{className:"drawer-item",children:[(0,b.jsx)("span",{className:"di-ic",children:a.ic}),(0,b.jsx)("span",{className:"di-label",children:a.label}),(0,b.jsx)("span",{className:"di-arrow",children:"›"})]},a.label)),g&&(0,b.jsxs)("button",{className:"drawer-item logout",onClick:()=>(0,h.signOut)({callbackUrl:"/login"}),children:[(0,b.jsx)("span",{className:"di-ic",children:"↩️"}),(0,b.jsx)("span",{className:"di-label",children:"Logout"}),(0,b.jsx)("span",{className:"di-arrow",children:"›"})]})]})]}),(0,b.jsx)("style",{children:`
.drawer-scrim{position:fixed;top:0;bottom:0;left:50%;transform:translateX(-50%);
  width:100%;max-width:480px;background:rgba(13,59,46,.45);
  opacity:0;pointer-events:none;transition:opacity .3s;z-index:40}
.drawer-scrim.on{opacity:1;pointer-events:auto}
.drawer{position:fixed;top:0;bottom:0;right:0;left:auto;width:86%;max-width:330px;
  background:${i.C.bg};z-index:41;transform:translateX(105%);
  transition:transform .34s cubic-bezier(.4,0,.2,1);display:flex;flex-direction:column;
  box-shadow:-12px 0 40px rgba(0,0,0,.3);overflow-y:auto}
.drawer.on{transform:translateX(0)}
@media(min-width:520px){
  .drawer-scrim{top:18px;bottom:18px;height:calc(100vh - 36px);border-radius:30px}
  .drawer{top:18px;bottom:18px;height:calc(100vh - 36px);right:50%;margin-right:-240px;max-width:300px;border-radius:0 30px 30px 0}
}
.drawer-head{background:linear-gradient(135deg,${i.C.dark},${i.C.darkSoft});padding:16px 18px 20px;position:relative;border-radius:0 0 22px 22px}
.drawer-x{position:absolute;top:14px;right:14px;background:rgba(255,255,255,.14);border:none;color:#fff;
  width:30px;height:30px;border-radius:50%;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center}
.drawer-head-title{color:#fff;font-size:15px;font-weight:700;margin-bottom:16px}
.drawer-user{display:flex;align-items:center;gap:14px}
.drawer-ava{width:64px;height:64px;border-radius:50%;flex-shrink:0;object-fit:cover;
  background:linear-gradient(135deg,#a3c93a,${i.C.orange});display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:26px;font-weight:800}
.drawer-login-btn{margin-top:8px;background:${i.C.orange};color:#fff;border:none;font-size:12px;font-weight:800;
  padding:7px 14px;border-radius:20px;cursor:pointer}
.drawer-name{color:#fff;font-size:19px;font-weight:800;line-height:1.1}
.drawer-mail{color:#a9cdbf;font-size:12px;margin-top:3px}
.drawer-tier{display:inline-block;margin-top:7px;background:${i.C.orange};color:#fff;font-size:10px;font-weight:800;
  padding:3px 11px;border-radius:20px;letter-spacing:.4px}
.drawer-stats{display:flex;gap:10px;padding:14px 16px 4px}
.dstat{flex:1;background:#fff;border-radius:14px;padding:12px 6px;text-align:center;box-shadow:0 2px 10px rgba(13,59,46,.06)}
.dstat b{display:block;font-size:19px;font-weight:800;color:${i.C.ink}}
.dstat span{font-size:10px;color:${i.C.muted}}
.drawer-menu{padding:12px 16px 26px;display:flex;flex-direction:column;gap:0}
.drawer-item{display:flex;align-items:center;gap:13px;background:#fff;border:none;
  border-bottom:1px solid ${i.C.line};padding:15px 14px;cursor:pointer;text-align:left;width:100%}
.drawer-item:first-child{border-radius:14px 14px 0 0}
.drawer-item:last-child{border-radius:0 0 14px 14px;border-bottom:none}
.di-ic{font-size:18px;width:24px;text-align:center}
.di-label{flex:1;font-size:14px;font-weight:600;color:${i.C.ink}}
.drawer-item.logout{margin-top:14px;border-radius:14px}
.drawer-item.logout .di-label{color:#d64545}
.di-arrow{color:#c2cfc8;font-size:18px;font-weight:700}
      `})]})}console.log("dnjddb");let l=[{key:"healthy",emoji:"🥗",title:"Healthy / High Protein",sub:"Diet bowls, protein meals",match:a=>/health|protein|salad|bowl|diet/i.test(a.name)},{key:"indian",emoji:"🍛",title:"Indian Food",sub:"Thali, rajma chawal, sabzi",match:a=>/thali|indian|combo|meal|rice|dal|sabzi/i.test(a.name)},{key:"fast",emoji:"🍔",title:"Fast Food",sub:"Snacks, quick bites",match:a=>/fast|snack|burger|wrap|roll|quick/i.test(a.name)},{key:"surprise",emoji:"😋",title:"Surprise me!",sub:"Aaj ka best dikha do",match:()=>!1}];function m({onDone:a}){let[d,e]=(0,c.useState)(null),[f,g]=(0,c.useState)(!1),[h,j]=(0,c.useState)(!1);return(0,b.jsxs)("div",{className:`intro-wrap ${f?"intro-leave":""}`,children:[(0,b.jsx)("div",{className:"intro-amb","aria-hidden":!0,children:["🍛","🥗","🫓","🧃","🍮"].map((a,c)=>(0,b.jsx)("span",{className:`amb a${c}`,children:a},c))}),(0,b.jsxs)("div",{className:"intro-inner",children:[(0,b.jsxs)("div",{className:"intro-brand",children:[(0,b.jsx)("span",{className:"brandmark",children:"B"}),(0,b.jsx)("span",{children:"Bite Theory"}),(0,b.jsx)("button",{className:"intro-skip",onClick:()=>a(null),children:"Skip →"})]}),(0,b.jsxs)("div",{className:"intro-avatar-stage",children:[(0,b.jsx)("div",{className:"intro-glow"}),h?(0,b.jsx)("div",{className:"intro-avatar-fallback",children:"🧑‍🍳"}):(0,b.jsx)("img",{src:i.AVATAR_FULL,alt:"Theory Bhaiya",className:"intro-avatar",onError:()=>j(!0)}),(0,b.jsx)("span",{className:"intro-wave",children:"👋"}),(0,b.jsx)("span",{className:"intro-badge",children:"YOUR BITE AGENT 🧪"})]}),(0,b.jsxs)("div",{className:"intro-bubble",children:[(0,b.jsx)("div",{className:"intro-bubble-title",children:"Hello! Main hoon aapka Bite Agent 😄"}),(0,b.jsx)("div",{className:"intro-bubble-sub",children:"Bhaiyaaa, aaj kya khaane ka mann hai? Bata do, main perfect cheez dikha deta hoon!"})]}),(0,b.jsx)("div",{className:"intro-goals",children:l.map(c=>(0,b.jsxs)("button",{className:`intro-goal ${d===c.key?"sel":""}`,onClick:()=>{e(c.key),g(!0),setTimeout(()=>a(c),420)},children:[(0,b.jsx)("span",{className:"ig-emoji",children:c.emoji}),(0,b.jsxs)("span",{className:"ig-text",children:[(0,b.jsx)("span",{className:"ig-title",children:c.title}),(0,b.jsx)("span",{className:"ig-sub",children:c.sub})]}),(0,b.jsx)("span",{className:"ig-arrow",children:d===c.key?"✓":"›"})]},c.key))})]}),(0,b.jsx)("style",{children:`
.intro-wrap{position:fixed;top:0;bottom:0;left:50%;transform:translateX(-50%);
  width:100%;max-width:480px;z-index:100;
  background:linear-gradient(165deg,${i.C.dark} 0%,${i.C.darkSoft} 55%,#1a6349 100%);
  display:flex;justify-content:center;animation:fadeIn .4s ease;overflow:hidden}
@media(min-width:520px){.intro-wrap{top:18px;bottom:18px;height:calc(100vh - 36px);border-radius:30px}}
.intro-leave{animation:fadeOut .42s ease forwards}
.intro-amb{position:absolute;inset:0;pointer-events:none}
.amb{position:absolute;opacity:.15;font-size:24px}
.amb.a0{top:7%;left:10%;animation:floatA 5s ease-in-out infinite}
.amb.a1{top:12%;right:11%;animation:floatB 6s ease-in-out infinite}
.amb.a2{top:42%;left:7%;animation:floatA 7s ease-in-out infinite}
.amb.a3{top:38%;right:8%;animation:floatB 6.5s ease-in-out infinite}
.amb.a4{bottom:20%;left:14%;animation:floatA 5.5s ease-in-out infinite}
.intro-inner{position:relative;width:100%;max-width:430px;padding:20px 22px 26px;
  display:flex;flex-direction:column;min-height:100%;overflow-y:auto}
.intro-brand{display:flex;align-items:center;gap:8px;color:#fff;font-weight:700;font-size:14px}
.intro-brand .brandmark{width:28px;height:28px;font-size:15px}
.intro-skip{margin-left:auto;background:none;border:none;color:#8fb3a3;font-size:12px;cursor:pointer}
.intro-avatar-stage{position:relative;height:230px;display:flex;align-items:flex-end;justify-content:center;margin-top:6px}
.intro-glow{position:absolute;top:10%;left:50%;transform:translateX(-50%);width:230px;height:230px;border-radius:50%;
  background:radial-gradient(circle,rgba(76,175,80,.45),transparent 68%)}
.intro-avatar{position:relative;max-height:230px;width:auto;object-fit:contain;
  filter:drop-shadow(0 14px 22px rgba(0,0,0,.32));animation:bob 3.2s ease-in-out infinite}
.intro-avatar-fallback{display:flex;align-items:flex-end;justify-content:center;font-size:150px;line-height:1;
  position:relative;animation:bob 3.2s ease-in-out infinite}
.intro-wave{position:absolute;top:18px;right:24%;font-size:30px;animation:wave 1.3s ease-in-out infinite;transform-origin:bottom}
.intro-badge{position:absolute;bottom:-4px;left:50%;transform:translateX(-50%);
  background:${i.C.orange};color:#fff;font-size:10px;padding:4px 14px;border-radius:20px;white-space:nowrap;
  animation:pulse 2s ease-in-out infinite}
.intro-bubble{background:rgba(255,255,255,.97);border-radius:18px 18px 18px 5px;padding:14px 16px;margin:22px 0 14px;
  box-shadow:0 8px 24px rgba(0,0,0,.18)}
.intro-bubble-title{font-size:16px;font-weight:700;color:${i.C.ink};line-height:1.3}
.intro-bubble-sub{font-size:12.5px;color:#3a5a4d;margin-top:5px;line-height:1.4}
.intro-goals{display:flex;flex-direction:column;gap:9px;margin-top:auto}
.intro-goal{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.97);
  border:2px solid transparent;border-radius:14px;padding:12px 14px;cursor:pointer;text-align:left;
  transition:transform .12s,border-color .12s}
.intro-goal:active{transform:scale(.98)}
.intro-goal.sel{border-color:${i.C.green}}
.ig-emoji{font-size:24px}
.ig-text{flex:1;display:flex;flex-direction:column;min-width:0}
.ig-title{font-size:14px;font-weight:700;color:${i.C.ink}}
.ig-sub{font-size:11px;color:${i.C.muted}}
.ig-arrow{color:${i.C.green};font-size:18px;font-weight:700}
@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
@keyframes wave{0%,100%{transform:rotate(0)}50%{transform:rotate(22deg)}}
@keyframes floatA{0%,100%{transform:translateY(0)}50%{transform:translateY(-13px)}}
@keyframes floatB{0%,100%{transform:translateY(0)}50%{transform:translateY(11px)}}
@keyframes pulse{0%,100%{transform:translateX(-50%) scale(1)}50%{transform:translateX(-50%) scale(1.05)}}
@keyframes fadeOut{0%{opacity:1}100%{opacity:0;visibility:hidden}}
      `})]})}var n=a.i(50944),o=a.i(52935);let p=[{greet:"Aur bhaiyooo, kaise ho? 😄",push:"Ye try kiya? Ek number hai —"},{greet:"Bhaiyyaaa, bhookh lagi kya? 😋",push:"Hamare yaha ka ye dekho —"},{greet:"Aaiye aaiye! 🙏",push:"Aaj ye special bana hai —"},{greet:"Arre wah, aap aa gaye! 🤩",push:"Ye to aapke liye perfect hai —"}];function q({product:a,line:d,inCart:e,hasCart:f,onOrder:g,onClose:h}){let[j,k]=(0,c.useState)(!1),l=(0,n.useRouter)(),m=(0,i.hasOffer)(a);return(0,b.jsxs)("div",{className:`agent-wrap ${f?"has-cart":""}`,role:"dialog","aria-label":"Today's special",children:[(0,b.jsxs)("div",{className:"agent-card",children:[(0,b.jsxs)("div",{className:"agent-ribbon",children:[(0,b.jsx)("span",{className:"agent-spark",children:"✨"}),"TODAY'S SPECIAL"]}),(0,b.jsxs)("div",{className:"agent-head",children:[(0,b.jsx)("span",{className:"agent-face",children:j?(0,b.jsx)("span",{className:"agent-face-fb",children:"🧑‍🍳"}):(0,b.jsx)("img",{src:i.AVATAR_FACE,alt:"Theory Bhaiya",onError:()=>k(!0)})}),(0,b.jsxs)("div",{className:"agent-id",children:[(0,b.jsx)("div",{className:"agent-name",children:"Theory Bhaiya"}),(0,b.jsxs)("div",{className:"agent-online",children:[(0,b.jsx)("i",{className:"dot"})," online · aapke liye"]})]}),(0,b.jsx)("button",{className:"agent-x",onClick:h,"aria-label":"Close",children:"✕"})]}),(0,b.jsxs)("div",{className:"agent-body",children:[(0,b.jsxs)("div",{className:"agent-bubble",children:[(0,b.jsx)("div",{className:"agent-greet",children:d.greet}),(0,b.jsxs)("div",{className:"agent-push",children:[d.push," ",(0,b.jsx)("b",{children:a.name})," 🍛"]})]}),(0,b.jsxs)("div",{className:"agent-prod",onClick:()=>l.push(`/product/${a.id}`),style:{cursor:"pointer"},children:[(0,b.jsxs)("div",{className:"agent-prod-img",children:[(0,b.jsx)(o.default,{src:a.image,alt:a.name,emoji:(0,i.catEmoji)(a.name)}),(0,b.jsx)("span",{className:"veg-dot sm",children:(0,b.jsx)("i",{})})]}),(0,b.jsxs)("div",{className:"agent-prod-info",children:[(0,b.jsx)("div",{className:"agent-prod-name",children:a.name}),(0,b.jsxs)("div",{className:"agent-prod-tags",children:[a.calories>0&&(0,b.jsxs)("span",{className:"tag",children:[a.calories," cal"]}),a.protein>0&&(0,b.jsxs)("span",{className:"tag green",children:[a.protein,"g protein"]})]}),(0,b.jsxs)("div",{className:"agent-prod-price",children:[(0,b.jsx)("b",{children:(0,i.money)((0,i.effectivePrice)(a))}),m&&(0,b.jsx)("s",{children:(0,i.money)(a.price)}),m&&(0,b.jsxs)("span",{className:"agent-off",children:[(0,i.offerPct)(a),"% OFF"]})]})]})]}),(0,b.jsxs)("div",{className:"agent-actions",children:[(0,b.jsx)("button",{className:"agent-order",onClick:g,children:e?"Add one more 🛒":"Order Now 🛒"}),(0,b.jsx)("button",{className:"agent-see",onClick:()=>l.push(`/product/${a.id}`),children:"Dekho →"})]})]})]}),(0,b.jsx)("style",{children:`
.agent-wrap{position:absolute;left:0;right:0;bottom:70px;padding:0 12px;z-index:26;pointer-events:none}
.agent-wrap.has-cart{bottom:122px}
.agent-card{pointer-events:auto;background:#fff;border-radius:20px;
  box-shadow:0 18px 50px rgba(13,59,46,.30);overflow:hidden;
  animation:popIn .5s cubic-bezier(.2,.9,.3,1.2);border:1px solid #d9efdc}
.agent-ribbon{background:linear-gradient(90deg,${i.C.orange},#f7a73a);color:#fff;font-size:10.5px;font-weight:800;
  letter-spacing:.8px;padding:5px 14px;display:flex;align-items:center;gap:6px}
.agent-spark{font-size:11px}
.agent-head{background:linear-gradient(135deg,${i.C.green},#3b8c3f);padding:10px 13px;display:flex;align-items:center;gap:10px}
.agent-face{width:34px;height:34px;border-radius:50%;background:#fff;overflow:hidden;flex-shrink:0;
  animation:bob 2.4s ease-in-out infinite;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,.18)}
.agent-face img{width:100%;height:100%;object-fit:cover}
.agent-face-fb{font-size:19px}
.agent-id{flex:1;min-width:0}
.agent-name{color:#fff;font-size:13px;font-weight:700}
.agent-online{color:#d6f5e0;font-size:9px;display:flex;align-items:center;gap:4px}
.agent-online .dot{width:6px;height:6px;border-radius:50%;background:#aef5c0;display:inline-block;animation:pulseDot 1.6s ease-in-out infinite}
.agent-x{background:rgba(255,255,255,.18);border:none;color:#fff;font-size:13px;width:24px;height:24px;border-radius:50%;
  cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0}
.agent-body{padding:12px 13px}
.agent-bubble{background:${i.C.bg};border-radius:13px 13px 13px 4px;padding:10px 12px;margin-bottom:10px}
.agent-greet{font-size:13.5px;color:${i.C.ink};font-weight:700}
.agent-push{font-size:12px;color:#3a5a4d;margin-top:2px}
.agent-prod{display:flex;gap:11px;background:#fff;border:1.5px solid ${i.C.greenSoft};border-radius:14px;padding:9px;align-items:center}
.agent-prod-img{width:58px;height:58px;border-radius:12px;background:${i.C.orangeSoft};display:flex;align-items:center;
  justify-content:center;flex-shrink:0;position:relative;overflow:hidden}
.agent-prod-img img{width:100%;height:100%;object-fit:cover}
.agent-prod-img .food-emoji{font-size:28px}
.agent-prod-info{flex:1;min-width:0}
.agent-prod-name{font-size:13px;font-weight:700;color:${i.C.ink};white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.agent-prod-tags{display:flex;gap:4px;margin:3px 0 4px;flex-wrap:wrap}
.agent-prod-price{display:flex;align-items:center;flex-wrap:wrap}
.agent-prod-price b{font-size:15px;font-weight:800}
.agent-prod-price s{font-size:10px;color:#9aa8a0;margin-left:5px}
.agent-off{font-size:8.5px;background:${i.C.orangeSoft};color:${i.C.orangeDeep};padding:2px 6px;border-radius:5px;font-weight:800;margin-left:6px}
.agent-actions{display:flex;gap:8px;margin-top:11px}
.agent-order{flex:1;background:linear-gradient(135deg,${i.C.green},${i.C.greenDeep});color:#fff;border:none;font-size:13px;
  font-weight:800;padding:11px;border-radius:11px;cursor:pointer;box-shadow:0 6px 16px rgba(76,175,80,.35)}
.agent-see{background:#fff;color:${i.C.ink};border:1.5px solid ${i.C.line};font-size:13px;font-weight:700;padding:11px 15px;border-radius:11px;cursor:pointer}
@keyframes popIn{0%{transform:translateY(40px) scale(.96);opacity:0}100%{transform:translateY(0) scale(1);opacity:1}}
@keyframes pulseDot{0%,100%{opacity:1}50%{opacity:.4}}
@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
      `})]})}var r=a.i(21011),s=a.i(65337);a.s(["default",0,function(){let{products:a,categories:h,loading:j,error:l}=(0,r.useCatalog)(),{add:n,cart:o}=(0,s.useCart)(),[t,u]=(0,c.useState)("all"),[v,w]=(0,c.useState)("pop"),[x,y]=(0,c.useState)(!1),[z,A]=(0,c.useState)(!1),[B,C]=(0,c.useState)(null),[D,E]=(0,c.useState)(null),[F,G]=(0,c.useState)(!1),[H]=(0,c.useState)(()=>Math.floor(Math.random()*p.length));function I(){G(!0);try{sessionStorage.setItem("bt_special_closed","1")}catch{}}(0,c.useEffect)(()=>{try{localStorage.getItem("bt_intro_seen")!==new Date().toDateString()&&A(!0)}catch{A(!0)}try{"1"===sessionStorage.getItem("bt_special_closed")&&G(!0)}catch{}},[]),(0,c.useEffect)(()=>{if(!B||"surprise"===B.key||!h.length)return;let a=h.find(a=>B.match(a));a&&u(a.id)},[B,h]),(0,c.useEffect)(()=>{if(j||!a.length||F)return;let b=setTimeout(()=>{E(a.filter(a=>a.offerPrice>0&&a.offerPrice<a.price).sort((a,b)=>b.price-b.offerPrice-(a.price-a.offerPrice))[0]||a[0])},2800);return()=>clearTimeout(b)},[j,a,F]);let J=(0,c.useMemo)(()=>{let b=[..."all"===t?a:a.filter(a=>a.categoryId===t)];return"protein"===v?b.sort((a,b)=>b.protein-a.protein):"lowcal"===v?b.sort((a,b)=>a.calories-b.calories):"cheap"===v?b.sort((a,b)=>(a.offerPrice||a.price)-(b.offerPrice||b.price)):b.sort((a,b)=>b.rating-a.rating),b},[a,t,v]);return(0,b.jsxs)(d.default,{header:(0,b.jsx)(e.default,{variant:"home",showSearch:!0,onMenu:()=>y(!0),onAskBhaiya:()=>A(!0)}),footerExtra:(0,b.jsx)(g.default,{}),overlay:(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(k,{open:x,onClose:()=>y(!1)}),D&&!F&&(0,b.jsx)(q,{product:D,line:p[H],inCart:(o[D.id]||0)>0,hasCart:Object.keys(o).length>0,onOrder:()=>{n(D.id),I()},onClose:I}),z&&(0,b.jsx)(m,{onDone:function(a){C(a),A(!1);try{localStorage.setItem("bt_intro_seen",new Date().toDateString())}catch{}a&&"surprise"!==a.key&&setTimeout(()=>{document.getElementById("catrow")?.scrollIntoView({behavior:"smooth",block:"start"})},350)}})]}),children:[(0,b.jsxs)("section",{className:"bt-hero",children:[(0,b.jsx)("span",{className:"bt-veg-badge",children:"100% PURE VEG"}),(0,b.jsxs)("h1",{className:"bt-hero-title",children:["Smart Food.",(0,b.jsx)("br",{}),"Better Living."]}),(0,b.jsx)("p",{className:"bt-hero-sub",children:"Good food. Right price. Under ₹99 combos."})]}),(0,b.jsx)("section",{className:"bt-cats",id:"catrow",children:(0,b.jsxs)("div",{className:"bt-cat-scroll",children:[(0,b.jsxs)("button",{className:`bt-cat ${"all"===t?"on":""}`,onClick:()=>u("all"),children:[(0,b.jsx)("span",{className:"bt-cat-ic",style:{background:i.C.orangeSoft},children:"🍽️"}),(0,b.jsx)("span",{className:"bt-cat-lbl",children:"All"})]}),j?Array.from({length:5}).map((a,c)=>(0,b.jsxs)("div",{className:"bt-cat",children:[(0,b.jsx)("span",{className:"bt-cat-ic skel"}),(0,b.jsx)("span",{className:"bt-cat-lbl skel-txt"})]},c)):h.map((a,c)=>(0,b.jsxs)("button",{className:`bt-cat ${t===a.id?"on":""}`,onClick:()=>u(a.id),children:[(0,b.jsx)("span",{className:"bt-cat-ic",style:{background:c%2?i.C.greenSoft:i.C.orangeSoft},children:a.image?(0,b.jsx)("img",{src:a.image,alt:a.name}):a.emoji}),(0,b.jsx)("span",{className:"bt-cat-lbl",children:a.name})]},a.id))]})}),(0,b.jsxs)("section",{className:"bt-offers",children:[(0,b.jsxs)("div",{className:"bt-offer dark",children:[(0,b.jsx)("span",{className:"bt-offer-ic",style:{background:i.C.orange},children:"%"}),(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"bt-offer-t",children:"70% OFF up to ₹100"}),(0,b.jsx)("div",{className:"bt-offer-s",children:"USE BITE70"})]})]}),(0,b.jsxs)("div",{className:"bt-offer soft",children:[(0,b.jsx)("span",{className:"bt-offer-ic",style:{background:i.C.green},children:"🍛"}),(0,b.jsxs)("div",{children:[(0,b.jsx)("div",{className:"bt-offer-t",style:{color:"#854f0b"},children:"Thali at ₹99"}),(0,b.jsx)("div",{className:"bt-offer-s",style:{color:"#ba7517"},children:"TODAY ONLY"})]})]})]}),(0,b.jsx)("section",{className:"bt-filters",children:[["pop","Sort by"],["protein","High Protein"],["lowcal","Under 400 cal"],["cheap","Cheapest"]].map(([a,c])=>(0,b.jsx)("button",{className:`bt-chip ${v===a?"on":""}`,onClick:()=>w(a),children:c},a))}),(0,b.jsxs)("section",{className:"bt-products",children:[(0,b.jsx)("h2",{className:"bt-sec-title",children:"all"===t?"Popular near you":h.find(a=>a.id===t)?.name||"Menu"}),l&&(0,b.jsx)("div",{className:"bt-empty",children:l}),j?Array.from({length:4}).map((a,c)=>(0,b.jsxs)("div",{className:"bt-card",children:[(0,b.jsx)("div",{className:"bt-card-img skel"}),(0,b.jsxs)("div",{className:"bt-card-body",children:[(0,b.jsx)("div",{className:"skel-txt",style:{width:"60%"}}),(0,b.jsx)("div",{className:"skel-txt",style:{width:"90%"}}),(0,b.jsx)("div",{className:"skel-txt",style:{width:"40%"}})]})]},c)):0===J.length?(0,b.jsx)("div",{className:"bt-empty",children:"Is category mein abhi kuch nahi hai. Doosri dekho!"}):J.map(a=>(0,b.jsx)(f.default,{p:a},a.id))]}),(0,b.jsx)("div",{style:{height:16}})]})},"dynamic",0,"force-dynamic"],60350)}];

//# sourceMappingURL=app_page_tsx_0pxmutw._.js.map