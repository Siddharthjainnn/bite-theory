1:"$Sreact.fragment"
2:I[730,["882","static/chunks/882-2f1a4a2efae4654f.js","177","static/chunks/app/layout-07a3023714e77a9a.js"],"default"]
3:I[8914,["882","static/chunks/882-2f1a4a2efae4654f.js","177","static/chunks/app/layout-07a3023714e77a9a.js"],"CartProvider"]
4:I[7121,[],""]
5:I[4581,[],""]
:HL["/_next/static/css/c8d2e1a9a1d776a3.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/c8d2e1a9a1d776a3.css","precedence":"next"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"style":{"margin":0},"children":["$","$L2",null,{"children":["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]}]}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"EGdGjd10ibSJYkyDsuiiF"}
