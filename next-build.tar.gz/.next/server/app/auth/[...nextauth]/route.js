var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__0qeb6-r._.js")
R.c("server/chunks/[root-of-the-server]__13242di._.js")
R.c("server/chunks/_next-internal_server_app_auth_[___nextauth]_route_actions_0tlu9m6.js")
R.m(96268)
module.exports=R.m(96268).exports
