1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/0oj0rbp2-4y_y.js","/_next/static/chunks/14mrh2-p_w84d.js"],"ViewportBoundary"]
3:I[97367,["/_next/static/chunks/0oj0rbp2-4y_y.js","/_next/static/chunks/14mrh2-p_w84d.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Bite Theory — Smart Food, Better Living"}],["$","meta","1",{"name":"description","content":"100% pure veg. Good food, right price. Indore."}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"T35RmELSIZvAXrWZ-IXUV"}
