var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/account/profile/route.js")
R.c("server/chunks/[externals]__1j99fbg._.js")
R.c("server/chunks/[root-of-the-server]__16f7npj._.js")
R.c("server/chunks/_0gvqm2n._.js")
R.c("server/chunks/_next-internal_server_app_account_profile_route_actions_1-4hb6-.js")
R.m(92685)
module.exports=R.m(92685).exports
